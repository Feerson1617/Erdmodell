# Messbericht G1.3.1

Produktionsbuild `c806a1b1358b17816e686e32e58e4369490088c7`

14 Bedienfolgen pro Engine. Bildzeiten stammen aus einer separaten ruhenden Schalenansicht bei 1920 × 1080. Die Auflösung gilt für das Modell neben der Bedienleiste.

## chromium 141.0.7390.37

ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero) (0x0000C0DE)), SwiftShader driver)

- Anteil der Modellfläche am Bildschirm bei 1920 × 1080: Globus 94%, Schalenschnitt im Präsentationsmodus 76%.
- 8.2 FPS. Median 149.9 ms, P95 183.3 ms, Maximum 283.4 ms.
- Puffer 1181 × 755. Faktor 0.75, Start 1.00, Minimum 0.75, Maximum 1.00. Absenkungen 2, Anhebungen 0.
- Warme Geometrien, Texturen und Programme zu Beginn → Ende: 53 → 53, 8 → 8, 11 → 11.
- Bedienfolge bis zur Bildausgabe im Median 393 ms, maximal 584 ms.
- JS-Heap in den warmen Zyklen: 13.6–13.6 MiB.

## webkit 26.0

Apple GPU

- Anteil der Modellfläche am Bildschirm bei 1920 × 1080: Globus 94%, Schalenschnitt im Präsentationsmodus 76%.
- 15.0 FPS. Median 66.0 ms, P95 78.0 ms, Maximum 108.0 ms.
- Puffer 1181 × 755. Faktor 0.75, Start 1.00, Minimum 0.75, Maximum 1.00. Absenkungen 2, Anhebungen 0.
- Warme Geometrien, Texturen und Programme zu Beginn → Ende: 53 → 53, 8 → 8, 11 → 11.
- Bedienfolge bis zur Bildausgabe im Median 143 ms, maximal 211 ms.
- JS-Heap vom Browser nicht ausgewiesen.
