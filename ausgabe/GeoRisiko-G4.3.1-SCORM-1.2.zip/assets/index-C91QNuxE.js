(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function t(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(s){if(s.ep)return;s.ep=!0;const r=t(s);fetch(s.href,r)}})();const os=i=>window.__geoAsset?.(i)??"./"+i;function Bs(i,e,t,n){const s=i.clone().project(e);return Math.max(Math.abs(s.x),Math.abs(s.y),Math.abs(s.z))>1?null:{x:(1+s.x)*t/2,y:(1-s.y)*n/2}}const Ou=(i,e)=>i.left<e.right+3&&i.right>e.left-3&&i.top<e.bottom+3&&i.bottom>e.top-3;class Eh{constructor(e,t){this.host=e,this.explain=t}work={draws:0,layouts:0,measures:0,creates:0,writes:0};nodes=new Map;sizes=new Map;frame;obstacles=[];revision=-1;draw(e,t,n){if(!e.length){this.host.childElementCount&&this.host.replaceChildren();return}if(this.work.draws++,!this.frame||n!==this.revision){this.revision=n;const a=this.frame=this.host.getBoundingClientRect();this.obstacles=t.filter(l=>l&&l.offsetWidth).map(l=>{const c=l.getBoundingClientRect();return{left:c.left-a.left,right:c.right-a.left,top:c.top-a.top,bottom:c.bottom-a.top}}),this.sizes.clear(),this.work.layouts++}const s=this.frame,r=[...this.obstacles],o=new Set;for(const a of e){let l=this.nodes.get(a.id);if(!l){const y=document.createElement("button"),x=document.createElement("i"),v=document.createElement("span");v.className="annotation-anchor",v.append(x,y);const w=document.createElement("span");w.textContent=a.name,y.append(w),y.dataset.object=a.id;const M={anchor:v,button:y,line:x,label:a};y.onclick=()=>this.explain(M.label),this.work.creates++,this.nodes.set(a.id,l=M)}const{anchor:c,button:h,line:u}=l;l.label=a;let d=this.sizes.get(a.name);d||(h.isConnected||this.host.append(c),this.work.measures++,d={width:h.offsetWidth,height:h.offsetHeight},this.sizes.set(a.name,d));const f=d.width,g=d.height,_=f/2+12,m=g/2+10,p=[[0,-m],[0,m],[_,0],[-_,0],[_,-m],[-_,-m],[_,m],[-_,m],[0,-m-g],[0,m+g],[-_,-m-g],[_,m+g]];for(const[y,x]of p){const v=a.x+y,w=a.y+x,M={left:v-f/2,right:v+f/2,top:w-g/2,bottom:w+g/2};if(M.left<3||M.right>s.width-3||M.top<3||M.bottom>s.height-3||r.some(k=>Ou(M,k)))continue;h.isConnected||this.host.append(c),o.add(a.id),r.push(M);const A=`translate(${Math.round(a.x*2)/2}px, ${Math.round(a.y*2)/2}px)`,T=y-f/2,S=x-g/2,b=`translate(${T}px, ${S}px)`,D=Math.min(T+f,Math.max(T,0)),I=Math.min(S+g,Math.max(S,0)),U=`rotate(${Math.atan2(I,D).toFixed(5)}rad)`,B=Math.hypot(D,I).toFixed(1)+"px";l.anchorPose!==A&&(c.style.transform=l.anchorPose=A,this.work.writes++),l.buttonPose!==b&&(h.style.transform=l.buttonPose=b,this.work.writes++),l.linePose!==U&&(u.style.transform=l.linePose=U,this.work.writes++),l.length!==B&&(u.style.width=l.length=B,this.work.writes++);break}}for(const[a,l]of this.nodes)l.button.isConnected&&!o.has(a)&&l.anchor.remove()}}const Fu=[{id:"hooge",name:"Hallig Hooge",target:{lat:54.5660014,lon:8.5504131,d:.29,tilt:75,bearing:-27},bounds:[8.48,54.54,8.604,54.6],overview:{d:9,tilt:35,bearing:0},context:"Nordfriesisches Wattenmeer",description:"Auf der Hanswarft stehen Häuser auf einem erhöhten Siedlungshügel. Ringsum verlaufen Gräben durch das Grünland.",sources:["© OpenStreetMap-Mitwirkende · ODbL 1.0","© GeoBasis-DE/LVermGeo SH · CC BY 4.0"],height:{kind:"mounds",baseM:1.7,riseM:5.8,radiusKm:[.125,.085]},mesh:"hooge-surface.bin",features:"hooge.json",maps:{base:"hooge.webp",A:"hooge-coast-air.webp",B:"hooge-atlas.webp",detail:"hanswarft.webp",detailBounds:[8.5404131,54.5600014,8.5604131,54.5720014]},lod:{loadKm:1400,fadeKm:[10,135],buildingsKm:12,fallbackKm:140},limits:"Warftprofile, Dächer und Bäume sind modelliert. Luftbild und Wasser zeigen keinen bestimmten Gezeitenstand.",label:"Warft- und Gebäudehöhen modelliert",validatedHazards:[],inputs:{orthoBase:"hooge-air.webp"}},{id:"helgoland",name:"Helgoland",target:{lat:54.184,lon:7.879,d:2.5,tilt:49,bearing:34},bounds:[7.855,54.166,7.932,54.2],overview:{d:6,tilt:28,bearing:0},context:"Deutsche Bucht · Teststandort",description:"Hauptinsel und Düne aus der Vogelperspektive. Das Oberland hebt sich von der flachen Nachbarinsel ab.",sources:["Copernicus DEM GLO-30 · Copernicus DEM Licence","© GeoBasis-DE/LVermGeo SH · CC BY 4.0"],height:{kind:"dsm",file:"helgoland-dsm.json"},mesh:"helgoland-surface.bin",features:null,maps:{base:"helgoland-atlas.webp",A:"helgoland-air.webp",B:"helgoland-atlas.webp"},lod:{loadKm:900,fadeKm:[8,100],buildingsKm:0,fallbackKm:140},limits:"Das Oberflächenmodell umfasst auch Vegetation und Bauwerke. Die steile Kliffkante ist durch das Messraster geglättet.",label:"Oberflächenmodell · ca. 30 m Messraster",validatedHazards:[],inputs:{dem:"helgoland.tif",ortho:"helgoland.jpg",grid:[167,135]}}];const ll="180",Bu=0,$l=1,zu=2,Ah=1,Th=2,Hn=3,jn=0,jt=1,wt=2,li=0,es=1,ql=2,Yl=3,jl=4,ku=5,Mi=100,Vu=101,Hu=102,Gu=103,Wu=104,Xu=200,$u=201,qu=202,Yu=203,oa=204,aa=205,ju=206,Ku=207,Zu=208,Ju=209,Qu=210,ed=211,td=212,nd=213,id=214,la=0,ca=1,ha=2,as=3,ua=4,da=5,fa=6,pa=7,cl=0,sd=1,rd=2,ci=0,od=1,ad=2,ld=3,Ch=4,cd=5,hd=6,ud=7,Rh=300,ls=301,cs=302,ma=303,ga=304,no=306,zs=1e3,bi=1001,va=1002,tn=1003,dd=1004,ar=1005,Sn=1006,fo=1007,oi=1008,In=1009,Ph=1010,Lh=1011,ks=1012,hl=1013,Ai=1014,Pn=1015,er=1016,ul=1017,dl=1018,Vs=1020,Dh=35902,Ih=35899,Uh=1021,Nh=1022,bn=1023,Hs=1026,Gs=1027,fl=1028,pl=1029,Oh=1030,ml=1031,gl=1033,Gr=33776,Wr=33777,Xr=33778,$r=33779,_a=35840,xa=35841,ya=35842,Ma=35843,Sa=36196,ba=37492,wa=37496,Ea=37808,Aa=37809,Ta=37810,Ca=37811,Ra=37812,Pa=37813,La=37814,Da=37815,Ia=37816,Ua=37817,Na=37818,Oa=37819,Fa=37820,Ba=37821,za=36492,ka=36494,Va=36495,Ha=36283,Ga=36284,Wa=36285,Xa=36286,fd=3200,pd=3201,vl=0,md=1,Gn="",Wt="srgb",hs="srgb-linear",jr="linear",gt="srgb",Li=7680,Kl=519,gd=512,vd=513,_d=514,Fh=515,xd=516,yd=517,Md=518,Sd=519,$a=35044,bd=35048,Zl="300 es",Ln=2e3,Kr=2001;class ps{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const s=n[e];if(s!==void 0){const r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,e);e.target=null}}}const Vt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let Jl=1234567;const Is=Math.PI/180,Ws=180/Math.PI;function Dn(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Vt[i&255]+Vt[i>>8&255]+Vt[i>>16&255]+Vt[i>>24&255]+"-"+Vt[e&255]+Vt[e>>8&255]+"-"+Vt[e>>16&15|64]+Vt[e>>24&255]+"-"+Vt[t&63|128]+Vt[t>>8&255]+"-"+Vt[t>>16&255]+Vt[t>>24&255]+Vt[n&255]+Vt[n>>8&255]+Vt[n>>16&255]+Vt[n>>24&255]).toLowerCase()}function We(i,e,t){return Math.max(e,Math.min(t,i))}function _l(i,e){return(i%e+e)%e}function wd(i,e,t,n,s){return n+(i-e)*(s-n)/(t-e)}function Ed(i,e,t){return i!==e?(t-i)/(e-i):0}function Us(i,e,t){return(1-t)*i+t*e}function Ad(i,e,t,n){return Us(i,e,1-Math.exp(-t*n))}function Td(i,e=1){return e-Math.abs(_l(i,e*2)-e)}function Cd(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function Rd(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function Pd(i,e){return i+Math.floor(Math.random()*(e-i+1))}function Ld(i,e){return i+Math.random()*(e-i)}function Dd(i){return i*(.5-Math.random())}function Id(i){i!==void 0&&(Jl=i);let e=Jl+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function Ud(i){return i*Is}function Nd(i){return i*Ws}function Od(i){return(i&i-1)===0&&i!==0}function Fd(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Bd(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function zd(i,e,t,n,s){const r=Math.cos,o=Math.sin,a=r(t/2),l=o(t/2),c=r((e+n)/2),h=o((e+n)/2),u=r((e-n)/2),d=o((e-n)/2),f=r((n-e)/2),g=o((n-e)/2);switch(s){case"XYX":i.set(a*h,l*u,l*d,a*c);break;case"YZY":i.set(l*d,a*h,l*u,a*c);break;case"ZXZ":i.set(l*u,l*d,a*h,a*c);break;case"XZX":i.set(a*h,l*g,l*f,a*c);break;case"YXY":i.set(l*f,a*h,l*g,a*c);break;case"ZYZ":i.set(l*g,l*f,a*h,a*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Mn(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function ft(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}const ut={DEG2RAD:Is,RAD2DEG:Ws,generateUUID:Dn,clamp:We,euclideanModulo:_l,mapLinear:wd,inverseLerp:Ed,lerp:Us,damp:Ad,pingpong:Td,smoothstep:Cd,smootherstep:Rd,randInt:Pd,randFloat:Ld,randFloatSpread:Dd,seededRandom:Id,degToRad:Ud,radToDeg:Nd,isPowerOfTwo:Od,ceilPowerOfTwo:Fd,floorPowerOfTwo:Bd,setQuaternionFromProperEuler:zd,normalize:ft,denormalize:Mn};class ue{constructor(e=0,t=0){ue.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=We(this.x,e.x,t.x),this.y=We(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=We(this.x,e,t),this.y=We(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(We(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(We(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),s=Math.sin(t),r=this.x-e.x,o=this.y-e.y;return this.x=r*n-o*s+e.x,this.y=r*s+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class tr{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,r,o,a){let l=n[s+0],c=n[s+1],h=n[s+2],u=n[s+3];const d=r[o+0],f=r[o+1],g=r[o+2],_=r[o+3];if(a===0){e[t+0]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u;return}if(a===1){e[t+0]=d,e[t+1]=f,e[t+2]=g,e[t+3]=_;return}if(u!==_||l!==d||c!==f||h!==g){let m=1-a;const p=l*d+c*f+h*g+u*_,y=p>=0?1:-1,x=1-p*p;if(x>Number.EPSILON){const w=Math.sqrt(x),M=Math.atan2(w,p*y);m=Math.sin(m*M)/w,a=Math.sin(a*M)/w}const v=a*y;if(l=l*m+d*v,c=c*m+f*v,h=h*m+g*v,u=u*m+_*v,m===1-a){const w=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=w,c*=w,h*=w,u*=w}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,s,r,o){const a=n[s],l=n[s+1],c=n[s+2],h=n[s+3],u=r[o],d=r[o+1],f=r[o+2],g=r[o+3];return e[t]=a*g+h*u+l*f-c*d,e[t+1]=l*g+h*d+c*u-a*f,e[t+2]=c*g+h*f+a*d-l*u,e[t+3]=h*g-a*u-l*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,s=e._y,r=e._z,o=e._order,a=Math.cos,l=Math.sin,c=a(n/2),h=a(s/2),u=a(r/2),d=l(n/2),f=l(s/2),g=l(r/2);switch(o){case"XYZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"YXZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"ZXY":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"ZYX":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"YZX":this._x=d*h*u+c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u-d*f*g;break;case"XZY":this._x=d*h*u-c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u+d*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],s=t[4],r=t[8],o=t[1],a=t[5],l=t[9],c=t[2],h=t[6],u=t[10],d=n+a+u;if(d>0){const f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(r-c)*f,this._z=(o-s)*f}else if(n>a&&n>u){const f=2*Math.sqrt(1+n-a-u);this._w=(h-l)/f,this._x=.25*f,this._y=(s+o)/f,this._z=(r+c)/f}else if(a>u){const f=2*Math.sqrt(1+a-n-u);this._w=(r-c)/f,this._x=(s+o)/f,this._y=.25*f,this._z=(l+h)/f}else{const f=2*Math.sqrt(1+u-n-a);this._w=(o-s)/f,this._x=(r+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(We(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,s=e._y,r=e._z,o=e._w,a=t._x,l=t._y,c=t._z,h=t._w;return this._x=n*h+o*a+s*c-r*l,this._y=s*h+o*l+r*a-n*c,this._z=r*h+o*c+n*l-s*a,this._w=o*h-n*a-s*l-r*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const n=this._x,s=this._y,r=this._z,o=this._w;let a=o*e._w+n*e._x+s*e._y+r*e._z;if(a<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,a=-a):this.copy(e),a>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;const l=1-a*a;if(l<=Number.EPSILON){const f=1-t;return this._w=f*o+t*this._w,this._x=f*n+t*this._x,this._y=f*s+t*this._y,this._z=f*r+t*this._z,this.normalize(),this}const c=Math.sqrt(l),h=Math.atan2(c,a),u=Math.sin((1-t)*h)/c,d=Math.sin(t*h)/c;return this._w=o*u+this._w*d,this._x=n*u+this._x*d,this._y=s*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class P{constructor(e=0,t=0,n=0){P.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Ql.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Ql.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6]*s,this.y=r[1]*t+r[4]*n+r[7]*s,this.z=r[2]*t+r[5]*n+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=e.elements,o=1/(r[3]*t+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*t+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*t+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(e){const t=this.x,n=this.y,s=this.z,r=e.x,o=e.y,a=e.z,l=e.w,c=2*(o*s-a*n),h=2*(a*t-r*s),u=2*(r*n-o*t);return this.x=t+l*c+o*u-a*h,this.y=n+l*h+a*c-r*u,this.z=s+l*u+r*h-o*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s,this.y=r[1]*t+r[5]*n+r[9]*s,this.z=r[2]*t+r[6]*n+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=We(this.x,e.x,t.x),this.y=We(this.y,e.y,t.y),this.z=We(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=We(this.x,e,t),this.y=We(this.y,e,t),this.z=We(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(We(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,s=e.y,r=e.z,o=t.x,a=t.y,l=t.z;return this.x=s*l-r*a,this.y=r*o-n*l,this.z=n*a-s*o,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return po.copy(this).projectOnVector(e),this.sub(po)}reflect(e){return this.sub(po.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(We(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const po=new P,Ql=new tr;class je{constructor(e,t,n,s,r,o,a,l,c){je.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,l,c)}set(e,t,n,s,r,o,a,l,c){const h=this.elements;return h[0]=e,h[1]=s,h[2]=a,h[3]=t,h[4]=r,h[5]=l,h[6]=n,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],g=n[8],_=s[0],m=s[3],p=s[6],y=s[1],x=s[4],v=s[7],w=s[2],M=s[5],A=s[8];return r[0]=o*_+a*y+l*w,r[3]=o*m+a*x+l*M,r[6]=o*p+a*v+l*A,r[1]=c*_+h*y+u*w,r[4]=c*m+h*x+u*M,r[7]=c*p+h*v+u*A,r[2]=d*_+f*y+g*w,r[5]=d*m+f*x+g*M,r[8]=d*p+f*v+g*A,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8];return t*o*h-t*a*c-n*r*h+n*a*l+s*r*c-s*o*l}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=h*o-a*c,d=a*l-h*r,f=c*r-o*l,g=t*u+n*d+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const _=1/g;return e[0]=u*_,e[1]=(s*c-h*n)*_,e[2]=(a*n-s*o)*_,e[3]=d*_,e[4]=(h*t-s*l)*_,e[5]=(s*r-a*t)*_,e[6]=f*_,e[7]=(n*l-c*t)*_,e[8]=(o*t-n*r)*_,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,r,o,a){const l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*o+c*a)+o+e,-s*c,s*l,-s*(-c*o+l*a)+a+t,0,0,1),this}scale(e,t){return this.premultiply(mo.makeScale(e,t)),this}rotate(e){return this.premultiply(mo.makeRotation(-e)),this}translate(e,t){return this.premultiply(mo.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const mo=new je;function Bh(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function Xs(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function kd(){const i=Xs("canvas");return i.style.display="block",i}const ec={};function $s(i){i in ec||(ec[i]=!0,console.warn(i))}function Vd(i,e,t){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,t);break;default:n()}}setTimeout(r,t)})}const tc=new je().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),nc=new je().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Hd(){const i={enabled:!0,workingColorSpace:hs,spaces:{},convert:function(s,r,o){return this.enabled===!1||r===o||!r||!o||(this.spaces[r].transfer===gt&&(s.r=Xn(s.r),s.g=Xn(s.g),s.b=Xn(s.b)),this.spaces[r].primaries!==this.spaces[o].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===gt&&(s.r=ts(s.r),s.g=ts(s.g),s.b=ts(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===Gn?jr:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,o){return s.copy(this.spaces[r].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(s,r){return $s("THREE.ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),i.workingToColorSpace(s,r)},toWorkingColorSpace:function(s,r){return $s("THREE.ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),i.colorSpaceToWorking(s,r)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[hs]:{primaries:e,whitePoint:n,transfer:jr,toXYZ:tc,fromXYZ:nc,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Wt},outputColorSpaceConfig:{drawingBufferColorSpace:Wt}},[Wt]:{primaries:e,whitePoint:n,transfer:gt,toXYZ:tc,fromXYZ:nc,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Wt}}}),i}const ht=Hd();function Xn(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function ts(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let Di;class Gd{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{Di===void 0&&(Di=Xs("canvas")),Di.width=e.width,Di.height=e.height;const s=Di.getContext("2d");e instanceof ImageData?s.putImageData(e,0,0):s.drawImage(e,0,0,e.width,e.height),n=Di}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Xs("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const s=n.getImageData(0,0,e.width,e.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=Xn(r[o]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(Xn(t[n]/255)*255):t[n]=Xn(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Wd=0;class xl{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Wd++}),this.uuid=Dn(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):t instanceof VideoFrame?e.set(t.displayHeight,t.displayWidth,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(go(s[o].image)):r.push(go(s[o]))}else r=go(s);n.url=r}return t||(e.images[this.uuid]=n),n}}function go(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?Gd.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Xd=0;const vo=new P;class Xt extends ps{constructor(e=Xt.DEFAULT_IMAGE,t=Xt.DEFAULT_MAPPING,n=bi,s=bi,r=Sn,o=oi,a=bn,l=In,c=Xt.DEFAULT_ANISOTROPY,h=Gn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Xd++}),this.uuid=Dn(),this.name="",this.source=new xl(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new ue(0,0),this.repeat=new ue(1,1),this.center=new ue(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new je,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(vo).x}get height(){return this.source.getSize(vo).y}get depth(){return this.source.getSize(vo).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){console.warn(`THREE.Texture.setValues(): property '${t}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Rh)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case zs:e.x=e.x-Math.floor(e.x);break;case bi:e.x=e.x<0?0:1;break;case va:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case zs:e.y=e.y-Math.floor(e.y);break;case bi:e.y=e.y<0?0:1;break;case va:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Xt.DEFAULT_IMAGE=null;Xt.DEFAULT_MAPPING=Rh;Xt.DEFAULT_ANISOTROPY=1;class at{constructor(e=0,t=0,n=0,s=1){at.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*t+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*t+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*t+o[7]*n+o[11]*s+o[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,r;const l=e.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],g=l[9],_=l[2],m=l[6],p=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-_)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+_)<.1&&Math.abs(g+m)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const x=(c+1)/2,v=(f+1)/2,w=(p+1)/2,M=(h+d)/4,A=(u+_)/4,T=(g+m)/4;return x>v&&x>w?x<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(x),s=M/n,r=A/n):v>w?v<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(v),n=M/s,r=T/s):w<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(w),n=A/r,s=T/r),this.set(n,s,r,t),this}let y=Math.sqrt((m-g)*(m-g)+(u-_)*(u-_)+(d-h)*(d-h));return Math.abs(y)<.001&&(y=1),this.x=(m-g)/y,this.y=(u-_)/y,this.z=(d-h)/y,this.w=Math.acos((c+f+p-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=We(this.x,e.x,t.x),this.y=We(this.y,e.y,t.y),this.z=We(this.z,e.z,t.z),this.w=We(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=We(this.x,e,t),this.y=We(this.y,e,t),this.z=We(this.z,e,t),this.w=We(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(We(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class $d extends ps{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Sn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new at(0,0,e,t),this.scissorTest=!1,this.viewport=new at(0,0,e,t);const s={width:e,height:t,depth:n.depth},r=new Xt(s);this.textures=[];const o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(e={}){const t={minFilter:Sn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=n,this.textures[s].isArrayTexture=this.textures[s].image.depth>1;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const s=Object.assign({},e.textures[t].image);this.textures[t].source=new xl(s)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Ti extends $d{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class zh extends Xt{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=tn,this.minFilter=tn,this.wrapR=bi,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class qd extends Xt{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=tn,this.minFilter=tn,this.wrapR=bi,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class cn{constructor(e=new P(1/0,1/0,1/0),t=new P(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(vn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(vn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=vn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const r=n.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,vn):vn.fromBufferAttribute(r,o),vn.applyMatrix4(e.matrixWorld),this.expandByPoint(vn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),lr.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),lr.copy(n.boundingBox)),lr.applyMatrix4(e.matrixWorld),this.union(lr)}const s=e.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,vn),vn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(xs),cr.subVectors(this.max,xs),Ii.subVectors(e.a,xs),Ui.subVectors(e.b,xs),Ni.subVectors(e.c,xs),Zn.subVectors(Ui,Ii),Jn.subVectors(Ni,Ui),di.subVectors(Ii,Ni);let t=[0,-Zn.z,Zn.y,0,-Jn.z,Jn.y,0,-di.z,di.y,Zn.z,0,-Zn.x,Jn.z,0,-Jn.x,di.z,0,-di.x,-Zn.y,Zn.x,0,-Jn.y,Jn.x,0,-di.y,di.x,0];return!_o(t,Ii,Ui,Ni,cr)||(t=[1,0,0,0,1,0,0,0,1],!_o(t,Ii,Ui,Ni,cr))?!1:(hr.crossVectors(Zn,Jn),t=[hr.x,hr.y,hr.z],_o(t,Ii,Ui,Ni,cr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,vn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(vn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(On[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),On[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),On[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),On[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),On[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),On[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),On[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),On[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(On),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const On=[new P,new P,new P,new P,new P,new P,new P,new P],vn=new P,lr=new cn,Ii=new P,Ui=new P,Ni=new P,Zn=new P,Jn=new P,di=new P,xs=new P,cr=new P,hr=new P,fi=new P;function _o(i,e,t,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){fi.fromArray(i,r);const a=s.x*Math.abs(fi.x)+s.y*Math.abs(fi.y)+s.z*Math.abs(fi.z),l=e.dot(fi),c=t.dot(fi),h=n.dot(fi);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}const Yd=new cn,ys=new P,xo=new P;class wn{constructor(e=new P,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):Yd.setFromPoints(e).getCenter(n);let s=0;for(let r=0,o=e.length;r<o;r++)s=Math.max(s,n.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;ys.subVectors(e,this.center);const t=ys.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(ys,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(xo.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(ys.copy(e.center).add(xo)),this.expandByPoint(ys.copy(e.center).sub(xo))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}const Fn=new P,yo=new P,ur=new P,Qn=new P,Mo=new P,dr=new P,So=new P;class io{constructor(e=new P,t=new P(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Fn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Fn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Fn.copy(this.origin).addScaledVector(this.direction,t),Fn.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){yo.copy(e).add(t).multiplyScalar(.5),ur.copy(t).sub(e).normalize(),Qn.copy(this.origin).sub(yo);const r=e.distanceTo(t)*.5,o=-this.direction.dot(ur),a=Qn.dot(this.direction),l=-Qn.dot(ur),c=Qn.lengthSq(),h=Math.abs(1-o*o);let u,d,f,g;if(h>0)if(u=o*l-a,d=o*a-l,g=r*h,u>=0)if(d>=-g)if(d<=g){const _=1/h;u*=_,d*=_,f=u*(u+o*d+2*a)+d*(o*u+d+2*l)+c}else d=r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d<=-g?(u=Math.max(0,-(-o*r+a)),d=u>0?-r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c):d<=g?(u=0,d=Math.min(Math.max(-r,-l),r),f=d*(d+2*l)+c):(u=Math.max(0,-(o*r+a)),d=u>0?r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c);else d=o>0?-r:r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(yo).addScaledVector(ur,d),f}intersectSphere(e,t){Fn.subVectors(e.center,this.origin);const n=Fn.dot(this.direction),s=Fn.dot(Fn)-n*n,r=e.radius*e.radius;if(s>r)return null;const o=Math.sqrt(r-s),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,t):this.at(a,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,r,o,a,l;const c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,s=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,s=(e.min.x-d.x)*c),h>=0?(r=(e.min.y-d.y)*h,o=(e.max.y-d.y)*h):(r=(e.max.y-d.y)*h,o=(e.min.y-d.y)*h),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),u>=0?(a=(e.min.z-d.z)*u,l=(e.max.z-d.z)*u):(a=(e.max.z-d.z)*u,l=(e.min.z-d.z)*u),n>l||a>s)||((a>n||n!==n)&&(n=a),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,Fn)!==null}intersectTriangle(e,t,n,s,r){Mo.subVectors(t,e),dr.subVectors(n,e),So.crossVectors(Mo,dr);let o=this.direction.dot(So),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;Qn.subVectors(this.origin,e);const l=a*this.direction.dot(dr.crossVectors(Qn,dr));if(l<0)return null;const c=a*this.direction.dot(Mo.cross(Qn));if(c<0||l+c>o)return null;const h=-a*Qn.dot(So);return h<0?null:this.at(h/o,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class st{constructor(e,t,n,s,r,o,a,l,c,h,u,d,f,g,_,m){st.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,l,c,h,u,d,f,g,_,m)}set(e,t,n,s,r,o,a,l,c,h,u,d,f,g,_,m){const p=this.elements;return p[0]=e,p[4]=t,p[8]=n,p[12]=s,p[1]=r,p[5]=o,p[9]=a,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=d,p[3]=f,p[7]=g,p[11]=_,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new st().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,n=e.elements,s=1/Oi.setFromMatrixColumn(e,0).length(),r=1/Oi.setFromMatrixColumn(e,1).length(),o=1/Oi.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*r,t[5]=n[5]*r,t[6]=n[6]*r,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,s=e.y,r=e.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(s),c=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(e.order==="XYZ"){const d=o*h,f=o*u,g=a*h,_=a*u;t[0]=l*h,t[4]=-l*u,t[8]=c,t[1]=f+g*c,t[5]=d-_*c,t[9]=-a*l,t[2]=_-d*c,t[6]=g+f*c,t[10]=o*l}else if(e.order==="YXZ"){const d=l*h,f=l*u,g=c*h,_=c*u;t[0]=d+_*a,t[4]=g*a-f,t[8]=o*c,t[1]=o*u,t[5]=o*h,t[9]=-a,t[2]=f*a-g,t[6]=_+d*a,t[10]=o*l}else if(e.order==="ZXY"){const d=l*h,f=l*u,g=c*h,_=c*u;t[0]=d-_*a,t[4]=-o*u,t[8]=g+f*a,t[1]=f+g*a,t[5]=o*h,t[9]=_-d*a,t[2]=-o*c,t[6]=a,t[10]=o*l}else if(e.order==="ZYX"){const d=o*h,f=o*u,g=a*h,_=a*u;t[0]=l*h,t[4]=g*c-f,t[8]=d*c+_,t[1]=l*u,t[5]=_*c+d,t[9]=f*c-g,t[2]=-c,t[6]=a*l,t[10]=o*l}else if(e.order==="YZX"){const d=o*l,f=o*c,g=a*l,_=a*c;t[0]=l*h,t[4]=_-d*u,t[8]=g*u+f,t[1]=u,t[5]=o*h,t[9]=-a*h,t[2]=-c*h,t[6]=f*u+g,t[10]=d-_*u}else if(e.order==="XZY"){const d=o*l,f=o*c,g=a*l,_=a*c;t[0]=l*h,t[4]=-u,t[8]=c*h,t[1]=d*u+_,t[5]=o*h,t[9]=f*u-g,t[2]=g*u-f,t[6]=a*h,t[10]=_*u+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(jd,e,Kd)}lookAt(e,t,n){const s=this.elements;return on.subVectors(e,t),on.lengthSq()===0&&(on.z=1),on.normalize(),ei.crossVectors(n,on),ei.lengthSq()===0&&(Math.abs(n.z)===1?on.x+=1e-4:on.z+=1e-4,on.normalize(),ei.crossVectors(n,on)),ei.normalize(),fr.crossVectors(on,ei),s[0]=ei.x,s[4]=fr.x,s[8]=on.x,s[1]=ei.y,s[5]=fr.y,s[9]=on.y,s[2]=ei.z,s[6]=fr.z,s[10]=on.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],g=n[2],_=n[6],m=n[10],p=n[14],y=n[3],x=n[7],v=n[11],w=n[15],M=s[0],A=s[4],T=s[8],S=s[12],b=s[1],D=s[5],I=s[9],U=s[13],B=s[2],k=s[6],V=s[10],te=s[14],H=s[3],Q=s[7],re=s[11],ge=s[15];return r[0]=o*M+a*b+l*B+c*H,r[4]=o*A+a*D+l*k+c*Q,r[8]=o*T+a*I+l*V+c*re,r[12]=o*S+a*U+l*te+c*ge,r[1]=h*M+u*b+d*B+f*H,r[5]=h*A+u*D+d*k+f*Q,r[9]=h*T+u*I+d*V+f*re,r[13]=h*S+u*U+d*te+f*ge,r[2]=g*M+_*b+m*B+p*H,r[6]=g*A+_*D+m*k+p*Q,r[10]=g*T+_*I+m*V+p*re,r[14]=g*S+_*U+m*te+p*ge,r[3]=y*M+x*b+v*B+w*H,r[7]=y*A+x*D+v*k+w*Q,r[11]=y*T+x*I+v*V+w*re,r[15]=y*S+x*U+v*te+w*ge,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],s=e[8],r=e[12],o=e[1],a=e[5],l=e[9],c=e[13],h=e[2],u=e[6],d=e[10],f=e[14],g=e[3],_=e[7],m=e[11],p=e[15];return g*(+r*l*u-s*c*u-r*a*d+n*c*d+s*a*f-n*l*f)+_*(+t*l*f-t*c*d+r*o*d-s*o*f+s*c*h-r*l*h)+m*(+t*c*u-t*a*f-r*o*u+n*o*f+r*a*h-n*c*h)+p*(-s*a*h-t*l*u+t*a*d+s*o*u-n*o*d+n*l*h)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=e[9],d=e[10],f=e[11],g=e[12],_=e[13],m=e[14],p=e[15],y=u*m*c-_*d*c+_*l*f-a*m*f-u*l*p+a*d*p,x=g*d*c-h*m*c-g*l*f+o*m*f+h*l*p-o*d*p,v=h*_*c-g*u*c+g*a*f-o*_*f-h*a*p+o*u*p,w=g*u*l-h*_*l-g*a*d+o*_*d+h*a*m-o*u*m,M=t*y+n*x+s*v+r*w;if(M===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const A=1/M;return e[0]=y*A,e[1]=(_*d*r-u*m*r-_*s*f+n*m*f+u*s*p-n*d*p)*A,e[2]=(a*m*r-_*l*r+_*s*c-n*m*c-a*s*p+n*l*p)*A,e[3]=(u*l*r-a*d*r-u*s*c+n*d*c+a*s*f-n*l*f)*A,e[4]=x*A,e[5]=(h*m*r-g*d*r+g*s*f-t*m*f-h*s*p+t*d*p)*A,e[6]=(g*l*r-o*m*r-g*s*c+t*m*c+o*s*p-t*l*p)*A,e[7]=(o*d*r-h*l*r+h*s*c-t*d*c-o*s*f+t*l*f)*A,e[8]=v*A,e[9]=(g*u*r-h*_*r-g*n*f+t*_*f+h*n*p-t*u*p)*A,e[10]=(o*_*r-g*a*r+g*n*c-t*_*c-o*n*p+t*a*p)*A,e[11]=(h*a*r-o*u*r-h*n*c+t*u*c+o*n*f-t*a*f)*A,e[12]=w*A,e[13]=(h*_*s-g*u*s+g*n*d-t*_*d-h*n*m+t*u*m)*A,e[14]=(g*a*s-o*_*s-g*n*l+t*_*l+o*n*m-t*a*m)*A,e[15]=(o*u*s-h*a*s+h*n*l-t*u*l-o*n*d+t*a*d)*A,this}scale(e){const t=this.elements,n=e.x,s=e.y,r=e.z;return t[0]*=n,t[4]*=s,t[8]*=r,t[1]*=n,t[5]*=s,t[9]*=r,t[2]*=n,t[6]*=s,t[10]*=r,t[3]*=n,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),s=Math.sin(t),r=1-n,o=e.x,a=e.y,l=e.z,c=r*o,h=r*a;return this.set(c*o+n,c*a-s*l,c*l+s*a,0,c*a+s*l,h*a+n,h*l-s*o,0,c*l-s*a,h*l+s*o,r*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,r,o){return this.set(1,n,r,0,e,1,o,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){const s=this.elements,r=t._x,o=t._y,a=t._z,l=t._w,c=r+r,h=o+o,u=a+a,d=r*c,f=r*h,g=r*u,_=o*h,m=o*u,p=a*u,y=l*c,x=l*h,v=l*u,w=n.x,M=n.y,A=n.z;return s[0]=(1-(_+p))*w,s[1]=(f+v)*w,s[2]=(g-x)*w,s[3]=0,s[4]=(f-v)*M,s[5]=(1-(d+p))*M,s[6]=(m+y)*M,s[7]=0,s[8]=(g+x)*A,s[9]=(m-y)*A,s[10]=(1-(d+_))*A,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){const s=this.elements;let r=Oi.set(s[0],s[1],s[2]).length();const o=Oi.set(s[4],s[5],s[6]).length(),a=Oi.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],_n.copy(this);const c=1/r,h=1/o,u=1/a;return _n.elements[0]*=c,_n.elements[1]*=c,_n.elements[2]*=c,_n.elements[4]*=h,_n.elements[5]*=h,_n.elements[6]*=h,_n.elements[8]*=u,_n.elements[9]*=u,_n.elements[10]*=u,t.setFromRotationMatrix(_n),n.x=r,n.y=o,n.z=a,this}makePerspective(e,t,n,s,r,o,a=Ln,l=!1){const c=this.elements,h=2*r/(t-e),u=2*r/(n-s),d=(t+e)/(t-e),f=(n+s)/(n-s);let g,_;if(l)g=r/(o-r),_=o*r/(o-r);else if(a===Ln)g=-(o+r)/(o-r),_=-2*o*r/(o-r);else if(a===Kr)g=-o/(o-r),_=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return c[0]=h,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=g,c[14]=_,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,s,r,o,a=Ln,l=!1){const c=this.elements,h=2/(t-e),u=2/(n-s),d=-(t+e)/(t-e),f=-(n+s)/(n-s);let g,_;if(l)g=1/(o-r),_=o/(o-r);else if(a===Ln)g=-2/(o-r),_=-(o+r)/(o-r);else if(a===Kr)g=-1/(o-r),_=-r/(o-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return c[0]=h,c[4]=0,c[8]=0,c[12]=d,c[1]=0,c[5]=u,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=g,c[14]=_,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const Oi=new P,_n=new st,jd=new P(0,0,0),Kd=new P(1,1,1),ei=new P,fr=new P,on=new P,ic=new st,sc=new tr;class En{constructor(e=0,t=0,n=0,s=En.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const s=e.elements,r=s[0],o=s[4],a=s[8],l=s[1],c=s[5],h=s[9],u=s[2],d=s[6],f=s[10];switch(t){case"XYZ":this._y=Math.asin(We(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-We(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(We(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-We(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(We(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-We(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return ic.makeRotationFromQuaternion(e),this.setFromRotationMatrix(ic,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return sc.setFromEuler(this),this.setFromQuaternion(sc,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}En.DEFAULT_ORDER="XYZ";let yl=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}},Zd=0;const rc=new P,Fi=new tr,Bn=new st,pr=new P,Ms=new P,Jd=new P,Qd=new tr,oc=new P(1,0,0),ac=new P(0,1,0),lc=new P(0,0,1),cc={type:"added"},ef={type:"removed"},Bi={type:"childadded",child:null},bo={type:"childremoved",child:null};class Rt extends ps{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Zd++}),this.uuid=Dn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Rt.DEFAULT_UP.clone();const e=new P,t=new En,n=new tr,s=new P(1,1,1);function r(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new st},normalMatrix:{value:new je}}),this.matrix=new st,this.matrixWorld=new st,this.matrixAutoUpdate=Rt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Rt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new yl,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Fi.setFromAxisAngle(e,t),this.quaternion.multiply(Fi),this}rotateOnWorldAxis(e,t){return Fi.setFromAxisAngle(e,t),this.quaternion.premultiply(Fi),this}rotateX(e){return this.rotateOnAxis(oc,e)}rotateY(e){return this.rotateOnAxis(ac,e)}rotateZ(e){return this.rotateOnAxis(lc,e)}translateOnAxis(e,t){return rc.copy(e).applyQuaternion(this.quaternion),this.position.add(rc.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(oc,e)}translateY(e){return this.translateOnAxis(ac,e)}translateZ(e){return this.translateOnAxis(lc,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Bn.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?pr.copy(e):pr.set(e,t,n);const s=this.parent;this.updateWorldMatrix(!0,!1),Ms.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Bn.lookAt(Ms,pr,this.up):Bn.lookAt(pr,Ms,this.up),this.quaternion.setFromRotationMatrix(Bn),s&&(Bn.extractRotation(s.matrixWorld),Fi.setFromRotationMatrix(Bn),this.quaternion.premultiply(Fi.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(cc),Bi.child=e,this.dispatchEvent(Bi),Bi.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(ef),bo.child=e,this.dispatchEvent(bo),bo.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Bn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Bn.multiply(e.parent.matrixWorld)),e.applyMatrix4(Bn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(cc),Bi.child=e,this.dispatchEvent(Bi),Bi.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){const o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ms,e,Jd),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ms,Qd,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(a=>({...a,boundingBox:a.boundingBox?a.boundingBox.toJSON():void 0,boundingSphere:a.boundingSphere?a.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(a=>({...a})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(e),s.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){const u=l[c];r(e.shapes,u)}else r(e.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(e.materials,this.material[l]));s.material=a}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){const l=this.animations[a];s.animations.push(r(e.animations,l))}}if(t){const a=o(e.geometries),l=o(e.materials),c=o(e.textures),h=o(e.images),u=o(e.shapes),d=o(e.skeletons),f=o(e.animations),g=o(e.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=s,n;function o(a){const l=[];for(const c in a){const h=a[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const s=e.children[n];this.add(s.clone())}return this}}Rt.DEFAULT_UP=new P(0,1,0);Rt.DEFAULT_MATRIX_AUTO_UPDATE=!0;Rt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const xn=new P,zn=new P,wo=new P,kn=new P,zi=new P,ki=new P,hc=new P,Eo=new P,Ao=new P,To=new P,Co=new at,Ro=new at,Po=new at;class pn{constructor(e=new P,t=new P,n=new P){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),xn.subVectors(e,t),s.cross(xn);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,n,s,r){xn.subVectors(s,t),zn.subVectors(n,t),wo.subVectors(e,t);const o=xn.dot(xn),a=xn.dot(zn),l=xn.dot(wo),c=zn.dot(zn),h=zn.dot(wo),u=o*c-a*a;if(u===0)return r.set(0,0,0),null;const d=1/u,f=(c*l-a*h)*d,g=(o*h-a*l)*d;return r.set(1-f-g,g,f)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,kn)===null?!1:kn.x>=0&&kn.y>=0&&kn.x+kn.y<=1}static getInterpolation(e,t,n,s,r,o,a,l){return this.getBarycoord(e,t,n,s,kn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,kn.x),l.addScaledVector(o,kn.y),l.addScaledVector(a,kn.z),l)}static getInterpolatedAttribute(e,t,n,s,r,o){return Co.setScalar(0),Ro.setScalar(0),Po.setScalar(0),Co.fromBufferAttribute(e,t),Ro.fromBufferAttribute(e,n),Po.fromBufferAttribute(e,s),o.setScalar(0),o.addScaledVector(Co,r.x),o.addScaledVector(Ro,r.y),o.addScaledVector(Po,r.z),o}static isFrontFacing(e,t,n,s){return xn.subVectors(n,t),zn.subVectors(e,t),xn.cross(zn).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return xn.subVectors(this.c,this.b),zn.subVectors(this.a,this.b),xn.cross(zn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return pn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return pn.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,s,r){return pn.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}containsPoint(e){return pn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return pn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,s=this.b,r=this.c;let o,a;zi.subVectors(s,n),ki.subVectors(r,n),Eo.subVectors(e,n);const l=zi.dot(Eo),c=ki.dot(Eo);if(l<=0&&c<=0)return t.copy(n);Ao.subVectors(e,s);const h=zi.dot(Ao),u=ki.dot(Ao);if(h>=0&&u<=h)return t.copy(s);const d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return o=l/(l-h),t.copy(n).addScaledVector(zi,o);To.subVectors(e,r);const f=zi.dot(To),g=ki.dot(To);if(g>=0&&f<=g)return t.copy(r);const _=f*c-l*g;if(_<=0&&c>=0&&g<=0)return a=c/(c-g),t.copy(n).addScaledVector(ki,a);const m=h*g-f*u;if(m<=0&&u-h>=0&&f-g>=0)return hc.subVectors(r,s),a=(u-h)/(u-h+(f-g)),t.copy(s).addScaledVector(hc,a);const p=1/(m+_+d);return o=_*p,a=d*p,t.copy(n).addScaledVector(zi,o).addScaledVector(ki,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const kh={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ti={h:0,s:0,l:0},mr={h:0,s:0,l:0};function Lo(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class Oe{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Wt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,ht.colorSpaceToWorking(this,t),this}setRGB(e,t,n,s=ht.workingColorSpace){return this.r=e,this.g=t,this.b=n,ht.colorSpaceToWorking(this,s),this}setHSL(e,t,n,s=ht.workingColorSpace){if(e=_l(e,1),t=We(t,0,1),n=We(n,0,1),t===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+t):n+t-n*t,o=2*n-r;this.r=Lo(o,r,e+1/3),this.g=Lo(o,r,e),this.b=Lo(o,r,e-1/3)}return ht.colorSpaceToWorking(this,s),this}setStyle(e,t=Wt){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r;const o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(r,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Wt){const n=kh[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Xn(e.r),this.g=Xn(e.g),this.b=Xn(e.b),this}copyLinearToSRGB(e){return this.r=ts(e.r),this.g=ts(e.g),this.b=ts(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Wt){return ht.workingToColorSpace(Ht.copy(this),e),Math.round(We(Ht.r*255,0,255))*65536+Math.round(We(Ht.g*255,0,255))*256+Math.round(We(Ht.b*255,0,255))}getHexString(e=Wt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=ht.workingColorSpace){ht.workingToColorSpace(Ht.copy(this),t);const n=Ht.r,s=Ht.g,r=Ht.b,o=Math.max(n,s,r),a=Math.min(n,s,r);let l,c;const h=(a+o)/2;if(a===o)l=0,c=0;else{const u=o-a;switch(c=h<=.5?u/(o+a):u/(2-o-a),o){case n:l=(s-r)/u+(s<r?6:0);break;case s:l=(r-n)/u+2;break;case r:l=(n-s)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=ht.workingColorSpace){return ht.workingToColorSpace(Ht.copy(this),t),e.r=Ht.r,e.g=Ht.g,e.b=Ht.b,e}getStyle(e=Wt){ht.workingToColorSpace(Ht.copy(this),e);const t=Ht.r,n=Ht.g,s=Ht.b;return e!==Wt?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(ti),this.setHSL(ti.h+e,ti.s+t,ti.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(ti),e.getHSL(mr);const n=Us(ti.h,mr.h,t),s=Us(ti.s,mr.s,t),r=Us(ti.l,mr.l,t);return this.setHSL(n,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*n+r[6]*s,this.g=r[1]*t+r[4]*n+r[7]*s,this.b=r[2]*t+r[5]*n+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ht=new Oe;Oe.NAMES=kh;let tf=0;class Ri extends ps{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:tf++}),this.uuid=Dn(),this.name="",this.type="Material",this.blending=es,this.side=jn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=oa,this.blendDst=aa,this.blendEquation=Mi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Oe(0,0,0),this.blendAlpha=0,this.depthFunc=as,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Kl,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Li,this.stencilZFail=Li,this.stencilZPass=Li,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==es&&(n.blending=this.blending),this.side!==jn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==oa&&(n.blendSrc=this.blendSrc),this.blendDst!==aa&&(n.blendDst=this.blendDst),this.blendEquation!==Mi&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==as&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Kl&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Li&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Li&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Li&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){const o=[];for(const a in r){const l=r[a];delete l.metadata,o.push(l)}return o}if(t){const r=s(e.textures),o=s(e.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const s=t.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class mn extends Ri{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Oe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new En,this.combine=cl,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Pt=new P,gr=new ue;let nf=0;class zt{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:nf++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=$a,this.updateRanges=[],this.gpuType=Pn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)gr.fromBufferAttribute(this,t),gr.applyMatrix3(e),this.setXY(t,gr.x,gr.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Pt.fromBufferAttribute(this,t),Pt.applyMatrix3(e),this.setXYZ(t,Pt.x,Pt.y,Pt.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Pt.fromBufferAttribute(this,t),Pt.applyMatrix4(e),this.setXYZ(t,Pt.x,Pt.y,Pt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Pt.fromBufferAttribute(this,t),Pt.applyNormalMatrix(e),this.setXYZ(t,Pt.x,Pt.y,Pt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Pt.fromBufferAttribute(this,t),Pt.transformDirection(e),this.setXYZ(t,Pt.x,Pt.y,Pt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=Mn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=ft(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Mn(t,this.array)),t}setX(e,t){return this.normalized&&(t=ft(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Mn(t,this.array)),t}setY(e,t){return this.normalized&&(t=ft(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Mn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=ft(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Mn(t,this.array)),t}setW(e,t){return this.normalized&&(t=ft(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=ft(t,this.array),n=ft(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=ft(t,this.array),n=ft(n,this.array),s=ft(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e*=this.itemSize,this.normalized&&(t=ft(t,this.array),n=ft(n,this.array),s=ft(s,this.array),r=ft(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==$a&&(e.usage=this.usage),e}}class Vh extends zt{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class Hh extends zt{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class Me extends zt{constructor(e,t,n){super(new Float32Array(e),t,n)}}let sf=0;const dn=new st,Do=new Rt,Vi=new P,an=new cn,Ss=new cn,Ut=new P;class it extends ps{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:sf++}),this.uuid=Dn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Bh(e)?Hh:Vh)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new je().getNormalMatrix(e);n.applyNormalMatrix(r),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return dn.makeRotationFromQuaternion(e),this.applyMatrix4(dn),this}rotateX(e){return dn.makeRotationX(e),this.applyMatrix4(dn),this}rotateY(e){return dn.makeRotationY(e),this.applyMatrix4(dn),this}rotateZ(e){return dn.makeRotationZ(e),this.applyMatrix4(dn),this}translate(e,t,n){return dn.makeTranslation(e,t,n),this.applyMatrix4(dn),this}scale(e,t,n){return dn.makeScale(e,t,n),this.applyMatrix4(dn),this}lookAt(e){return Do.lookAt(e),Do.updateMatrix(),this.applyMatrix4(Do.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Vi).negate(),this.translate(Vi.x,Vi.y,Vi.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let s=0,r=e.length;s<r;s++){const o=e[s];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new Me(n,3))}else{const n=Math.min(e.length,t.count);for(let s=0;s<n;s++){const r=e[s];t.setXYZ(s,r.x,r.y,r.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new cn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new P(-1/0,-1/0,-1/0),new P(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){const r=t[n];an.setFromBufferAttribute(r),this.morphTargetsRelative?(Ut.addVectors(this.boundingBox.min,an.min),this.boundingBox.expandByPoint(Ut),Ut.addVectors(this.boundingBox.max,an.max),this.boundingBox.expandByPoint(Ut)):(this.boundingBox.expandByPoint(an.min),this.boundingBox.expandByPoint(an.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new wn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new P,1/0);return}if(e){const n=this.boundingSphere.center;if(an.setFromBufferAttribute(e),t)for(let r=0,o=t.length;r<o;r++){const a=t[r];Ss.setFromBufferAttribute(a),this.morphTargetsRelative?(Ut.addVectors(an.min,Ss.min),an.expandByPoint(Ut),Ut.addVectors(an.max,Ss.max),an.expandByPoint(Ut)):(an.expandByPoint(Ss.min),an.expandByPoint(Ss.max))}an.getCenter(n);let s=0;for(let r=0,o=e.count;r<o;r++)Ut.fromBufferAttribute(e,r),s=Math.max(s,n.distanceToSquared(Ut));if(t)for(let r=0,o=t.length;r<o;r++){const a=t[r],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)Ut.fromBufferAttribute(a,c),l&&(Vi.fromBufferAttribute(e,c),Ut.add(Vi)),s=Math.max(s,n.distanceToSquared(Ut))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,s=t.normal,r=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new zt(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),a=[],l=[];for(let T=0;T<n.count;T++)a[T]=new P,l[T]=new P;const c=new P,h=new P,u=new P,d=new ue,f=new ue,g=new ue,_=new P,m=new P;function p(T,S,b){c.fromBufferAttribute(n,T),h.fromBufferAttribute(n,S),u.fromBufferAttribute(n,b),d.fromBufferAttribute(r,T),f.fromBufferAttribute(r,S),g.fromBufferAttribute(r,b),h.sub(c),u.sub(c),f.sub(d),g.sub(d);const D=1/(f.x*g.y-g.x*f.y);isFinite(D)&&(_.copy(h).multiplyScalar(g.y).addScaledVector(u,-f.y).multiplyScalar(D),m.copy(u).multiplyScalar(f.x).addScaledVector(h,-g.x).multiplyScalar(D),a[T].add(_),a[S].add(_),a[b].add(_),l[T].add(m),l[S].add(m),l[b].add(m))}let y=this.groups;y.length===0&&(y=[{start:0,count:e.count}]);for(let T=0,S=y.length;T<S;++T){const b=y[T],D=b.start,I=b.count;for(let U=D,B=D+I;U<B;U+=3)p(e.getX(U+0),e.getX(U+1),e.getX(U+2))}const x=new P,v=new P,w=new P,M=new P;function A(T){w.fromBufferAttribute(s,T),M.copy(w);const S=a[T];x.copy(S),x.sub(w.multiplyScalar(w.dot(S))).normalize(),v.crossVectors(M,S);const D=v.dot(l[T])<0?-1:1;o.setXYZW(T,x.x,x.y,x.z,D)}for(let T=0,S=y.length;T<S;++T){const b=y[T],D=b.start,I=b.count;for(let U=D,B=D+I;U<B;U+=3)A(e.getX(U+0)),A(e.getX(U+1)),A(e.getX(U+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new zt(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);const s=new P,r=new P,o=new P,a=new P,l=new P,c=new P,h=new P,u=new P;if(e)for(let d=0,f=e.count;d<f;d+=3){const g=e.getX(d+0),_=e.getX(d+1),m=e.getX(d+2);s.fromBufferAttribute(t,g),r.fromBufferAttribute(t,_),o.fromBufferAttribute(t,m),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),a.fromBufferAttribute(n,g),l.fromBufferAttribute(n,_),c.fromBufferAttribute(n,m),a.add(h),l.add(h),c.add(h),n.setXYZ(g,a.x,a.y,a.z),n.setXYZ(_,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let d=0,f=t.count;d<f;d+=3)s.fromBufferAttribute(t,d+0),r.fromBufferAttribute(t,d+1),o.fromBufferAttribute(t,d+2),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Ut.fromBufferAttribute(e,t),Ut.normalize(),e.setXYZ(t,Ut.x,Ut.y,Ut.z)}toNonIndexed(){function e(a,l){const c=a.array,h=a.itemSize,u=a.normalized,d=new c.constructor(l.length*h);let f=0,g=0;for(let _=0,m=l.length;_<m;_++){a.isInterleavedBufferAttribute?f=l[_]*a.data.stride+a.offset:f=l[_]*h;for(let p=0;p<h;p++)d[g++]=c[f++]}return new zt(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new it,n=this.index.array,s=this.attributes;for(const a in s){const l=s[a],c=e(l,n);t.setAttribute(a,c)}const r=this.morphAttributes;for(const a in r){const l=[],c=r[a];for(let h=0,u=c.length;h<u;h++){const d=c[h],f=e(d,n);l.push(f)}t.morphAttributes[a]=l}t.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,l=o.length;a<l;a++){const c=o[a];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const l in n){const c=n[l];e.data.attributes[l]=c.toJSON(e.data)}const s={};let r=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){const f=c[u];h.push(f.toJSON(e.data))}h.length>0&&(s[l]=h,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(e.data.boundingSphere=a.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const s=e.attributes;for(const c in s){const h=s[c];this.setAttribute(c,h.clone(t))}const r=e.morphAttributes;for(const c in r){const h=[],u=r[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let c=0,h=o.length;c<h;c++){const u=o[c];this.addGroup(u.start,u.count,u.materialIndex)}const a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const uc=new st,pi=new io,vr=new wn,dc=new P,_r=new P,xr=new P,yr=new P,Io=new P,Mr=new P,fc=new P,Sr=new P;class Ne extends Rt{constructor(e=new it,t=new mn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(e,t){const n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(s,e);const a=this.morphTargetInfluences;if(r&&a){Mr.set(0,0,0);for(let l=0,c=r.length;l<c;l++){const h=a[l],u=r[l];h!==0&&(Io.fromBufferAttribute(u,e),o?Mr.addScaledVector(Io,h):Mr.addScaledVector(Io.sub(t),h))}t.add(Mr)}return t}raycast(e,t){const n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),vr.copy(n.boundingSphere),vr.applyMatrix4(r),pi.copy(e.ray).recast(e.near),!(vr.containsPoint(pi.origin)===!1&&(pi.intersectSphere(vr,dc)===null||pi.origin.distanceToSquared(dc)>(e.far-e.near)**2))&&(uc.copy(r).invert(),pi.copy(e.ray).applyMatrix4(uc),!(n.boundingBox!==null&&pi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,pi)))}_computeIntersections(e,t,n){let s;const r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,_=d.length;g<_;g++){const m=d[g],p=o[m.materialIndex],y=Math.max(m.start,f.start),x=Math.min(a.count,Math.min(m.start+m.count,f.start+f.count));for(let v=y,w=x;v<w;v+=3){const M=a.getX(v),A=a.getX(v+1),T=a.getX(v+2);s=br(this,p,e,n,c,h,u,M,A,T),s&&(s.faceIndex=Math.floor(v/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),_=Math.min(a.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){const y=a.getX(m),x=a.getX(m+1),v=a.getX(m+2);s=br(this,o,e,n,c,h,u,y,x,v),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}else if(l!==void 0)if(Array.isArray(o))for(let g=0,_=d.length;g<_;g++){const m=d[g],p=o[m.materialIndex],y=Math.max(m.start,f.start),x=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let v=y,w=x;v<w;v+=3){const M=v,A=v+1,T=v+2;s=br(this,p,e,n,c,h,u,M,A,T),s&&(s.faceIndex=Math.floor(v/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const g=Math.max(0,f.start),_=Math.min(l.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){const y=m,x=m+1,v=m+2;s=br(this,o,e,n,c,h,u,y,x,v),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}}}function rf(i,e,t,n,s,r,o,a){let l;if(e.side===jt?l=n.intersectTriangle(o,r,s,!0,a):l=n.intersectTriangle(s,r,o,e.side===jn,a),l===null)return null;Sr.copy(a),Sr.applyMatrix4(i.matrixWorld);const c=t.ray.origin.distanceTo(Sr);return c<t.near||c>t.far?null:{distance:c,point:Sr.clone(),object:i}}function br(i,e,t,n,s,r,o,a,l,c){i.getVertexPosition(a,_r),i.getVertexPosition(l,xr),i.getVertexPosition(c,yr);const h=rf(i,e,t,n,_r,xr,yr,fc);if(h){const u=new P;pn.getBarycoord(fc,_r,xr,yr,u),s&&(h.uv=pn.getInterpolatedAttribute(s,a,l,c,u,new ue)),r&&(h.uv1=pn.getInterpolatedAttribute(r,a,l,c,u,new ue)),o&&(h.normal=pn.getInterpolatedAttribute(o,a,l,c,u,new P),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const d={a,b:l,c,normal:new P,materialIndex:0};pn.getNormal(_r,xr,yr,d.normal),h.face=d,h.barycoord=u}return h}class ms extends it{constructor(e=1,t=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};const a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);const l=[],c=[],h=[],u=[];let d=0,f=0;g("z","y","x",-1,-1,n,t,e,o,r,0),g("z","y","x",1,-1,n,t,-e,o,r,1),g("x","z","y",1,1,e,n,t,s,o,2),g("x","z","y",1,-1,e,n,-t,s,o,3),g("x","y","z",1,-1,e,t,n,s,r,4),g("x","y","z",-1,-1,e,t,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new Me(c,3)),this.setAttribute("normal",new Me(h,3)),this.setAttribute("uv",new Me(u,2));function g(_,m,p,y,x,v,w,M,A,T,S){const b=v/A,D=w/T,I=v/2,U=w/2,B=M/2,k=A+1,V=T+1;let te=0,H=0;const Q=new P;for(let re=0;re<V;re++){const ge=re*D-U;for(let xe=0;xe<k;xe++){const Qe=xe*b-I;Q[_]=Qe*y,Q[m]=ge*x,Q[p]=B,c.push(Q.x,Q.y,Q.z),Q[_]=0,Q[m]=0,Q[p]=M>0?1:-1,h.push(Q.x,Q.y,Q.z),u.push(xe/A),u.push(1-re/T),te+=1}}for(let re=0;re<T;re++)for(let ge=0;ge<A;ge++){const xe=d+ge+k*re,Qe=d+ge+k*(re+1),ot=d+(ge+1)+k*(re+1),qe=d+(ge+1)+k*re;l.push(xe,Qe,qe),l.push(Qe,ot,qe),H+=6}a.addGroup(f,H,S),f+=H,d+=te}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ms(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function us(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const s=i[t][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone():Array.isArray(s)?e[t][n]=s.slice():e[t][n]=s}}return e}function Yt(i){const e={};for(let t=0;t<i.length;t++){const n=us(i[t]);for(const s in n)e[s]=n[s]}return e}function of(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function Gh(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:ht.workingColorSpace}const Ml={clone:us,merge:Yt};var af=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,lf=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class nn extends Ri{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=af,this.fragmentShader=lf,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=us(e.uniforms),this.uniformsGroups=of(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const o=this.uniforms[s].value;o&&o.isTexture?t.uniforms[s]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[s]={type:"m4",value:o.toArray()}:t.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class Wh extends Rt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new st,this.projectionMatrix=new st,this.projectionMatrixInverse=new st,this.coordinateSystem=Ln,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const ni=new P,pc=new ue,mc=new ue;class fn extends Wh{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Ws*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Is*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Ws*2*Math.atan(Math.tan(Is*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){ni.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(ni.x,ni.y).multiplyScalar(-e/ni.z),ni.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(ni.x,ni.y).multiplyScalar(-e/ni.z)}getViewSize(e,t){return this.getViewBounds(e,pc,mc),t.subVectors(mc,pc)}setViewOffset(e,t,n,s,r,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(Is*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,r=-.5*s;const o=this.view;if(this.view!==null&&this.view.enabled){const l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*s/l,t-=o.offsetY*n/c,s*=o.width/l,n*=o.height/c}const a=this.filmOffset;a!==0&&(r+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const Hi=-90,Gi=1;class cf extends Rt{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new fn(Hi,Gi,e,t);s.layers=this.layers,this.add(s);const r=new fn(Hi,Gi,e,t);r.layers=this.layers,this.add(r);const o=new fn(Hi,Gi,e,t);o.layers=this.layers,this.add(o);const a=new fn(Hi,Gi,e,t);a.layers=this.layers,this.add(a);const l=new fn(Hi,Gi,e,t);l.layers=this.layers,this.add(l);const c=new fn(Hi,Gi,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,s,r,o,a,l]=t;for(const c of t)this.remove(c);if(e===Ln)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===Kr)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[r,o,a,l,c,h]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const _=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,s),e.render(t,r),e.setRenderTarget(n,1,s),e.render(t,o),e.setRenderTarget(n,2,s),e.render(t,a),e.setRenderTarget(n,3,s),e.render(t,l),e.setRenderTarget(n,4,s),e.render(t,c),n.texture.generateMipmaps=_,e.setRenderTarget(n,5,s),e.render(t,h),e.setRenderTarget(u,d,f),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class Xh extends Xt{constructor(e=[],t=ls,n,s,r,o,a,l,c,h){super(e,t,n,s,r,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class hf extends Ti{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];this.texture=new Xh(s),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new ms(5,5,5),r=new nn({name:"CubemapFromEquirect",uniforms:us(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:jt,blending:li});r.uniforms.tEquirect.value=t;const o=new Ne(s,r),a=t.minFilter;return t.minFilter===oi&&(t.minFilter=Sn),new cf(1,10,this).update(e,o),t.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,t=!0,n=!0,s=!0){const r=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,s);e.setRenderTarget(r)}}class rt extends Rt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const uf={type:"move"};class Uo{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new rt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new rt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new P,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new P),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new rt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new P,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new P),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,r=null,o=null;const a=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){o=!0;for(const _ of e.hand.values()){const m=t.getJointPose(_,n),p=this._getHandJoint(c,_);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,g=.005;c.inputState.pinching&&d>f+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&d<=f-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(uf)))}return a!==null&&(a.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new rt;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}class Sl{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new Oe(e),this.density=t}clone(){return new Sl(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class df extends Rt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new En,this.environmentIntensity=1,this.environmentRotation=new En,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class ff{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=$a,this.updateRanges=[],this.version=0,this.uuid=Dn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let s=0,r=this.stride;s<r;s++)this.array[e+s]=t.array[n+s];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Dn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Dn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const qt=new P;class ai{constructor(e,t,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)qt.fromBufferAttribute(this,t),qt.applyMatrix4(e),this.setXYZ(t,qt.x,qt.y,qt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)qt.fromBufferAttribute(this,t),qt.applyNormalMatrix(e),this.setXYZ(t,qt.x,qt.y,qt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)qt.fromBufferAttribute(this,t),qt.transformDirection(e),this.setXYZ(t,qt.x,qt.y,qt.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=Mn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=ft(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=ft(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=ft(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=ft(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=ft(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=Mn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=Mn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=Mn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=Mn(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=ft(t,this.array),n=ft(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=ft(t,this.array),n=ft(n,this.array),s=ft(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=ft(t,this.array),n=ft(n,this.array),s=ft(s,this.array),r=ft(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this.data.array[e+3]=r,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return new zt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new ai(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}const wr=new P,gc=new P;class pf extends Rt{constructor(){super(),this.isLOD=!0,this._currentLevel=0,this.type="LOD",Object.defineProperties(this,{levels:{enumerable:!0,value:[]}}),this.autoUpdate=!0}copy(e){super.copy(e,!1);const t=e.levels;for(let n=0,s=t.length;n<s;n++){const r=t[n];this.addLevel(r.object.clone(),r.distance,r.hysteresis)}return this.autoUpdate=e.autoUpdate,this}addLevel(e,t=0,n=0){t=Math.abs(t);const s=this.levels;let r;for(r=0;r<s.length&&!(t<s[r].distance);r++);return s.splice(r,0,{distance:t,hysteresis:n,object:e}),this.add(e),this}removeLevel(e){const t=this.levels;for(let n=0;n<t.length;n++)if(t[n].distance===e){const s=t.splice(n,1);return this.remove(s[0].object),!0}return!1}getCurrentLevel(){return this._currentLevel}getObjectForDistance(e){const t=this.levels;if(t.length>0){let n,s;for(n=1,s=t.length;n<s;n++){let r=t[n].distance;if(t[n].object.visible&&(r-=r*t[n].hysteresis),e<r)break}return t[n-1].object}return null}raycast(e,t){if(this.levels.length>0){wr.setFromMatrixPosition(this.matrixWorld);const s=e.ray.origin.distanceTo(wr);this.getObjectForDistance(s).raycast(e,t)}}update(e){const t=this.levels;if(t.length>1){wr.setFromMatrixPosition(e.matrixWorld),gc.setFromMatrixPosition(this.matrixWorld);const n=wr.distanceTo(gc)/e.zoom;t[0].object.visible=!0;let s,r;for(s=1,r=t.length;s<r;s++){let o=t[s].distance;if(t[s].object.visible&&(o-=o*t[s].hysteresis),n>=o)t[s-1].object.visible=!1,t[s].object.visible=!0;else break}for(this._currentLevel=s-1;s<r;s++)t[s].object.visible=!1}}toJSON(e){const t=super.toJSON(e);this.autoUpdate===!1&&(t.object.autoUpdate=!1),t.object.levels=[];const n=this.levels;for(let s=0,r=n.length;s<r;s++){const o=n[s];t.object.levels.push({object:o.object.uuid,distance:o.distance,hysteresis:o.hysteresis})}return t}}class $h extends Xt{constructor(e=null,t=1,n=1,s,r,o,a,l,c=tn,h=tn,u,d){super(null,o,a,l,c,h,s,r,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class vc extends zt{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const Wi=new st,_c=new st,Er=[],xc=new cn,mf=new st,bs=new Ne,ws=new wn;class qa extends Ne{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new vc(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,mf)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new cn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Wi),xc.copy(e.boundingBox).applyMatrix4(Wi),this.boundingBox.union(xc)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new wn),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Wi),ws.copy(e.boundingSphere).applyMatrix4(Wi),this.boundingSphere.union(ws)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const n=t.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,o=e*r+1;for(let a=0;a<n.length;a++)n[a]=s[o+a]}raycast(e,t){const n=this.matrixWorld,s=this.count;if(bs.geometry=this.geometry,bs.material=this.material,bs.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),ws.copy(this.boundingSphere),ws.applyMatrix4(n),e.ray.intersectsSphere(ws)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Wi),_c.multiplyMatrices(n,Wi),bs.matrixWorld=_c,bs.raycast(e,Er);for(let o=0,a=Er.length;o<a;o++){const l=Er[o];l.instanceId=r,l.object=this,t.push(l)}Er.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new vc(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}setMorphAt(e,t){const n=t.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new $h(new Float32Array(s*this.count),s,this.count,fl,Pn));const r=this.morphTexture.source.data.data;let o=0;for(let c=0;c<n.length;c++)o+=n[c];const a=this.geometry.morphTargetsRelative?1:1-o,l=s*e;r[l]=a,r.set(n,l+1)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const No=new P,gf=new P,vf=new je;class xi{constructor(e=new P(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const s=No.subVectors(n,t).cross(gf.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(No),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:t.copy(e.start).addScaledVector(n,r)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||vf.getNormalMatrix(e),s=this.coplanarPoint(No).applyMatrix4(e),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const mi=new wn,_f=new ue(.5,.5),Ar=new P;class bl{constructor(e=new xi,t=new xi,n=new xi,s=new xi,r=new xi,o=new xi){this.planes=[e,t,n,s,r,o]}set(e,t,n,s,r,o){const a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=Ln,n=!1){const s=this.planes,r=e.elements,o=r[0],a=r[1],l=r[2],c=r[3],h=r[4],u=r[5],d=r[6],f=r[7],g=r[8],_=r[9],m=r[10],p=r[11],y=r[12],x=r[13],v=r[14],w=r[15];if(s[0].setComponents(c-o,f-h,p-g,w-y).normalize(),s[1].setComponents(c+o,f+h,p+g,w+y).normalize(),s[2].setComponents(c+a,f+u,p+_,w+x).normalize(),s[3].setComponents(c-a,f-u,p-_,w-x).normalize(),n)s[4].setComponents(l,d,m,v).normalize(),s[5].setComponents(c-l,f-d,p-m,w-v).normalize();else if(s[4].setComponents(c-l,f-d,p-m,w-v).normalize(),t===Ln)s[5].setComponents(c+l,f+d,p+m,w+v).normalize();else if(t===Kr)s[5].setComponents(l,d,m,v).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),mi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),mi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(mi)}intersectsSprite(e){mi.center.set(0,0,0);const t=_f.distanceTo(e.center);return mi.radius=.7071067811865476+t,mi.applyMatrix4(e.matrixWorld),this.intersectsSphere(mi)}intersectsSphere(e){const t=this.planes,n=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const s=t[n];if(Ar.x=s.normal.x>0?e.max.x:e.min.x,Ar.y=s.normal.y>0?e.max.y:e.min.y,Ar.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(Ar)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class wl extends Ri{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Oe(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const Zr=new P,Jr=new P,yc=new st,Es=new io,Tr=new wn,Oo=new P,Mc=new P;class xf extends Rt{constructor(e=new it,t=new wl){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let s=1,r=t.count;s<r;s++)Zr.fromBufferAttribute(t,s-1),Jr.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=Zr.distanceTo(Jr);e.setAttribute("lineDistance",new Me(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const n=this.geometry,s=this.matrixWorld,r=e.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Tr.copy(n.boundingSphere),Tr.applyMatrix4(s),Tr.radius+=r,e.ray.intersectsSphere(Tr)===!1)return;yc.copy(s).invert(),Es.copy(e.ray).applyMatrix4(yc);const a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=this.isLineSegments?2:1,h=n.index,d=n.attributes.position;if(h!==null){const f=Math.max(0,o.start),g=Math.min(h.count,o.start+o.count);for(let _=f,m=g-1;_<m;_+=c){const p=h.getX(_),y=h.getX(_+1),x=Cr(this,e,Es,l,p,y,_);x&&t.push(x)}if(this.isLineLoop){const _=h.getX(g-1),m=h.getX(f),p=Cr(this,e,Es,l,_,m,g-1);p&&t.push(p)}}else{const f=Math.max(0,o.start),g=Math.min(d.count,o.start+o.count);for(let _=f,m=g-1;_<m;_+=c){const p=Cr(this,e,Es,l,_,_+1,_);p&&t.push(p)}if(this.isLineLoop){const _=Cr(this,e,Es,l,g-1,f,g-1);_&&t.push(_)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}}function Cr(i,e,t,n,s,r,o){const a=i.geometry.attributes.position;if(Zr.fromBufferAttribute(a,s),Jr.fromBufferAttribute(a,r),t.distanceSqToSegment(Zr,Jr,Oo,Mc)>n)return;Oo.applyMatrix4(i.matrixWorld);const c=e.ray.origin.distanceTo(Oo);if(!(c<e.near||c>e.far))return{distance:c,point:Mc.clone().applyMatrix4(i.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:i}}const Sc=new P,bc=new P;class qh extends xf{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let s=0,r=t.count;s<r;s+=2)Sc.fromBufferAttribute(t,s),bc.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Sc.distanceTo(bc);e.setAttribute("lineDistance",new Me(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Yh extends Xt{constructor(e,t,n=Ai,s,r,o,a=tn,l=tn,c,h=Hs,u=1){if(h!==Hs&&h!==Gs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const d={width:e,height:t,depth:u};super(d,s,r,o,a,l,h,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new xl(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class jh extends Xt{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class El extends it{constructor(e=1,t=1,n=4,s=8,r=1){super(),this.type="CapsuleGeometry",this.parameters={radius:e,height:t,capSegments:n,radialSegments:s,heightSegments:r},t=Math.max(0,t),n=Math.max(1,Math.floor(n)),s=Math.max(3,Math.floor(s)),r=Math.max(1,Math.floor(r));const o=[],a=[],l=[],c=[],h=t/2,u=Math.PI/2*e,d=t,f=2*u+d,g=n*2+r,_=s+1,m=new P,p=new P;for(let y=0;y<=g;y++){let x=0,v=0,w=0,M=0;if(y<=n){const S=y/n,b=S*Math.PI/2;v=-h-e*Math.cos(b),w=e*Math.sin(b),M=-e*Math.cos(b),x=S*u}else if(y<=n+r){const S=(y-n)/r;v=-h+S*t,w=e,M=0,x=u+S*d}else{const S=(y-n-r)/n,b=S*Math.PI/2;v=h+e*Math.sin(b),w=e*Math.cos(b),M=e*Math.sin(b),x=u+d+S*u}const A=Math.max(0,Math.min(1,x/f));let T=0;y===0?T=.5/s:y===g&&(T=-.5/s);for(let S=0;S<=s;S++){const b=S/s,D=b*Math.PI*2,I=Math.sin(D),U=Math.cos(D);p.x=-w*U,p.y=v,p.z=w*I,a.push(p.x,p.y,p.z),m.set(-w*U,M,w*I),m.normalize(),l.push(m.x,m.y,m.z),c.push(b+T,A)}if(y>0){const S=(y-1)*_;for(let b=0;b<s;b++){const D=S+b,I=S+b+1,U=y*_+b,B=y*_+b+1;o.push(D,I,U),o.push(I,B,U)}}}this.setIndex(o),this.setAttribute("position",new Me(a,3)),this.setAttribute("normal",new Me(l,3)),this.setAttribute("uv",new Me(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new El(e.radius,e.height,e.capSegments,e.radialSegments,e.heightSegments)}}class nr extends it{constructor(e=1,t=1,n=1,s=32,r=1,o=!1,a=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:l};const c=this;s=Math.floor(s),r=Math.floor(r);const h=[],u=[],d=[],f=[];let g=0;const _=[],m=n/2;let p=0;y(),o===!1&&(e>0&&x(!0),t>0&&x(!1)),this.setIndex(h),this.setAttribute("position",new Me(u,3)),this.setAttribute("normal",new Me(d,3)),this.setAttribute("uv",new Me(f,2));function y(){const v=new P,w=new P;let M=0;const A=(t-e)/n;for(let T=0;T<=r;T++){const S=[],b=T/r,D=b*(t-e)+e;for(let I=0;I<=s;I++){const U=I/s,B=U*l+a,k=Math.sin(B),V=Math.cos(B);w.x=D*k,w.y=-b*n+m,w.z=D*V,u.push(w.x,w.y,w.z),v.set(k,A,V).normalize(),d.push(v.x,v.y,v.z),f.push(U,1-b),S.push(g++)}_.push(S)}for(let T=0;T<s;T++)for(let S=0;S<r;S++){const b=_[S][T],D=_[S+1][T],I=_[S+1][T+1],U=_[S][T+1];(e>0||S!==0)&&(h.push(b,D,U),M+=3),(t>0||S!==r-1)&&(h.push(D,I,U),M+=3)}c.addGroup(p,M,0),p+=M}function x(v){const w=g,M=new ue,A=new P;let T=0;const S=v===!0?e:t,b=v===!0?1:-1;for(let I=1;I<=s;I++)u.push(0,m*b,0),d.push(0,b,0),f.push(.5,.5),g++;const D=g;for(let I=0;I<=s;I++){const B=I/s*l+a,k=Math.cos(B),V=Math.sin(B);A.x=S*V,A.y=m*b,A.z=S*k,u.push(A.x,A.y,A.z),d.push(0,b,0),M.x=k*.5+.5,M.y=V*.5*b+.5,f.push(M.x,M.y),g++}for(let I=0;I<s;I++){const U=w+I,B=D+I;v===!0?h.push(B,B+1,U):h.push(B+1,B,U),T+=3}c.addGroup(p,T,v===!0?1:2),p+=T}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new nr(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class so extends it{constructor(e=[],t=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:s};const r=[],o=[];a(s),c(n),h(),this.setAttribute("position",new Me(r,3)),this.setAttribute("normal",new Me(r.slice(),3)),this.setAttribute("uv",new Me(o,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function a(y){const x=new P,v=new P,w=new P;for(let M=0;M<t.length;M+=3)f(t[M+0],x),f(t[M+1],v),f(t[M+2],w),l(x,v,w,y)}function l(y,x,v,w){const M=w+1,A=[];for(let T=0;T<=M;T++){A[T]=[];const S=y.clone().lerp(v,T/M),b=x.clone().lerp(v,T/M),D=M-T;for(let I=0;I<=D;I++)I===0&&T===M?A[T][I]=S:A[T][I]=S.clone().lerp(b,I/D)}for(let T=0;T<M;T++)for(let S=0;S<2*(M-T)-1;S++){const b=Math.floor(S/2);S%2===0?(d(A[T][b+1]),d(A[T+1][b]),d(A[T][b])):(d(A[T][b+1]),d(A[T+1][b+1]),d(A[T+1][b]))}}function c(y){const x=new P;for(let v=0;v<r.length;v+=3)x.x=r[v+0],x.y=r[v+1],x.z=r[v+2],x.normalize().multiplyScalar(y),r[v+0]=x.x,r[v+1]=x.y,r[v+2]=x.z}function h(){const y=new P;for(let x=0;x<r.length;x+=3){y.x=r[x+0],y.y=r[x+1],y.z=r[x+2];const v=m(y)/2/Math.PI+.5,w=p(y)/Math.PI+.5;o.push(v,1-w)}g(),u()}function u(){for(let y=0;y<o.length;y+=6){const x=o[y+0],v=o[y+2],w=o[y+4],M=Math.max(x,v,w),A=Math.min(x,v,w);M>.9&&A<.1&&(x<.2&&(o[y+0]+=1),v<.2&&(o[y+2]+=1),w<.2&&(o[y+4]+=1))}}function d(y){r.push(y.x,y.y,y.z)}function f(y,x){const v=y*3;x.x=e[v+0],x.y=e[v+1],x.z=e[v+2]}function g(){const y=new P,x=new P,v=new P,w=new P,M=new ue,A=new ue,T=new ue;for(let S=0,b=0;S<r.length;S+=9,b+=6){y.set(r[S+0],r[S+1],r[S+2]),x.set(r[S+3],r[S+4],r[S+5]),v.set(r[S+6],r[S+7],r[S+8]),M.set(o[b+0],o[b+1]),A.set(o[b+2],o[b+3]),T.set(o[b+4],o[b+5]),w.copy(y).add(x).add(v).divideScalar(3);const D=m(w);_(M,b+0,y,D),_(A,b+2,x,D),_(T,b+4,v,D)}}function _(y,x,v,w){w<0&&y.x===1&&(o[x]=y.x-1),v.x===0&&v.z===0&&(o[x]=w/2/Math.PI+.5)}function m(y){return Math.atan2(y.z,-y.x)}function p(y){return Math.atan2(-y.y,Math.sqrt(y.x*y.x+y.z*y.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new so(e.vertices,e.indices,e.radius,e.details)}}class Al extends so{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,s=1/n,r=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],o=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(r,o,e,t),this.type="DodecahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new Al(e.radius,e.detail)}}class Un{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){console.warn("THREE.Curve: .getPoint() not implemented.")}getPointAt(e,t){const n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let n,s=this.getPoint(0),r=0;t.push(0);for(let o=1;o<=e;o++)n=this.getPoint(o/e),r+=n.distanceTo(s),t.push(r),s=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const n=this.getLengths();let s=0;const r=n.length;let o;t?o=t:o=e*n[r-1];let a=0,l=r-1,c;for(;a<=l;)if(s=Math.floor(a+(l-a)/2),c=n[s]-o,c<0)a=s+1;else if(c>0)l=s-1;else{l=s;break}if(s=l,n[s]===o)return s/(r-1);const h=n[s],d=n[s+1]-h,f=(o-h)/d;return(s+f)/(r-1)}getTangent(e,t){let s=e-1e-4,r=e+1e-4;s<0&&(s=0),r>1&&(r=1);const o=this.getPoint(s),a=this.getPoint(r),l=t||(o.isVector2?new ue:new P);return l.copy(a).sub(o).normalize(),l}getTangentAt(e,t){const n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t=!1){const n=new P,s=[],r=[],o=[],a=new P,l=new st;for(let f=0;f<=e;f++){const g=f/e;s[f]=this.getTangentAt(g,new P)}r[0]=new P,o[0]=new P;let c=Number.MAX_VALUE;const h=Math.abs(s[0].x),u=Math.abs(s[0].y),d=Math.abs(s[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),a.crossVectors(s[0],n).normalize(),r[0].crossVectors(s[0],a),o[0].crossVectors(s[0],r[0]);for(let f=1;f<=e;f++){if(r[f]=r[f-1].clone(),o[f]=o[f-1].clone(),a.crossVectors(s[f-1],s[f]),a.length()>Number.EPSILON){a.normalize();const g=Math.acos(We(s[f-1].dot(s[f]),-1,1));r[f].applyMatrix4(l.makeRotationAxis(a,g))}o[f].crossVectors(s[f],r[f])}if(t===!0){let f=Math.acos(We(r[0].dot(r[e]),-1,1));f/=e,s[0].dot(a.crossVectors(r[0],r[e]))>0&&(f=-f);for(let g=1;g<=e;g++)r[g].applyMatrix4(l.makeRotationAxis(s[g],f*g)),o[g].crossVectors(s[g],r[g])}return{tangents:s,normals:r,binormals:o}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class Tl extends Un{constructor(e=0,t=0,n=1,s=1,r=0,o=Math.PI*2,a=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=n,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=o,this.aClockwise=a,this.aRotation=l}getPoint(e,t=new ue){const n=t,s=Math.PI*2;let r=this.aEndAngle-this.aStartAngle;const o=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(o?r=0:r=s),this.aClockwise===!0&&!o&&(r===s?r=-s:r=r-s);const a=this.aStartAngle+e*r;let l=this.aX+this.xRadius*Math.cos(a),c=this.aY+this.yRadius*Math.sin(a);if(this.aRotation!==0){const h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,f=c-this.aY;l=d*h-f*u+this.aX,c=d*u+f*h+this.aY}return n.set(l,c)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class yf extends Tl{constructor(e,t,n,s,r,o){super(e,t,n,n,s,r,o),this.isArcCurve=!0,this.type="ArcCurve"}}function Cl(){let i=0,e=0,t=0,n=0;function s(r,o,a,l){i=r,e=a,t=-3*r+3*o-2*a-l,n=2*r-2*o+a+l}return{initCatmullRom:function(r,o,a,l,c){s(o,a,c*(a-r),c*(l-o))},initNonuniformCatmullRom:function(r,o,a,l,c,h,u){let d=(o-r)/c-(a-r)/(c+h)+(a-o)/h,f=(a-o)/h-(l-o)/(h+u)+(l-a)/u;d*=h,f*=h,s(o,a,d,f)},calc:function(r){const o=r*r,a=o*r;return i+e*r+t*o+n*a}}}const Rr=new P,Fo=new Cl,Bo=new Cl,zo=new Cl;class qs extends Un{constructor(e=[],t=!1,n="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=n,this.tension=s}getPoint(e,t=new P){const n=t,s=this.points,r=s.length,o=(r-(this.closed?0:1))*e;let a=Math.floor(o),l=o-a;this.closed?a+=a>0?0:(Math.floor(Math.abs(a)/r)+1)*r:l===0&&a===r-1&&(a=r-2,l=1);let c,h;this.closed||a>0?c=s[(a-1)%r]:(Rr.subVectors(s[0],s[1]).add(s[0]),c=Rr);const u=s[a%r],d=s[(a+1)%r];if(this.closed||a+2<r?h=s[(a+2)%r]:(Rr.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=Rr),this.curveType==="centripetal"||this.curveType==="chordal"){const f=this.curveType==="chordal"?.5:.25;let g=Math.pow(c.distanceToSquared(u),f),_=Math.pow(u.distanceToSquared(d),f),m=Math.pow(d.distanceToSquared(h),f);_<1e-4&&(_=1),g<1e-4&&(g=_),m<1e-4&&(m=_),Fo.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,g,_,m),Bo.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,g,_,m),zo.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,g,_,m)}else this.curveType==="catmullrom"&&(Fo.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),Bo.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),zo.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return n.set(Fo.calc(l),Bo.calc(l),zo.calc(l)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(s.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const s=this.points[t];e.points.push(s.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(new P().fromArray(s))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function wc(i,e,t,n,s){const r=(n-e)*.5,o=(s-t)*.5,a=i*i,l=i*a;return(2*t-2*n+r+o)*l+(-3*t+3*n-2*r-o)*a+r*i+t}function Mf(i,e){const t=1-i;return t*t*e}function Sf(i,e){return 2*(1-i)*i*e}function bf(i,e){return i*i*e}function Ns(i,e,t,n){return Mf(i,e)+Sf(i,t)+bf(i,n)}function wf(i,e){const t=1-i;return t*t*t*e}function Ef(i,e){const t=1-i;return 3*t*t*i*e}function Af(i,e){return 3*(1-i)*i*i*e}function Tf(i,e){return i*i*i*e}function Os(i,e,t,n,s){return wf(i,e)+Ef(i,t)+Af(i,n)+Tf(i,s)}class Kh extends Un{constructor(e=new ue,t=new ue,n=new ue,s=new ue){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new ue){const n=t,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(Os(e,s.x,r.x,o.x,a.x),Os(e,s.y,r.y,o.y,a.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class Cf extends Un{constructor(e=new P,t=new P,n=new P,s=new P){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new P){const n=t,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(Os(e,s.x,r.x,o.x,a.x),Os(e,s.y,r.y,o.y,a.y),Os(e,s.z,r.z,o.z,a.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class Zh extends Un{constructor(e=new ue,t=new ue){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new ue){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new ue){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Rf extends Un{constructor(e=new P,t=new P){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new P){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new P){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Jh extends Un{constructor(e=new ue,t=new ue,n=new ue){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new ue){const n=t,s=this.v0,r=this.v1,o=this.v2;return n.set(Ns(e,s.x,r.x,o.x),Ns(e,s.y,r.y,o.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Qh extends Un{constructor(e=new P,t=new P,n=new P){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new P){const n=t,s=this.v0,r=this.v1,o=this.v2;return n.set(Ns(e,s.x,r.x,o.x),Ns(e,s.y,r.y,o.y),Ns(e,s.z,r.z,o.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class eu extends Un{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new ue){const n=t,s=this.points,r=(s.length-1)*e,o=Math.floor(r),a=r-o,l=s[o===0?o:o-1],c=s[o],h=s[o>s.length-2?s.length-1:o+1],u=s[o>s.length-3?s.length-1:o+2];return n.set(wc(a,l.x,c.x,h.x,u.x),wc(a,l.y,c.y,h.y,u.y)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const s=this.points[t];e.points.push(s.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const s=e.points[t];this.points.push(new ue().fromArray(s))}return this}}var Qr=Object.freeze({__proto__:null,ArcCurve:yf,CatmullRomCurve3:qs,CubicBezierCurve:Kh,CubicBezierCurve3:Cf,EllipseCurve:Tl,LineCurve:Zh,LineCurve3:Rf,QuadraticBezierCurve:Jh,QuadraticBezierCurve3:Qh,SplineCurve:eu});class Pf extends Un{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){const n=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Qr[n](t,e))}return this}getPoint(e,t){const n=e*this.getLength(),s=this.getCurveLengths();let r=0;for(;r<s.length;){if(s[r]>=n){const o=s[r]-n,a=this.curves[r],l=a.getLength(),c=l===0?0:1-o/l;return a.getPointAt(c,t)}r++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let t=0;for(let n=0,s=this.curves.length;n<s;n++)t+=this.curves[n].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){const t=[];let n;for(let s=0,r=this.curves;s<r.length;s++){const o=r[s],a=o.isEllipseCurve?e*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?e*o.points.length:e,l=o.getPoints(a);for(let c=0;c<l.length;c++){const h=l[c];n&&n.equals(h)||(t.push(h),n=h)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const s=e.curves[t];this.curves.push(s.clone())}return this.autoClose=e.autoClose,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,n=this.curves.length;t<n;t++){const s=this.curves[t];e.curves.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const s=e.curves[t];this.curves.push(new Qr[s.type]().fromJSON(s))}return this}}class Ec extends Pf{constructor(e){super(),this.type="Path",this.currentPoint=new ue,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,n=e.length;t<n;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){const n=new Zh(this.currentPoint.clone(),new ue(e,t));return this.curves.push(n),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,n,s){const r=new Jh(this.currentPoint.clone(),new ue(e,t),new ue(n,s));return this.curves.push(r),this.currentPoint.set(n,s),this}bezierCurveTo(e,t,n,s,r,o){const a=new Kh(this.currentPoint.clone(),new ue(e,t),new ue(n,s),new ue(r,o));return this.curves.push(a),this.currentPoint.set(r,o),this}splineThru(e){const t=[this.currentPoint.clone()].concat(e),n=new eu(t);return this.curves.push(n),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,n,s,r,o){const a=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(e+a,t+l,n,s,r,o),this}absarc(e,t,n,s,r,o){return this.absellipse(e,t,n,n,s,r,o),this}ellipse(e,t,n,s,r,o,a,l){const c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(e+c,t+h,n,s,r,o,a,l),this}absellipse(e,t,n,s,r,o,a,l){const c=new Tl(e,t,n,s,r,o,a,l);if(this.curves.length>0){const u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);const h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class ir extends Ec{constructor(e){super(e),this.uuid=Dn(),this.type="Shape",this.holes=[]}getPointsHoles(e){const t=[];for(let n=0,s=this.holes.length;n<s;n++)t[n]=this.holes[n].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const s=e.holes[t];this.holes.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,n=this.holes.length;t<n;t++){const s=this.holes[t];e.holes.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const s=e.holes[t];this.holes.push(new Ec().fromJSON(s))}return this}}function Lf(i,e,t=2){const n=e&&e.length,s=n?e[0]*t:i.length;let r=tu(i,0,s,t,!0);const o=[];if(!r||r.next===r.prev)return o;let a,l,c;if(n&&(r=Of(i,e,r,t)),i.length>80*t){a=1/0,l=1/0;let h=-1/0,u=-1/0;for(let d=t;d<s;d+=t){const f=i[d],g=i[d+1];f<a&&(a=f),g<l&&(l=g),f>h&&(h=f),g>u&&(u=g)}c=Math.max(h-a,u-l),c=c!==0?32767/c:0}return Ys(r,o,t,a,l,c,0),o}function tu(i,e,t,n,s){let r;if(s===qf(i,e,t,n)>0)for(let o=e;o<t;o+=n)r=Ac(o/n|0,i[o],i[o+1],r);else for(let o=t-n;o>=e;o-=n)r=Ac(o/n|0,i[o],i[o+1],r);return r&&ds(r,r.next)&&(Ks(r),r=r.next),r}function Ci(i,e){if(!i)return i;e||(e=i);let t=i,n;do if(n=!1,!t.steiner&&(ds(t,t.next)||Et(t.prev,t,t.next)===0)){if(Ks(t),t=e=t.prev,t===t.next)break;n=!0}else t=t.next;while(n||t!==e);return e}function Ys(i,e,t,n,s,r,o){if(!i)return;!o&&r&&Vf(i,n,s,r);let a=i;for(;i.prev!==i.next;){const l=i.prev,c=i.next;if(r?If(i,n,s,r):Df(i)){e.push(l.i,i.i,c.i),Ks(i),i=c.next,a=c.next;continue}if(i=c,i===a){o?o===1?(i=Uf(Ci(i),e),Ys(i,e,t,n,s,r,2)):o===2&&Nf(i,e,t,n,s,r):Ys(Ci(i),e,t,n,s,r,1);break}}}function Df(i){const e=i.prev,t=i,n=i.next;if(Et(e,t,n)>=0)return!1;const s=e.x,r=t.x,o=n.x,a=e.y,l=t.y,c=n.y,h=Math.min(s,r,o),u=Math.min(a,l,c),d=Math.max(s,r,o),f=Math.max(a,l,c);let g=n.next;for(;g!==e;){if(g.x>=h&&g.x<=d&&g.y>=u&&g.y<=f&&Rs(s,a,r,l,o,c,g.x,g.y)&&Et(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function If(i,e,t,n){const s=i.prev,r=i,o=i.next;if(Et(s,r,o)>=0)return!1;const a=s.x,l=r.x,c=o.x,h=s.y,u=r.y,d=o.y,f=Math.min(a,l,c),g=Math.min(h,u,d),_=Math.max(a,l,c),m=Math.max(h,u,d),p=Ya(f,g,e,t,n),y=Ya(_,m,e,t,n);let x=i.prevZ,v=i.nextZ;for(;x&&x.z>=p&&v&&v.z<=y;){if(x.x>=f&&x.x<=_&&x.y>=g&&x.y<=m&&x!==s&&x!==o&&Rs(a,h,l,u,c,d,x.x,x.y)&&Et(x.prev,x,x.next)>=0||(x=x.prevZ,v.x>=f&&v.x<=_&&v.y>=g&&v.y<=m&&v!==s&&v!==o&&Rs(a,h,l,u,c,d,v.x,v.y)&&Et(v.prev,v,v.next)>=0))return!1;v=v.nextZ}for(;x&&x.z>=p;){if(x.x>=f&&x.x<=_&&x.y>=g&&x.y<=m&&x!==s&&x!==o&&Rs(a,h,l,u,c,d,x.x,x.y)&&Et(x.prev,x,x.next)>=0)return!1;x=x.prevZ}for(;v&&v.z<=y;){if(v.x>=f&&v.x<=_&&v.y>=g&&v.y<=m&&v!==s&&v!==o&&Rs(a,h,l,u,c,d,v.x,v.y)&&Et(v.prev,v,v.next)>=0)return!1;v=v.nextZ}return!0}function Uf(i,e){let t=i;do{const n=t.prev,s=t.next.next;!ds(n,s)&&iu(n,t,t.next,s)&&js(n,s)&&js(s,n)&&(e.push(n.i,t.i,s.i),Ks(t),Ks(t.next),t=i=s),t=t.next}while(t!==i);return Ci(t)}function Nf(i,e,t,n,s,r){let o=i;do{let a=o.next.next;for(;a!==o.prev;){if(o.i!==a.i&&Wf(o,a)){let l=su(o,a);o=Ci(o,o.next),l=Ci(l,l.next),Ys(o,e,t,n,s,r,0),Ys(l,e,t,n,s,r,0);return}a=a.next}o=o.next}while(o!==i)}function Of(i,e,t,n){const s=[];for(let r=0,o=e.length;r<o;r++){const a=e[r]*n,l=r<o-1?e[r+1]*n:i.length,c=tu(i,a,l,n,!1);c===c.next&&(c.steiner=!0),s.push(Gf(c))}s.sort(Ff);for(let r=0;r<s.length;r++)t=Bf(s[r],t);return t}function Ff(i,e){let t=i.x-e.x;if(t===0&&(t=i.y-e.y,t===0)){const n=(i.next.y-i.y)/(i.next.x-i.x),s=(e.next.y-e.y)/(e.next.x-e.x);t=n-s}return t}function Bf(i,e){const t=zf(i,e);if(!t)return e;const n=su(t,i);return Ci(n,n.next),Ci(t,t.next)}function zf(i,e){let t=e;const n=i.x,s=i.y;let r=-1/0,o;if(ds(i,t))return t;do{if(ds(i,t.next))return t.next;if(s<=t.y&&s>=t.next.y&&t.next.y!==t.y){const u=t.x+(s-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(u<=n&&u>r&&(r=u,o=t.x<t.next.x?t:t.next,u===n))return o}t=t.next}while(t!==e);if(!o)return null;const a=o,l=o.x,c=o.y;let h=1/0;t=o;do{if(n>=t.x&&t.x>=l&&n!==t.x&&nu(s<c?n:r,s,l,c,s<c?r:n,s,t.x,t.y)){const u=Math.abs(s-t.y)/(n-t.x);js(t,i)&&(u<h||u===h&&(t.x>o.x||t.x===o.x&&kf(o,t)))&&(o=t,h=u)}t=t.next}while(t!==a);return o}function kf(i,e){return Et(i.prev,i,e.prev)<0&&Et(e.next,i,i.next)<0}function Vf(i,e,t,n){let s=i;do s.z===0&&(s.z=Ya(s.x,s.y,e,t,n)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==i);s.prevZ.nextZ=null,s.prevZ=null,Hf(s)}function Hf(i){let e,t=1;do{let n=i,s;i=null;let r=null;for(e=0;n;){e++;let o=n,a=0;for(let c=0;c<t&&(a++,o=o.nextZ,!!o);c++);let l=t;for(;a>0||l>0&&o;)a!==0&&(l===0||!o||n.z<=o.z)?(s=n,n=n.nextZ,a--):(s=o,o=o.nextZ,l--),r?r.nextZ=s:i=s,s.prevZ=r,r=s;n=o}r.nextZ=null,t*=2}while(e>1);return i}function Ya(i,e,t,n,s){return i=(i-t)*s|0,e=(e-n)*s|0,i=(i|i<<8)&16711935,i=(i|i<<4)&252645135,i=(i|i<<2)&858993459,i=(i|i<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,i|e<<1}function Gf(i){let e=i,t=i;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==i);return t}function nu(i,e,t,n,s,r,o,a){return(s-o)*(e-a)>=(i-o)*(r-a)&&(i-o)*(n-a)>=(t-o)*(e-a)&&(t-o)*(r-a)>=(s-o)*(n-a)}function Rs(i,e,t,n,s,r,o,a){return!(i===o&&e===a)&&nu(i,e,t,n,s,r,o,a)}function Wf(i,e){return i.next.i!==e.i&&i.prev.i!==e.i&&!Xf(i,e)&&(js(i,e)&&js(e,i)&&$f(i,e)&&(Et(i.prev,i,e.prev)||Et(i,e.prev,e))||ds(i,e)&&Et(i.prev,i,i.next)>0&&Et(e.prev,e,e.next)>0)}function Et(i,e,t){return(e.y-i.y)*(t.x-e.x)-(e.x-i.x)*(t.y-e.y)}function ds(i,e){return i.x===e.x&&i.y===e.y}function iu(i,e,t,n){const s=Lr(Et(i,e,t)),r=Lr(Et(i,e,n)),o=Lr(Et(t,n,i)),a=Lr(Et(t,n,e));return!!(s!==r&&o!==a||s===0&&Pr(i,t,e)||r===0&&Pr(i,n,e)||o===0&&Pr(t,i,n)||a===0&&Pr(t,e,n))}function Pr(i,e,t){return e.x<=Math.max(i.x,t.x)&&e.x>=Math.min(i.x,t.x)&&e.y<=Math.max(i.y,t.y)&&e.y>=Math.min(i.y,t.y)}function Lr(i){return i>0?1:i<0?-1:0}function Xf(i,e){let t=i;do{if(t.i!==i.i&&t.next.i!==i.i&&t.i!==e.i&&t.next.i!==e.i&&iu(t,t.next,i,e))return!0;t=t.next}while(t!==i);return!1}function js(i,e){return Et(i.prev,i,i.next)<0?Et(i,e,i.next)>=0&&Et(i,i.prev,e)>=0:Et(i,e,i.prev)<0||Et(i,i.next,e)<0}function $f(i,e){let t=i,n=!1;const s=(i.x+e.x)/2,r=(i.y+e.y)/2;do t.y>r!=t.next.y>r&&t.next.y!==t.y&&s<(t.next.x-t.x)*(r-t.y)/(t.next.y-t.y)+t.x&&(n=!n),t=t.next;while(t!==i);return n}function su(i,e){const t=ja(i.i,i.x,i.y),n=ja(e.i,e.x,e.y),s=i.next,r=e.prev;return i.next=e,e.prev=i,t.next=s,s.prev=t,n.next=t,t.prev=n,r.next=n,n.prev=r,n}function Ac(i,e,t,n){const s=ja(i,e,t);return n?(s.next=n.next,s.prev=n,n.next.prev=s,n.next=s):(s.prev=s,s.next=s),s}function Ks(i){i.next.prev=i.prev,i.prev.next=i.next,i.prevZ&&(i.prevZ.nextZ=i.nextZ),i.nextZ&&(i.nextZ.prevZ=i.prevZ)}function ja(i,e,t){return{i,x:e,y:t,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function qf(i,e,t,n){let s=0;for(let r=e,o=t-n;r<t;r+=n)s+=(i[o]-i[r])*(i[r+1]+i[o+1]),o=r;return s}class Yf{static triangulate(e,t,n=2){return Lf(e,t,n)}}class Wn{static area(e){const t=e.length;let n=0;for(let s=t-1,r=0;r<t;s=r++)n+=e[s].x*e[r].y-e[r].x*e[s].y;return n*.5}static isClockWise(e){return Wn.area(e)<0}static triangulateShape(e,t){const n=[],s=[],r=[];Tc(e),Cc(n,e);let o=e.length;t.forEach(Tc);for(let l=0;l<t.length;l++)s.push(o),o+=t[l].length,Cc(n,t[l]);const a=Yf.triangulate(n,s);for(let l=0;l<a.length;l+=3)r.push(a.slice(l,l+3));return r}}function Tc(i){const e=i.length;e>2&&i[e-1].equals(i[0])&&i.pop()}function Cc(i,e){for(let t=0;t<e.length;t++)i.push(e[t].x),i.push(e[t].y)}class Rl extends it{constructor(e=new ir([new ue(.5,.5),new ue(-.5,.5),new ue(-.5,-.5),new ue(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];const n=this,s=[],r=[];for(let a=0,l=e.length;a<l;a++){const c=e[a];o(c)}this.setAttribute("position",new Me(s,3)),this.setAttribute("uv",new Me(r,2)),this.computeVertexNormals();function o(a){const l=[],c=t.curveSegments!==void 0?t.curveSegments:12,h=t.steps!==void 0?t.steps:1,u=t.depth!==void 0?t.depth:1;let d=t.bevelEnabled!==void 0?t.bevelEnabled:!0,f=t.bevelThickness!==void 0?t.bevelThickness:.2,g=t.bevelSize!==void 0?t.bevelSize:f-.1,_=t.bevelOffset!==void 0?t.bevelOffset:0,m=t.bevelSegments!==void 0?t.bevelSegments:3;const p=t.extrudePath,y=t.UVGenerator!==void 0?t.UVGenerator:jf;let x,v=!1,w,M,A,T;p&&(x=p.getSpacedPoints(h),v=!0,d=!1,w=p.computeFrenetFrames(h,!1),M=new P,A=new P,T=new P),d||(m=0,f=0,g=0,_=0);const S=a.extractPoints(c);let b=S.shape;const D=S.holes;if(!Wn.isClockWise(b)){b=b.reverse();for(let Z=0,j=D.length;Z<j;Z++){const Y=D[Z];Wn.isClockWise(Y)&&(D[Z]=Y.reverse())}}function U(Z){const Y=10000000000000001e-36;let K=Z[0];for(let he=1;he<=Z.length;he++){const se=he%Z.length,fe=Z[se],Xe=fe.x-K.x,Ge=fe.y-K.y,R=Xe*Xe+Ge*Ge,E=Math.max(Math.abs(fe.x),Math.abs(fe.y),Math.abs(K.x),Math.abs(K.y)),z=Y*E*E;if(R<=z){Z.splice(se,1),he--;continue}K=fe}}U(b),D.forEach(U);const B=D.length,k=b;for(let Z=0;Z<B;Z++){const j=D[Z];b=b.concat(j)}function V(Z,j,Y){return j||console.error("THREE.ExtrudeGeometry: vec does not exist"),Z.clone().addScaledVector(j,Y)}const te=b.length;function H(Z,j,Y){let K,he,se;const fe=Z.x-j.x,Xe=Z.y-j.y,Ge=Y.x-Z.x,R=Y.y-Z.y,E=fe*fe+Xe*Xe,z=fe*R-Xe*Ge;if(Math.abs(z)>Number.EPSILON){const X=Math.sqrt(E),ie=Math.sqrt(Ge*Ge+R*R),$=j.x-Xe/X,De=j.y+fe/X,de=Y.x-R/ie,Re=Y.y+Ge/ie,Pe=((de-$)*R-(Re-De)*Ge)/(fe*R-Xe*Ge);K=$+fe*Pe-Z.x,he=De+Xe*Pe-Z.y;const oe=K*K+he*he;if(oe<=2)return new ue(K,he);se=Math.sqrt(oe/2)}else{let X=!1;fe>Number.EPSILON?Ge>Number.EPSILON&&(X=!0):fe<-Number.EPSILON?Ge<-Number.EPSILON&&(X=!0):Math.sign(Xe)===Math.sign(R)&&(X=!0),X?(K=-Xe,he=fe,se=Math.sqrt(E)):(K=fe,he=Xe,se=Math.sqrt(E/2))}return new ue(K/se,he/se)}const Q=[];for(let Z=0,j=k.length,Y=j-1,K=Z+1;Z<j;Z++,Y++,K++)Y===j&&(Y=0),K===j&&(K=0),Q[Z]=H(k[Z],k[Y],k[K]);const re=[];let ge,xe=Q.concat();for(let Z=0,j=B;Z<j;Z++){const Y=D[Z];ge=[];for(let K=0,he=Y.length,se=he-1,fe=K+1;K<he;K++,se++,fe++)se===he&&(se=0),fe===he&&(fe=0),ge[K]=H(Y[K],Y[se],Y[fe]);re.push(ge),xe=xe.concat(ge)}let Qe;if(m===0)Qe=Wn.triangulateShape(k,D);else{const Z=[],j=[];for(let Y=0;Y<m;Y++){const K=Y/m,he=f*Math.cos(K*Math.PI/2),se=g*Math.sin(K*Math.PI/2)+_;for(let fe=0,Xe=k.length;fe<Xe;fe++){const Ge=V(k[fe],Q[fe],se);Te(Ge.x,Ge.y,-he),K===0&&Z.push(Ge)}for(let fe=0,Xe=B;fe<Xe;fe++){const Ge=D[fe];ge=re[fe];const R=[];for(let E=0,z=Ge.length;E<z;E++){const X=V(Ge[E],ge[E],se);Te(X.x,X.y,-he),K===0&&R.push(X)}K===0&&j.push(R)}}Qe=Wn.triangulateShape(Z,j)}const ot=Qe.length,qe=g+_;for(let Z=0;Z<te;Z++){const j=d?V(b[Z],xe[Z],qe):b[Z];v?(A.copy(w.normals[0]).multiplyScalar(j.x),M.copy(w.binormals[0]).multiplyScalar(j.y),T.copy(x[0]).add(A).add(M),Te(T.x,T.y,T.z)):Te(j.x,j.y,0)}for(let Z=1;Z<=h;Z++)for(let j=0;j<te;j++){const Y=d?V(b[j],xe[j],qe):b[j];v?(A.copy(w.normals[Z]).multiplyScalar(Y.x),M.copy(w.binormals[Z]).multiplyScalar(Y.y),T.copy(x[Z]).add(A).add(M),Te(T.x,T.y,T.z)):Te(Y.x,Y.y,u/h*Z)}for(let Z=m-1;Z>=0;Z--){const j=Z/m,Y=f*Math.cos(j*Math.PI/2),K=g*Math.sin(j*Math.PI/2)+_;for(let he=0,se=k.length;he<se;he++){const fe=V(k[he],Q[he],K);Te(fe.x,fe.y,u+Y)}for(let he=0,se=D.length;he<se;he++){const fe=D[he];ge=re[he];for(let Xe=0,Ge=fe.length;Xe<Ge;Xe++){const R=V(fe[Xe],ge[Xe],K);v?Te(R.x,R.y+x[h-1].y,x[h-1].x+Y):Te(R.x,R.y,u+Y)}}}J(),ee();function J(){const Z=s.length/3;if(d){let j=0,Y=te*j;for(let K=0;K<ot;K++){const he=Qe[K];Ee(he[2]+Y,he[1]+Y,he[0]+Y)}j=h+m*2,Y=te*j;for(let K=0;K<ot;K++){const he=Qe[K];Ee(he[0]+Y,he[1]+Y,he[2]+Y)}}else{for(let j=0;j<ot;j++){const Y=Qe[j];Ee(Y[2],Y[1],Y[0])}for(let j=0;j<ot;j++){const Y=Qe[j];Ee(Y[0]+te*h,Y[1]+te*h,Y[2]+te*h)}}n.addGroup(Z,s.length/3-Z,0)}function ee(){const Z=s.length/3;let j=0;Se(k,j),j+=k.length;for(let Y=0,K=D.length;Y<K;Y++){const he=D[Y];Se(he,j),j+=he.length}n.addGroup(Z,s.length/3-Z,1)}function Se(Z,j){let Y=Z.length;for(;--Y>=0;){const K=Y;let he=Y-1;he<0&&(he=Z.length-1);for(let se=0,fe=h+m*2;se<fe;se++){const Xe=te*se,Ge=te*(se+1),R=j+K+Xe,E=j+he+Xe,z=j+he+Ge,X=j+K+Ge;et(R,E,z,X)}}}function Te(Z,j,Y){l.push(Z),l.push(j),l.push(Y)}function Ee(Z,j,Y){Ie(Z),Ie(j),Ie(Y);const K=s.length/3,he=y.generateTopUV(n,s,K-3,K-2,K-1);L(he[0]),L(he[1]),L(he[2])}function et(Z,j,Y,K){Ie(Z),Ie(j),Ie(K),Ie(j),Ie(Y),Ie(K);const he=s.length/3,se=y.generateSideWallUV(n,s,he-6,he-3,he-2,he-1);L(se[0]),L(se[1]),L(se[3]),L(se[1]),L(se[2]),L(se[3])}function Ie(Z){s.push(l[Z*3+0]),s.push(l[Z*3+1]),s.push(l[Z*3+2])}function L(Z){r.push(Z.x),r.push(Z.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes,n=this.parameters.options;return Kf(t,n,e)}static fromJSON(e,t){const n=[];for(let r=0,o=e.shapes.length;r<o;r++){const a=t[e.shapes[r]];n.push(a)}const s=e.options.extrudePath;return s!==void 0&&(e.options.extrudePath=new Qr[s.type]().fromJSON(s)),new Rl(n,e.options)}}const jf={generateTopUV:function(i,e,t,n,s){const r=e[t*3],o=e[t*3+1],a=e[n*3],l=e[n*3+1],c=e[s*3],h=e[s*3+1];return[new ue(r,o),new ue(a,l),new ue(c,h)]},generateSideWallUV:function(i,e,t,n,s,r){const o=e[t*3],a=e[t*3+1],l=e[t*3+2],c=e[n*3],h=e[n*3+1],u=e[n*3+2],d=e[s*3],f=e[s*3+1],g=e[s*3+2],_=e[r*3],m=e[r*3+1],p=e[r*3+2];return Math.abs(a-h)<Math.abs(o-c)?[new ue(o,1-l),new ue(c,1-u),new ue(d,1-g),new ue(_,1-p)]:[new ue(a,1-l),new ue(h,1-u),new ue(f,1-g),new ue(m,1-p)]}};function Kf(i,e,t){if(t.shapes=[],Array.isArray(i))for(let n=0,s=i.length;n<s;n++){const r=i[n];t.shapes.push(r.uuid)}else t.shapes.push(i.uuid);return t.options=Object.assign({},e),e.extrudePath!==void 0&&(t.options.extrudePath=e.extrudePath.toJSON()),t}class sr extends so{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new sr(e.radius,e.detail)}}class gs extends it{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};const r=e/2,o=t/2,a=Math.floor(n),l=Math.floor(s),c=a+1,h=l+1,u=e/a,d=t/l,f=[],g=[],_=[],m=[];for(let p=0;p<h;p++){const y=p*d-o;for(let x=0;x<c;x++){const v=x*u-r;g.push(v,-y,0),_.push(0,0,1),m.push(x/a),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let y=0;y<a;y++){const x=y+c*p,v=y+c*(p+1),w=y+1+c*(p+1),M=y+1+c*p;f.push(x,v,M),f.push(v,w,M)}this.setIndex(f),this.setAttribute("position",new Me(g,3)),this.setAttribute("normal",new Me(_,3)),this.setAttribute("uv",new Me(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new gs(e.width,e.height,e.widthSegments,e.heightSegments)}}class ro extends it{constructor(e=new ir([new ue(0,.5),new ue(-.5,-.5),new ue(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};const n=[],s=[],r=[],o=[];let a=0,l=0;if(Array.isArray(e)===!1)c(e);else for(let h=0;h<e.length;h++)c(e[h]),this.addGroup(a,l,h),a+=l,l=0;this.setIndex(n),this.setAttribute("position",new Me(s,3)),this.setAttribute("normal",new Me(r,3)),this.setAttribute("uv",new Me(o,2));function c(h){const u=s.length/3,d=h.extractPoints(t);let f=d.shape;const g=d.holes;Wn.isClockWise(f)===!1&&(f=f.reverse());for(let m=0,p=g.length;m<p;m++){const y=g[m];Wn.isClockWise(y)===!0&&(g[m]=y.reverse())}const _=Wn.triangulateShape(f,g);for(let m=0,p=g.length;m<p;m++){const y=g[m];f=f.concat(y)}for(let m=0,p=f.length;m<p;m++){const y=f[m];s.push(y.x,y.y,0),r.push(0,0,1),o.push(y.x,y.y)}for(let m=0,p=_.length;m<p;m++){const y=_[m],x=y[0]+u,v=y[1]+u,w=y[2]+u;n.push(x,v,w),l+=3}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes;return Zf(t,e)}static fromJSON(e,t){const n=[];for(let s=0,r=e.shapes.length;s<r;s++){const o=t[e.shapes[s]];n.push(o)}return new ro(n,e.curveSegments)}}function Zf(i,e){if(e.shapes=[],Array.isArray(i))for(let t=0,n=i.length;t<n;t++){const s=i[t];e.shapes.push(s.uuid)}else e.shapes.push(i.uuid);return e}class Kn extends it{constructor(e=1,t=32,n=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const l=Math.min(o+a,Math.PI);let c=0;const h=[],u=new P,d=new P,f=[],g=[],_=[],m=[];for(let p=0;p<=n;p++){const y=[],x=p/n;let v=0;p===0&&o===0?v=.5/t:p===n&&l===Math.PI&&(v=-.5/t);for(let w=0;w<=t;w++){const M=w/t;u.x=-e*Math.cos(s+M*r)*Math.sin(o+x*a),u.y=e*Math.cos(o+x*a),u.z=e*Math.sin(s+M*r)*Math.sin(o+x*a),g.push(u.x,u.y,u.z),d.copy(u).normalize(),_.push(d.x,d.y,d.z),m.push(M+v,1-x),y.push(c++)}h.push(y)}for(let p=0;p<n;p++)for(let y=0;y<t;y++){const x=h[p][y+1],v=h[p][y],w=h[p+1][y],M=h[p+1][y+1];(p!==0||o>0)&&f.push(x,v,M),(p!==n-1||l<Math.PI)&&f.push(v,w,M)}this.setIndex(f),this.setAttribute("position",new Me(g,3)),this.setAttribute("normal",new Me(_,3)),this.setAttribute("uv",new Me(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Kn(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Pl extends it{constructor(e=1,t=.4,n=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:s,arc:r},n=Math.floor(n),s=Math.floor(s);const o=[],a=[],l=[],c=[],h=new P,u=new P,d=new P;for(let f=0;f<=n;f++)for(let g=0;g<=s;g++){const _=g/s*r,m=f/n*Math.PI*2;u.x=(e+t*Math.cos(m))*Math.cos(_),u.y=(e+t*Math.cos(m))*Math.sin(_),u.z=t*Math.sin(m),a.push(u.x,u.y,u.z),h.x=e*Math.cos(_),h.y=e*Math.sin(_),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(g/s),c.push(f/n)}for(let f=1;f<=n;f++)for(let g=1;g<=s;g++){const _=(s+1)*f+g-1,m=(s+1)*(f-1)+g-1,p=(s+1)*(f-1)+g,y=(s+1)*f+g;o.push(_,m,y),o.push(m,p,y)}this.setIndex(o),this.setAttribute("position",new Me(a,3)),this.setAttribute("normal",new Me(l,3)),this.setAttribute("uv",new Me(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Pl(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}}class Zs extends it{constructor(e=new Qh(new P(-1,-1,0),new P(-1,1,0),new P(1,1,0)),t=64,n=1,s=8,r=!1){super(),this.type="TubeGeometry",this.parameters={path:e,tubularSegments:t,radius:n,radialSegments:s,closed:r};const o=e.computeFrenetFrames(t,r);this.tangents=o.tangents,this.normals=o.normals,this.binormals=o.binormals;const a=new P,l=new P,c=new ue;let h=new P;const u=[],d=[],f=[],g=[];_(),this.setIndex(g),this.setAttribute("position",new Me(u,3)),this.setAttribute("normal",new Me(d,3)),this.setAttribute("uv",new Me(f,2));function _(){for(let x=0;x<t;x++)m(x);m(r===!1?t:0),y(),p()}function m(x){h=e.getPointAt(x/t,h);const v=o.normals[x],w=o.binormals[x];for(let M=0;M<=s;M++){const A=M/s*Math.PI*2,T=Math.sin(A),S=-Math.cos(A);l.x=S*v.x+T*w.x,l.y=S*v.y+T*w.y,l.z=S*v.z+T*w.z,l.normalize(),d.push(l.x,l.y,l.z),a.x=h.x+n*l.x,a.y=h.y+n*l.y,a.z=h.z+n*l.z,u.push(a.x,a.y,a.z)}}function p(){for(let x=1;x<=t;x++)for(let v=1;v<=s;v++){const w=(s+1)*(x-1)+(v-1),M=(s+1)*x+(v-1),A=(s+1)*x+v,T=(s+1)*(x-1)+v;g.push(w,M,T),g.push(M,A,T)}}function y(){for(let x=0;x<=t;x++)for(let v=0;v<=s;v++)c.x=x/t,c.y=v/s,f.push(c.x,c.y)}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON();return e.path=this.parameters.path.toJSON(),e}static fromJSON(e){return new Zs(new Qr[e.path.type]().fromJSON(e.path),e.tubularSegments,e.radius,e.radialSegments,e.closed)}}class Jf extends it{constructor(e=null){if(super(),this.type="WireframeGeometry",this.parameters={geometry:e},e!==null){const t=[],n=new Set,s=new P,r=new P;if(e.index!==null){const o=e.attributes.position,a=e.index;let l=e.groups;l.length===0&&(l=[{start:0,count:a.count,materialIndex:0}]);for(let c=0,h=l.length;c<h;++c){const u=l[c],d=u.start,f=u.count;for(let g=d,_=d+f;g<_;g+=3)for(let m=0;m<3;m++){const p=a.getX(g+m),y=a.getX(g+(m+1)%3);s.fromBufferAttribute(o,p),r.fromBufferAttribute(o,y),Rc(s,r,n)===!0&&(t.push(s.x,s.y,s.z),t.push(r.x,r.y,r.z))}}}else{const o=e.attributes.position;for(let a=0,l=o.count/3;a<l;a++)for(let c=0;c<3;c++){const h=3*a+c,u=3*a+(c+1)%3;s.fromBufferAttribute(o,h),r.fromBufferAttribute(o,u),Rc(s,r,n)===!0&&(t.push(s.x,s.y,s.z),t.push(r.x,r.y,r.z))}}this.setAttribute("position",new Me(t,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}}function Rc(i,e,t){const n=`${i.x},${i.y},${i.z}-${e.x},${e.y},${e.z}`,s=`${e.x},${e.y},${e.z}-${i.x},${i.y},${i.z}`;return t.has(n)===!0||t.has(s)===!0?!1:(t.add(n),t.add(s),!0)}class gn extends Ri{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Oe(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Oe(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=vl,this.normalScale=new ue(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new En,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Ps extends Ri{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Oe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Oe(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=vl,this.normalScale=new ue(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new En,this.combine=cl,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Qf extends Ri{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=fd,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class ep extends Ri{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const ko={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}};class tp{constructor(e,t,n){const s=this;let r=!1,o=0,a=0,l;const c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.abortController=new AbortController,this.itemStart=function(h){a++,r===!1&&s.onStart!==void 0&&s.onStart(h,o,a),r=!0},this.itemEnd=function(h){o++,s.onProgress!==void 0&&s.onProgress(h,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){const u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){const f=c[u],g=c[u+1];if(f.global&&(f.lastIndex=0),f.test(h))return g}return null},this.abort=function(){return this.abortController.abort(),this.abortController=new AbortController,this}}}const np=new tp;class Ll{constructor(e){this.manager=e!==void 0?e:np,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const n=this;return new Promise(function(s,r){n.load(e,s,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}}Ll.DEFAULT_MATERIAL_NAME="__DEFAULT";const Xi=new WeakMap;class ip extends Ll{constructor(e){super(e)}load(e,t,n,s){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const r=this,o=ko.get(`image:${e}`);if(o!==void 0){if(o.complete===!0)r.manager.itemStart(e),setTimeout(function(){t&&t(o),r.manager.itemEnd(e)},0);else{let u=Xi.get(o);u===void 0&&(u=[],Xi.set(o,u)),u.push({onLoad:t,onError:s})}return o}const a=Xs("img");function l(){h(),t&&t(this);const u=Xi.get(this)||[];for(let d=0;d<u.length;d++){const f=u[d];f.onLoad&&f.onLoad(this)}Xi.delete(this),r.manager.itemEnd(e)}function c(u){h(),s&&s(u),ko.remove(`image:${e}`);const d=Xi.get(this)||[];for(let f=0;f<d.length;f++){const g=d[f];g.onError&&g.onError(u)}Xi.delete(this),r.manager.itemError(e),r.manager.itemEnd(e)}function h(){a.removeEventListener("load",l,!1),a.removeEventListener("error",c,!1)}return a.addEventListener("load",l,!1),a.addEventListener("error",c,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(a.crossOrigin=this.crossOrigin),ko.add(`image:${e}`,a),r.manager.itemStart(e),a.src=e,a}}class oo extends Ll{constructor(e){super(e)}load(e,t,n,s){const r=new Xt,o=new ip(this.manager);return o.setCrossOrigin(this.crossOrigin),o.setPath(this.path),o.load(e,function(a){r.image=a,r.needsUpdate=!0,t!==void 0&&t(r)},n,s),r}}class ru extends Rt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Oe(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}}class sp extends ru{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Rt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Oe(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const Vo=new st,Pc=new P,Lc=new P;class rp{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new ue(512,512),this.mapType=In,this.map=null,this.mapPass=null,this.matrix=new st,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new bl,this._frameExtents=new ue(1,1),this._viewportCount=1,this._viewports=[new at(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,n=this.matrix;Pc.setFromMatrixPosition(e.matrixWorld),t.position.copy(Pc),Lc.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Lc),t.updateMatrixWorld(),Vo.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Vo,t.coordinateSystem,t.reversedDepth),t.reversedDepth?n.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Vo)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class ou extends Wh{constructor(e=-1,t=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=n-e,o=n+e,a=s+t,l=s-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class op extends rp{constructor(){super(new ou(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class ap extends ru{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Rt.DEFAULT_UP),this.updateMatrix(),this.target=new Rt,this.shadow=new op}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class lp extends it{constructor(){super(),this.isInstancedBufferGeometry=!0,this.type="InstancedBufferGeometry",this.instanceCount=1/0}copy(e){return super.copy(e),this.instanceCount=e.instanceCount,this}toJSON(){const e=super.toJSON();return e.instanceCount=this.instanceCount,e.isInstancedBufferGeometry=!0,e}}class cp extends fn{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}class Ka extends ff{constructor(e,t,n=1){super(e,t),this.isInstancedInterleavedBuffer=!0,this.meshPerAttribute=n}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}clone(e){const t=super.clone(e);return t.meshPerAttribute=this.meshPerAttribute,t}toJSON(e){const t=super.toJSON(e);return t.isInstancedInterleavedBuffer=!0,t.meshPerAttribute=this.meshPerAttribute,t}}const Dc=new st;class Za{constructor(e,t,n=0,s=1/0){this.ray=new io(e,t),this.near=n,this.far=s,this.camera=null,this.layers=new yl,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return Dc.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Dc),this}intersectObject(e,t=!0,n=[]){return Ja(e,this,n,t),n.sort(Ic),n}intersectObjects(e,t=!0,n=[]){for(let s=0,r=e.length;s<r;s++)Ja(e[s],this,n,t);return n.sort(Ic),n}}function Ic(i,e){return i.distance-e.distance}function Ja(i,e,t,n){let s=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(s=!1),s===!0&&n===!0){const r=i.children;for(let o=0,a=r.length;o<a;o++)Ja(r[o],e,t,!0)}}const Uc=new P,Dr=new P,$i=new P,qi=new P,Ho=new P,hp=new P,up=new P;class dp{constructor(e=new P,t=new P){this.start=e,this.end=t}set(e,t){return this.start.copy(e),this.end.copy(t),this}copy(e){return this.start.copy(e.start),this.end.copy(e.end),this}getCenter(e){return e.addVectors(this.start,this.end).multiplyScalar(.5)}delta(e){return e.subVectors(this.end,this.start)}distanceSq(){return this.start.distanceToSquared(this.end)}distance(){return this.start.distanceTo(this.end)}at(e,t){return this.delta(t).multiplyScalar(e).add(this.start)}closestPointToPointParameter(e,t){Uc.subVectors(e,this.start),Dr.subVectors(this.end,this.start);const n=Dr.dot(Dr);let r=Dr.dot(Uc)/n;return t&&(r=We(r,0,1)),r}closestPointToPoint(e,t,n){const s=this.closestPointToPointParameter(e,t);return this.delta(n).multiplyScalar(s).add(this.start)}distanceSqToLine3(e,t=hp,n=up){const s=10000000000000001e-32;let r,o;const a=this.start,l=e.start,c=this.end,h=e.end;$i.subVectors(c,a),qi.subVectors(h,l),Ho.subVectors(a,l);const u=$i.dot($i),d=qi.dot(qi),f=qi.dot(Ho);if(u<=s&&d<=s)return t.copy(a),n.copy(l),t.sub(n),t.dot(t);if(u<=s)r=0,o=f/d,o=We(o,0,1);else{const g=$i.dot(Ho);if(d<=s)o=0,r=We(-g/u,0,1);else{const _=$i.dot(qi),m=u*d-_*_;m!==0?r=We((_*f-g*d)/m,0,1):r=0,o=(_*r+f)/d,o<0?(o=0,r=We(-g/u,0,1)):o>1&&(o=1,r=We((_-g)/u,0,1))}}return t.copy(a).add($i.multiplyScalar(r)),n.copy(l).add(qi.multiplyScalar(o)),t.sub(n),t.dot(t)}applyMatrix4(e){return this.start.applyMatrix4(e),this.end.applyMatrix4(e),this}equals(e){return e.start.equals(this.start)&&e.end.equals(this.end)}clone(){return new this.constructor().copy(this)}}function Nc(i,e,t,n){const s=fp(n);switch(t){case Uh:return i*e;case fl:return i*e/s.components*s.byteLength;case pl:return i*e/s.components*s.byteLength;case Oh:return i*e*2/s.components*s.byteLength;case ml:return i*e*2/s.components*s.byteLength;case Nh:return i*e*3/s.components*s.byteLength;case bn:return i*e*4/s.components*s.byteLength;case gl:return i*e*4/s.components*s.byteLength;case Gr:case Wr:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Xr:case $r:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case xa:case Ma:return Math.max(i,16)*Math.max(e,8)/4;case _a:case ya:return Math.max(i,8)*Math.max(e,8)/2;case Sa:case ba:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case wa:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Ea:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Aa:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case Ta:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case Ca:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case Ra:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case Pa:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case La:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case Da:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case Ia:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case Ua:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Na:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case Oa:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Fa:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Ba:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case za:case ka:case Va:return Math.ceil(i/4)*Math.ceil(e/4)*16;case Ha:case Ga:return Math.ceil(i/4)*Math.ceil(e/4)*8;case Wa:case Xa:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function fp(i){switch(i){case In:case Ph:return{byteLength:1,components:1};case ks:case Lh:case er:return{byteLength:2,components:1};case ul:case dl:return{byteLength:2,components:4};case Ai:case hl:case Pn:return{byteLength:4,components:1};case Dh:case Ih:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:ll}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=ll);function au(){let i=null,e=!1,t=null,n=null;function s(r,o){t(r,o),n=i.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){i=r}}}function pp(i){const e=new WeakMap;function t(a,l){const c=a.array,h=a.usage,u=c.byteLength,d=i.createBuffer();i.bindBuffer(l,d),i.bufferData(l,c,h),a.onUploadCallback();let f;if(c instanceof Float32Array)f=i.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)f=i.HALF_FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=i.SHORT;else if(c instanceof Uint32Array)f=i.UNSIGNED_INT;else if(c instanceof Int32Array)f=i.INT;else if(c instanceof Int8Array)f=i.BYTE;else if(c instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:u}}function n(a,l,c){const h=l.array,u=l.updateRanges;if(i.bindBuffer(c,a),u.length===0)i.bufferSubData(c,0,h);else{u.sort((f,g)=>f.start-g.start);let d=0;for(let f=1;f<u.length;f++){const g=u[d],_=u[f];_.start<=g.start+g.count+1?g.count=Math.max(g.count,_.start+_.count-g.start):(++d,u[d]=_)}u.length=d+1;for(let f=0,g=u.length;f<g;f++){const _=u[f];i.bufferSubData(c,_.start*h.BYTES_PER_ELEMENT,h,_.start,_.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(a){return a.isInterleavedBufferAttribute&&(a=a.data),e.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);const l=e.get(a);l&&(i.deleteBuffer(l.buffer),e.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const h=e.get(a);(!h||h.version<a.version)&&e.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const c=e.get(a);if(c===void 0)e.set(a,t(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,a,l),c.version=a.version}}return{get:s,remove:r,update:o}}var mp=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,gp=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,vp=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,_p=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,xp=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,yp=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Mp=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Sp=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,bp=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,wp=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Ep=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Ap=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Tp=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Cp=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Rp=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Pp=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Lp=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Dp=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Ip=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Up=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Np=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Op=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Fp=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Bp=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,zp=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,kp=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Vp=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Hp=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Gp=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Wp=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Xp="gl_FragColor = linearToOutputTexel( gl_FragColor );",$p=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,qp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Yp=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,jp=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Kp=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Zp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Jp=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Qp=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,em=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,tm=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,nm=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,im=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,sm=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,rm=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,om=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,am=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,lm=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,cm=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,hm=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,um=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,dm=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,fm=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,pm=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,mm=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,gm=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,vm=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,_m=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,xm=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,ym=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Mm=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Sm=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,bm=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,wm=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Em=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Am=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Tm=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Cm=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Rm=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Pm=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Lm=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Dm=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Im=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Um=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Nm=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Om=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Fm=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Bm=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,zm=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,km=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Vm=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Hm=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Gm=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Wm=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Xm=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,$m=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,qm=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Ym=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,jm=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Km=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Zm=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Jm=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Qm=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,eg=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,tg=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,ng=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,ig=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,sg=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,rg=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,og=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,ag=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,lg=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,cg=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,hg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,ug=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,dg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,fg=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const pg=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,mg=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,gg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,vg=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,_g=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,xg=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,yg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Mg=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Sg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,bg=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,wg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Eg=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ag=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Tg=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Cg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Rg=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Pg=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Lg=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Dg=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Ig=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ug=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Ng=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Og=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Fg=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Bg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,zg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,kg=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Vg=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Hg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Gg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Wg=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Xg=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,$g=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,qg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Je={alphahash_fragment:mp,alphahash_pars_fragment:gp,alphamap_fragment:vp,alphamap_pars_fragment:_p,alphatest_fragment:xp,alphatest_pars_fragment:yp,aomap_fragment:Mp,aomap_pars_fragment:Sp,batching_pars_vertex:bp,batching_vertex:wp,begin_vertex:Ep,beginnormal_vertex:Ap,bsdfs:Tp,iridescence_fragment:Cp,bumpmap_pars_fragment:Rp,clipping_planes_fragment:Pp,clipping_planes_pars_fragment:Lp,clipping_planes_pars_vertex:Dp,clipping_planes_vertex:Ip,color_fragment:Up,color_pars_fragment:Np,color_pars_vertex:Op,color_vertex:Fp,common:Bp,cube_uv_reflection_fragment:zp,defaultnormal_vertex:kp,displacementmap_pars_vertex:Vp,displacementmap_vertex:Hp,emissivemap_fragment:Gp,emissivemap_pars_fragment:Wp,colorspace_fragment:Xp,colorspace_pars_fragment:$p,envmap_fragment:qp,envmap_common_pars_fragment:Yp,envmap_pars_fragment:jp,envmap_pars_vertex:Kp,envmap_physical_pars_fragment:am,envmap_vertex:Zp,fog_vertex:Jp,fog_pars_vertex:Qp,fog_fragment:em,fog_pars_fragment:tm,gradientmap_pars_fragment:nm,lightmap_pars_fragment:im,lights_lambert_fragment:sm,lights_lambert_pars_fragment:rm,lights_pars_begin:om,lights_toon_fragment:lm,lights_toon_pars_fragment:cm,lights_phong_fragment:hm,lights_phong_pars_fragment:um,lights_physical_fragment:dm,lights_physical_pars_fragment:fm,lights_fragment_begin:pm,lights_fragment_maps:mm,lights_fragment_end:gm,logdepthbuf_fragment:vm,logdepthbuf_pars_fragment:_m,logdepthbuf_pars_vertex:xm,logdepthbuf_vertex:ym,map_fragment:Mm,map_pars_fragment:Sm,map_particle_fragment:bm,map_particle_pars_fragment:wm,metalnessmap_fragment:Em,metalnessmap_pars_fragment:Am,morphinstance_vertex:Tm,morphcolor_vertex:Cm,morphnormal_vertex:Rm,morphtarget_pars_vertex:Pm,morphtarget_vertex:Lm,normal_fragment_begin:Dm,normal_fragment_maps:Im,normal_pars_fragment:Um,normal_pars_vertex:Nm,normal_vertex:Om,normalmap_pars_fragment:Fm,clearcoat_normal_fragment_begin:Bm,clearcoat_normal_fragment_maps:zm,clearcoat_pars_fragment:km,iridescence_pars_fragment:Vm,opaque_fragment:Hm,packing:Gm,premultiplied_alpha_fragment:Wm,project_vertex:Xm,dithering_fragment:$m,dithering_pars_fragment:qm,roughnessmap_fragment:Ym,roughnessmap_pars_fragment:jm,shadowmap_pars_fragment:Km,shadowmap_pars_vertex:Zm,shadowmap_vertex:Jm,shadowmask_pars_fragment:Qm,skinbase_vertex:eg,skinning_pars_vertex:tg,skinning_vertex:ng,skinnormal_vertex:ig,specularmap_fragment:sg,specularmap_pars_fragment:rg,tonemapping_fragment:og,tonemapping_pars_fragment:ag,transmission_fragment:lg,transmission_pars_fragment:cg,uv_pars_fragment:hg,uv_pars_vertex:ug,uv_vertex:dg,worldpos_vertex:fg,background_vert:pg,background_frag:mg,backgroundCube_vert:gg,backgroundCube_frag:vg,cube_vert:_g,cube_frag:xg,depth_vert:yg,depth_frag:Mg,distanceRGBA_vert:Sg,distanceRGBA_frag:bg,equirect_vert:wg,equirect_frag:Eg,linedashed_vert:Ag,linedashed_frag:Tg,meshbasic_vert:Cg,meshbasic_frag:Rg,meshlambert_vert:Pg,meshlambert_frag:Lg,meshmatcap_vert:Dg,meshmatcap_frag:Ig,meshnormal_vert:Ug,meshnormal_frag:Ng,meshphong_vert:Og,meshphong_frag:Fg,meshphysical_vert:Bg,meshphysical_frag:zg,meshtoon_vert:kg,meshtoon_frag:Vg,points_vert:Hg,points_frag:Gg,shadow_vert:Wg,shadow_frag:Xg,sprite_vert:$g,sprite_frag:qg},me={common:{diffuse:{value:new Oe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new je},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new je}},envmap:{envMap:{value:null},envMapRotation:{value:new je},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new je}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new je}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new je},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new je},normalScale:{value:new ue(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new je},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new je}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new je}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new je}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Oe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Oe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0},uvTransform:{value:new je}},sprite:{diffuse:{value:new Oe(16777215)},opacity:{value:1},center:{value:new ue(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new je},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0}}},Jt={basic:{uniforms:Yt([me.common,me.specularmap,me.envmap,me.aomap,me.lightmap,me.fog]),vertexShader:Je.meshbasic_vert,fragmentShader:Je.meshbasic_frag},lambert:{uniforms:Yt([me.common,me.specularmap,me.envmap,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.fog,me.lights,{emissive:{value:new Oe(0)}}]),vertexShader:Je.meshlambert_vert,fragmentShader:Je.meshlambert_frag},phong:{uniforms:Yt([me.common,me.specularmap,me.envmap,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.fog,me.lights,{emissive:{value:new Oe(0)},specular:{value:new Oe(1118481)},shininess:{value:30}}]),vertexShader:Je.meshphong_vert,fragmentShader:Je.meshphong_frag},standard:{uniforms:Yt([me.common,me.envmap,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.roughnessmap,me.metalnessmap,me.fog,me.lights,{emissive:{value:new Oe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Je.meshphysical_vert,fragmentShader:Je.meshphysical_frag},toon:{uniforms:Yt([me.common,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.gradientmap,me.fog,me.lights,{emissive:{value:new Oe(0)}}]),vertexShader:Je.meshtoon_vert,fragmentShader:Je.meshtoon_frag},matcap:{uniforms:Yt([me.common,me.bumpmap,me.normalmap,me.displacementmap,me.fog,{matcap:{value:null}}]),vertexShader:Je.meshmatcap_vert,fragmentShader:Je.meshmatcap_frag},points:{uniforms:Yt([me.points,me.fog]),vertexShader:Je.points_vert,fragmentShader:Je.points_frag},dashed:{uniforms:Yt([me.common,me.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Je.linedashed_vert,fragmentShader:Je.linedashed_frag},depth:{uniforms:Yt([me.common,me.displacementmap]),vertexShader:Je.depth_vert,fragmentShader:Je.depth_frag},normal:{uniforms:Yt([me.common,me.bumpmap,me.normalmap,me.displacementmap,{opacity:{value:1}}]),vertexShader:Je.meshnormal_vert,fragmentShader:Je.meshnormal_frag},sprite:{uniforms:Yt([me.sprite,me.fog]),vertexShader:Je.sprite_vert,fragmentShader:Je.sprite_frag},background:{uniforms:{uvTransform:{value:new je},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Je.background_vert,fragmentShader:Je.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new je}},vertexShader:Je.backgroundCube_vert,fragmentShader:Je.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Je.cube_vert,fragmentShader:Je.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Je.equirect_vert,fragmentShader:Je.equirect_frag},distanceRGBA:{uniforms:Yt([me.common,me.displacementmap,{referencePosition:{value:new P},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Je.distanceRGBA_vert,fragmentShader:Je.distanceRGBA_frag},shadow:{uniforms:Yt([me.lights,me.fog,{color:{value:new Oe(0)},opacity:{value:1}}]),vertexShader:Je.shadow_vert,fragmentShader:Je.shadow_frag}};Jt.physical={uniforms:Yt([Jt.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new je},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new je},clearcoatNormalScale:{value:new ue(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new je},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new je},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new je},sheen:{value:0},sheenColor:{value:new Oe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new je},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new je},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new je},transmissionSamplerSize:{value:new ue},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new je},attenuationDistance:{value:0},attenuationColor:{value:new Oe(0)},specularColor:{value:new Oe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new je},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new je},anisotropyVector:{value:new ue},anisotropyMap:{value:null},anisotropyMapTransform:{value:new je}}]),vertexShader:Je.meshphysical_vert,fragmentShader:Je.meshphysical_frag};const Ir={r:0,b:0,g:0},gi=new En,Yg=new st;function jg(i,e,t,n,s,r,o){const a=new Oe(0);let l=r===!0?0:1,c,h,u=null,d=0,f=null;function g(x){let v=x.isScene===!0?x.background:null;return v&&v.isTexture&&(v=(x.backgroundBlurriness>0?t:e).get(v)),v}function _(x){let v=!1;const w=g(x);w===null?p(a,l):w&&w.isColor&&(p(w,1),v=!0);const M=i.xr.getEnvironmentBlendMode();M==="additive"?n.buffers.color.setClear(0,0,0,1,o):M==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||v)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function m(x,v){const w=g(v);w&&(w.isCubeTexture||w.mapping===no)?(h===void 0&&(h=new Ne(new ms(1,1,1),new nn({name:"BackgroundCubeMaterial",uniforms:us(Jt.backgroundCube.uniforms),vertexShader:Jt.backgroundCube.vertexShader,fragmentShader:Jt.backgroundCube.fragmentShader,side:jt,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(M,A,T){this.matrixWorld.copyPosition(T.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),gi.copy(v.backgroundRotation),gi.x*=-1,gi.y*=-1,gi.z*=-1,w.isCubeTexture&&w.isRenderTargetTexture===!1&&(gi.y*=-1,gi.z*=-1),h.material.uniforms.envMap.value=w,h.material.uniforms.flipEnvMap.value=w.isCubeTexture&&w.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=v.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(Yg.makeRotationFromEuler(gi)),h.material.toneMapped=ht.getTransfer(w.colorSpace)!==gt,(u!==w||d!==w.version||f!==i.toneMapping)&&(h.material.needsUpdate=!0,u=w,d=w.version,f=i.toneMapping),h.layers.enableAll(),x.unshift(h,h.geometry,h.material,0,0,null)):w&&w.isTexture&&(c===void 0&&(c=new Ne(new gs(2,2),new nn({name:"BackgroundMaterial",uniforms:us(Jt.background.uniforms),vertexShader:Jt.background.vertexShader,fragmentShader:Jt.background.fragmentShader,side:jn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=w,c.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,c.material.toneMapped=ht.getTransfer(w.colorSpace)!==gt,w.matrixAutoUpdate===!0&&w.updateMatrix(),c.material.uniforms.uvTransform.value.copy(w.matrix),(u!==w||d!==w.version||f!==i.toneMapping)&&(c.material.needsUpdate=!0,u=w,d=w.version,f=i.toneMapping),c.layers.enableAll(),x.unshift(c,c.geometry,c.material,0,0,null))}function p(x,v){x.getRGB(Ir,Gh(i)),n.buffers.color.setClear(Ir.r,Ir.g,Ir.b,v,o)}function y(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return a},setClearColor:function(x,v=1){a.set(x),l=v,p(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(x){l=x,p(a,l)},render:_,addToRenderList:m,dispose:y}}function Kg(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=d(null);let r=s,o=!1;function a(b,D,I,U,B){let k=!1;const V=u(U,I,D);r!==V&&(r=V,c(r.object)),k=f(b,U,I,B),k&&g(b,U,I,B),B!==null&&e.update(B,i.ELEMENT_ARRAY_BUFFER),(k||o)&&(o=!1,v(b,D,I,U),B!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(B).buffer))}function l(){return i.createVertexArray()}function c(b){return i.bindVertexArray(b)}function h(b){return i.deleteVertexArray(b)}function u(b,D,I){const U=I.wireframe===!0;let B=n[b.id];B===void 0&&(B={},n[b.id]=B);let k=B[D.id];k===void 0&&(k={},B[D.id]=k);let V=k[U];return V===void 0&&(V=d(l()),k[U]=V),V}function d(b){const D=[],I=[],U=[];for(let B=0;B<t;B++)D[B]=0,I[B]=0,U[B]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:D,enabledAttributes:I,attributeDivisors:U,object:b,attributes:{},index:null}}function f(b,D,I,U){const B=r.attributes,k=D.attributes;let V=0;const te=I.getAttributes();for(const H in te)if(te[H].location>=0){const re=B[H];let ge=k[H];if(ge===void 0&&(H==="instanceMatrix"&&b.instanceMatrix&&(ge=b.instanceMatrix),H==="instanceColor"&&b.instanceColor&&(ge=b.instanceColor)),re===void 0||re.attribute!==ge||ge&&re.data!==ge.data)return!0;V++}return r.attributesNum!==V||r.index!==U}function g(b,D,I,U){const B={},k=D.attributes;let V=0;const te=I.getAttributes();for(const H in te)if(te[H].location>=0){let re=k[H];re===void 0&&(H==="instanceMatrix"&&b.instanceMatrix&&(re=b.instanceMatrix),H==="instanceColor"&&b.instanceColor&&(re=b.instanceColor));const ge={};ge.attribute=re,re&&re.data&&(ge.data=re.data),B[H]=ge,V++}r.attributes=B,r.attributesNum=V,r.index=U}function _(){const b=r.newAttributes;for(let D=0,I=b.length;D<I;D++)b[D]=0}function m(b){p(b,0)}function p(b,D){const I=r.newAttributes,U=r.enabledAttributes,B=r.attributeDivisors;I[b]=1,U[b]===0&&(i.enableVertexAttribArray(b),U[b]=1),B[b]!==D&&(i.vertexAttribDivisor(b,D),B[b]=D)}function y(){const b=r.newAttributes,D=r.enabledAttributes;for(let I=0,U=D.length;I<U;I++)D[I]!==b[I]&&(i.disableVertexAttribArray(I),D[I]=0)}function x(b,D,I,U,B,k,V){V===!0?i.vertexAttribIPointer(b,D,I,B,k):i.vertexAttribPointer(b,D,I,U,B,k)}function v(b,D,I,U){_();const B=U.attributes,k=I.getAttributes(),V=D.defaultAttributeValues;for(const te in k){const H=k[te];if(H.location>=0){let Q=B[te];if(Q===void 0&&(te==="instanceMatrix"&&b.instanceMatrix&&(Q=b.instanceMatrix),te==="instanceColor"&&b.instanceColor&&(Q=b.instanceColor)),Q!==void 0){const re=Q.normalized,ge=Q.itemSize,xe=e.get(Q);if(xe===void 0)continue;const Qe=xe.buffer,ot=xe.type,qe=xe.bytesPerElement,J=ot===i.INT||ot===i.UNSIGNED_INT||Q.gpuType===hl;if(Q.isInterleavedBufferAttribute){const ee=Q.data,Se=ee.stride,Te=Q.offset;if(ee.isInstancedInterleavedBuffer){for(let Ee=0;Ee<H.locationSize;Ee++)p(H.location+Ee,ee.meshPerAttribute);b.isInstancedMesh!==!0&&U._maxInstanceCount===void 0&&(U._maxInstanceCount=ee.meshPerAttribute*ee.count)}else for(let Ee=0;Ee<H.locationSize;Ee++)m(H.location+Ee);i.bindBuffer(i.ARRAY_BUFFER,Qe);for(let Ee=0;Ee<H.locationSize;Ee++)x(H.location+Ee,ge/H.locationSize,ot,re,Se*qe,(Te+ge/H.locationSize*Ee)*qe,J)}else{if(Q.isInstancedBufferAttribute){for(let ee=0;ee<H.locationSize;ee++)p(H.location+ee,Q.meshPerAttribute);b.isInstancedMesh!==!0&&U._maxInstanceCount===void 0&&(U._maxInstanceCount=Q.meshPerAttribute*Q.count)}else for(let ee=0;ee<H.locationSize;ee++)m(H.location+ee);i.bindBuffer(i.ARRAY_BUFFER,Qe);for(let ee=0;ee<H.locationSize;ee++)x(H.location+ee,ge/H.locationSize,ot,re,ge*qe,ge/H.locationSize*ee*qe,J)}}else if(V!==void 0){const re=V[te];if(re!==void 0)switch(re.length){case 2:i.vertexAttrib2fv(H.location,re);break;case 3:i.vertexAttrib3fv(H.location,re);break;case 4:i.vertexAttrib4fv(H.location,re);break;default:i.vertexAttrib1fv(H.location,re)}}}}y()}function w(){T();for(const b in n){const D=n[b];for(const I in D){const U=D[I];for(const B in U)h(U[B].object),delete U[B];delete D[I]}delete n[b]}}function M(b){if(n[b.id]===void 0)return;const D=n[b.id];for(const I in D){const U=D[I];for(const B in U)h(U[B].object),delete U[B];delete D[I]}delete n[b.id]}function A(b){for(const D in n){const I=n[D];if(I[b.id]===void 0)continue;const U=I[b.id];for(const B in U)h(U[B].object),delete U[B];delete I[b.id]}}function T(){S(),o=!0,r!==s&&(r=s,c(r.object))}function S(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:a,reset:T,resetDefaultState:S,dispose:w,releaseStatesOfGeometry:M,releaseStatesOfProgram:A,initAttributes:_,enableAttribute:m,disableUnusedAttributes:y}}function Zg(i,e,t){let n;function s(c){n=c}function r(c,h){i.drawArrays(n,c,h),t.update(h,n,1)}function o(c,h,u){u!==0&&(i.drawArraysInstanced(n,c,h,u),t.update(h,n,u))}function a(c,h,u){if(u===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,u);let f=0;for(let g=0;g<u;g++)f+=h[g];t.update(f,n,1)}function l(c,h,u,d){if(u===0)return;const f=e.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<c.length;g++)o(c[g],h[g],d[g]);else{f.multiDrawArraysInstancedWEBGL(n,c,0,h,0,d,0,u);let g=0;for(let _=0;_<u;_++)g+=h[_]*d[_];t.update(g,n,1)}}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=l}function Jg(i,e,t,n){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const A=e.get("EXT_texture_filter_anisotropic");s=i.getParameter(A.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(A){return!(A!==bn&&n.convert(A)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(A){const T=A===er&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(A!==In&&n.convert(A)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&A!==Pn&&!T)}function l(A){if(A==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";A="mediump"}return A==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);const u=t.logarithmicDepthBuffer===!0,d=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),_=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),p=i.getParameter(i.MAX_VERTEX_ATTRIBS),y=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),x=i.getParameter(i.MAX_VARYING_VECTORS),v=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),w=g>0,M=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:u,reversedDepthBuffer:d,maxTextures:f,maxVertexTextures:g,maxTextureSize:_,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:y,maxVaryings:x,maxFragmentUniforms:v,vertexTextures:w,maxSamples:M}}function Qg(i){const e=this;let t=null,n=0,s=!1,r=!1;const o=new xi,a=new je,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){const f=u.length!==0||d||n!==0||s;return s=d,n=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){t=h(u,d,0)},this.setState=function(u,d,f){const g=u.clippingPlanes,_=u.clipIntersection,m=u.clipShadows,p=i.get(u);if(!s||g===null||g.length===0||r&&!m)r?h(null):c();else{const y=r?0:n,x=y*4;let v=p.clippingState||null;l.value=v,v=h(g,d,x,f);for(let w=0;w!==x;++w)v[w]=t[w];p.clippingState=v,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=y}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function h(u,d,f,g){const _=u!==null?u.length:0;let m=null;if(_!==0){if(m=l.value,g!==!0||m===null){const p=f+_*4,y=d.matrixWorldInverse;a.getNormalMatrix(y),(m===null||m.length<p)&&(m=new Float32Array(p));for(let x=0,v=f;x!==_;++x,v+=4)o.copy(u[x]).applyMatrix4(y,a),o.normal.toArray(m,v),m[v+3]=o.constant}l.value=m,l.needsUpdate=!0}return e.numPlanes=_,e.numIntersection=0,m}}function e0(i){let e=new WeakMap;function t(o,a){return a===ma?o.mapping=ls:a===ga&&(o.mapping=cs),o}function n(o){if(o&&o.isTexture){const a=o.mapping;if(a===ma||a===ga)if(e.has(o)){const l=e.get(o).texture;return t(l,o.mapping)}else{const l=o.image;if(l&&l.height>0){const c=new hf(l.height);return c.fromEquirectangularTexture(i,o),e.set(o,c),o.addEventListener("dispose",s),t(c.texture,o.mapping)}else return null}}return o}function s(o){const a=o.target;a.removeEventListener("dispose",s);const l=e.get(a);l!==void 0&&(e.delete(a),l.dispose())}function r(){e=new WeakMap}return{get:n,dispose:r}}const Ji=4,Oc=[.125,.215,.35,.446,.526,.582],Si=20,Go=new ou,Fc=new Oe;let Wo=null,Xo=0,$o=0,qo=!1;const yi=(1+Math.sqrt(5))/2,Yi=1/yi,Bc=[new P(-yi,Yi,0),new P(yi,Yi,0),new P(-Yi,0,yi),new P(Yi,0,yi),new P(0,yi,-Yi),new P(0,yi,Yi),new P(-1,1,-1),new P(1,1,-1),new P(-1,1,1),new P(1,1,1)],t0=new P;class zc{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,s=100,r={}){const{size:o=256,position:a=t0}=r;Wo=this._renderer.getRenderTarget(),Xo=this._renderer.getActiveCubeFace(),$o=this._renderer.getActiveMipmapLevel(),qo=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);const l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(e,n,s,l,a),t>0&&this._blur(l,0,0,t),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Hc(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Vc(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(Wo,Xo,$o),this._renderer.xr.enabled=qo,e.scissorTest=!1,Ur(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===ls||e.mapping===cs?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Wo=this._renderer.getRenderTarget(),Xo=this._renderer.getActiveCubeFace(),$o=this._renderer.getActiveMipmapLevel(),qo=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:Sn,minFilter:Sn,generateMipmaps:!1,type:er,format:bn,colorSpace:hs,depthBuffer:!1},s=kc(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=kc(e,t,n);const{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=n0(r)),this._blurMaterial=i0(r,e,t)}return s}_compileMaterial(e){const t=new Ne(this._lodPlanes[0],e);this._renderer.compile(t,Go)}_sceneToCubeUV(e,t,n,s,r){const l=new fn(90,1,t,n),c=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],u=this._renderer,d=u.autoClear,f=u.toneMapping;u.getClearColor(Fc),u.toneMapping=ci,u.autoClear=!1,u.state.buffers.depth.getReversed()&&(u.setRenderTarget(s),u.clearDepth(),u.setRenderTarget(null));const _=new mn({name:"PMREM.Background",side:jt,depthWrite:!1,depthTest:!1}),m=new Ne(new ms,_);let p=!1;const y=e.background;y?y.isColor&&(_.color.copy(y),e.background=null,p=!0):(_.color.copy(Fc),p=!0);for(let x=0;x<6;x++){const v=x%3;v===0?(l.up.set(0,c[x],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x+h[x],r.y,r.z)):v===1?(l.up.set(0,0,c[x]),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y+h[x],r.z)):(l.up.set(0,c[x],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y,r.z+h[x]));const w=this._cubeSize;Ur(s,v*w,x>2?w:0,w,w),u.setRenderTarget(s),p&&u.render(m,l),u.render(e,l)}m.geometry.dispose(),m.material.dispose(),u.toneMapping=f,u.autoClear=d,e.background=y}_textureToCubeUV(e,t){const n=this._renderer,s=e.mapping===ls||e.mapping===cs;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Hc()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Vc());const r=s?this._cubemapMaterial:this._equirectMaterial,o=new Ne(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=e;const l=this._cubeSize;Ur(t,0,0,3*l,2*l),n.setRenderTarget(t),n.render(o,Go)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const s=this._lodPlanes.length;for(let r=1;r<s;r++){const o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=Bc[(s-r-1)%Bc.length];this._blur(e,r-1,r,o,a)}t.autoClear=n}_blur(e,t,n,s,r){const o=this._pingPongRenderTarget;this._halfBlur(e,o,t,n,s,"latitudinal",r),this._halfBlur(o,e,n,n,s,"longitudinal",r)}_halfBlur(e,t,n,s,r,o,a){const l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const h=3,u=new Ne(this._lodPlanes[s],c),d=c.uniforms,f=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*Si-1),_=r/g,m=isFinite(r)?1+Math.floor(h*_):Si;m>Si&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${Si}`);const p=[];let y=0;for(let A=0;A<Si;++A){const T=A/_,S=Math.exp(-T*T/2);p.push(S),A===0?y+=S:A<m&&(y+=2*S)}for(let A=0;A<p.length;A++)p[A]=p[A]/y;d.envMap.value=e.texture,d.samples.value=m,d.weights.value=p,d.latitudinal.value=o==="latitudinal",a&&(d.poleAxis.value=a);const{_lodMax:x}=this;d.dTheta.value=g,d.mipInt.value=x-n;const v=this._sizeLods[s],w=3*v*(s>x-Ji?s-x+Ji:0),M=4*(this._cubeSize-v);Ur(t,w,M,3*v,2*v),l.setRenderTarget(t),l.render(u,Go)}}function n0(i){const e=[],t=[],n=[];let s=i;const r=i-Ji+1+Oc.length;for(let o=0;o<r;o++){const a=Math.pow(2,s);t.push(a);let l=1/a;o>i-Ji?l=Oc[o-i+Ji-1]:o===0&&(l=0),n.push(l);const c=1/(a-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,g=6,_=3,m=2,p=1,y=new Float32Array(_*g*f),x=new Float32Array(m*g*f),v=new Float32Array(p*g*f);for(let M=0;M<f;M++){const A=M%3*2/3-1,T=M>2?0:-1,S=[A,T,0,A+2/3,T,0,A+2/3,T+1,0,A,T,0,A+2/3,T+1,0,A,T+1,0];y.set(S,_*g*M),x.set(d,m*g*M);const b=[M,M,M,M,M,M];v.set(b,p*g*M)}const w=new it;w.setAttribute("position",new zt(y,_)),w.setAttribute("uv",new zt(x,m)),w.setAttribute("faceIndex",new zt(v,p)),e.push(w),s>Ji&&s--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function kc(i,e,t){const n=new Ti(i,e,t);return n.texture.mapping=no,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Ur(i,e,t,n,s){i.viewport.set(e,t,n,s),i.scissor.set(e,t,n,s)}function i0(i,e,t){const n=new Float32Array(Si),s=new P(0,1,0);return new nn({name:"SphericalGaussianBlur",defines:{n:Si,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Dl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:li,depthTest:!1,depthWrite:!1})}function Vc(){return new nn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Dl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:li,depthTest:!1,depthWrite:!1})}function Hc(){return new nn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Dl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:li,depthTest:!1,depthWrite:!1})}function Dl(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function s0(i){let e=new WeakMap,t=null;function n(a){if(a&&a.isTexture){const l=a.mapping,c=l===ma||l===ga,h=l===ls||l===cs;if(c||h){let u=e.get(a);const d=u!==void 0?u.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==d)return t===null&&(t=new zc(i)),u=c?t.fromEquirectangular(a,u):t.fromCubemap(a,u),u.texture.pmremVersion=a.pmremVersion,e.set(a,u),u.texture;if(u!==void 0)return u.texture;{const f=a.image;return c&&f&&f.height>0||h&&f&&s(f)?(t===null&&(t=new zc(i)),u=c?t.fromEquirectangular(a):t.fromCubemap(a),u.texture.pmremVersion=a.pmremVersion,e.set(a,u),a.addEventListener("dispose",r),u.texture):null}}}return a}function s(a){let l=0;const c=6;for(let h=0;h<c;h++)a[h]!==void 0&&l++;return l===c}function r(a){const l=a.target;l.removeEventListener("dispose",r);const c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:o}}function r0(i){const e={};function t(n){if(e[n]!==void 0)return e[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const s=t(n);return s===null&&$s("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function o0(i,e,t,n){const s={},r=new WeakMap;function o(u){const d=u.target;d.index!==null&&e.remove(d.index);for(const g in d.attributes)e.remove(d.attributes[g]);d.removeEventListener("dispose",o),delete s[d.id];const f=r.get(d);f&&(e.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,t.memory.geometries--}function a(u,d){return s[d.id]===!0||(d.addEventListener("dispose",o),s[d.id]=!0,t.memory.geometries++),d}function l(u){const d=u.attributes;for(const f in d)e.update(d[f],i.ARRAY_BUFFER)}function c(u){const d=[],f=u.index,g=u.attributes.position;let _=0;if(f!==null){const y=f.array;_=f.version;for(let x=0,v=y.length;x<v;x+=3){const w=y[x+0],M=y[x+1],A=y[x+2];d.push(w,M,M,A,A,w)}}else if(g!==void 0){const y=g.array;_=g.version;for(let x=0,v=y.length/3-1;x<v;x+=3){const w=x+0,M=x+1,A=x+2;d.push(w,M,M,A,A,w)}}else return;const m=new(Bh(d)?Hh:Vh)(d,1);m.version=_;const p=r.get(u);p&&e.remove(p),r.set(u,m)}function h(u){const d=r.get(u);if(d){const f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return r.get(u)}return{get:a,update:l,getWireframeAttribute:h}}function a0(i,e,t){let n;function s(d){n=d}let r,o;function a(d){r=d.type,o=d.bytesPerElement}function l(d,f){i.drawElements(n,f,r,d*o),t.update(f,n,1)}function c(d,f,g){g!==0&&(i.drawElementsInstanced(n,f,r,d*o,g),t.update(f,n,g))}function h(d,f,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,r,d,0,g);let m=0;for(let p=0;p<g;p++)m+=f[p];t.update(m,n,1)}function u(d,f,g,_){if(g===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<d.length;p++)c(d[p]/o,f[p],_[p]);else{m.multiDrawElementsInstancedWEBGL(n,f,0,r,d,0,_,0,g);let p=0;for(let y=0;y<g;y++)p+=f[y]*_[y];t.update(p,n,1)}}this.setMode=s,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function l0(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(t.calls++,o){case i.TRIANGLES:t.triangles+=a*(r/3);break;case i.LINES:t.lines+=a*(r/2);break;case i.LINE_STRIP:t.lines+=a*(r-1);break;case i.LINE_LOOP:t.lines+=a*r;break;case i.POINTS:t.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function c0(i,e,t){const n=new WeakMap,s=new at;function r(o,a,l){const c=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0;let d=n.get(a);if(d===void 0||d.count!==u){let S=function(){A.dispose(),n.delete(a),a.removeEventListener("dispose",S)};d!==void 0&&d.texture.dispose();const f=a.morphAttributes.position!==void 0,g=a.morphAttributes.normal!==void 0,_=a.morphAttributes.color!==void 0,m=a.morphAttributes.position||[],p=a.morphAttributes.normal||[],y=a.morphAttributes.color||[];let x=0;f===!0&&(x=1),g===!0&&(x=2),_===!0&&(x=3);let v=a.attributes.position.count*x,w=1;v>e.maxTextureSize&&(w=Math.ceil(v/e.maxTextureSize),v=e.maxTextureSize);const M=new Float32Array(v*w*4*u),A=new zh(M,v,w,u);A.type=Pn,A.needsUpdate=!0;const T=x*4;for(let b=0;b<u;b++){const D=m[b],I=p[b],U=y[b],B=v*w*4*b;for(let k=0;k<D.count;k++){const V=k*T;f===!0&&(s.fromBufferAttribute(D,k),M[B+V+0]=s.x,M[B+V+1]=s.y,M[B+V+2]=s.z,M[B+V+3]=0),g===!0&&(s.fromBufferAttribute(I,k),M[B+V+4]=s.x,M[B+V+5]=s.y,M[B+V+6]=s.z,M[B+V+7]=0),_===!0&&(s.fromBufferAttribute(U,k),M[B+V+8]=s.x,M[B+V+9]=s.y,M[B+V+10]=s.z,M[B+V+11]=U.itemSize===4?s.w:1)}}d={count:u,texture:A,size:new ue(v,w)},n.set(a,d),a.addEventListener("dispose",S)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",o.morphTexture,t);else{let f=0;for(let _=0;_<c.length;_++)f+=c[_];const g=a.morphTargetsRelative?1:1-f;l.getUniforms().setValue(i,"morphTargetBaseInfluence",g),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",d.texture,t),l.getUniforms().setValue(i,"morphTargetsTextureSize",d.size)}return{update:r}}function h0(i,e,t,n){let s=new WeakMap;function r(l){const c=n.render.frame,h=l.geometry,u=e.get(l,h);if(s.get(u)!==c&&(e.update(u),s.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),s.get(l)!==c&&(t.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){const d=l.skeleton;s.get(d)!==c&&(d.update(),s.set(d,c))}return u}function o(){s=new WeakMap}function a(l){const c=l.target;c.removeEventListener("dispose",a),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:r,dispose:o}}const lu=new Xt,Gc=new Yh(1,1),cu=new zh,hu=new qd,uu=new Xh,Wc=[],Xc=[],$c=new Float32Array(16),qc=new Float32Array(9),Yc=new Float32Array(4);function vs(i,e,t){const n=i[0];if(n<=0||n>0)return i;const s=e*t;let r=Wc[s];if(r===void 0&&(r=new Float32Array(s),Wc[s]=r),e!==0){n.toArray(r,0);for(let o=1,a=0;o!==e;++o)a+=t,i[o].toArray(r,a)}return r}function Dt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function It(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function ao(i,e){let t=Xc[e];t===void 0&&(t=new Int32Array(e),Xc[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function u0(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function d0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Dt(t,e))return;i.uniform2fv(this.addr,e),It(t,e)}}function f0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Dt(t,e))return;i.uniform3fv(this.addr,e),It(t,e)}}function p0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Dt(t,e))return;i.uniform4fv(this.addr,e),It(t,e)}}function m0(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Dt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),It(t,e)}else{if(Dt(t,n))return;Yc.set(n),i.uniformMatrix2fv(this.addr,!1,Yc),It(t,n)}}function g0(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Dt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),It(t,e)}else{if(Dt(t,n))return;qc.set(n),i.uniformMatrix3fv(this.addr,!1,qc),It(t,n)}}function v0(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Dt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),It(t,e)}else{if(Dt(t,n))return;$c.set(n),i.uniformMatrix4fv(this.addr,!1,$c),It(t,n)}}function _0(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function x0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Dt(t,e))return;i.uniform2iv(this.addr,e),It(t,e)}}function y0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Dt(t,e))return;i.uniform3iv(this.addr,e),It(t,e)}}function M0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Dt(t,e))return;i.uniform4iv(this.addr,e),It(t,e)}}function S0(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function b0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Dt(t,e))return;i.uniform2uiv(this.addr,e),It(t,e)}}function w0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Dt(t,e))return;i.uniform3uiv(this.addr,e),It(t,e)}}function E0(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Dt(t,e))return;i.uniform4uiv(this.addr,e),It(t,e)}}function A0(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(Gc.compareFunction=Fh,r=Gc):r=lu,t.setTexture2D(e||r,s)}function T0(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||hu,s)}function C0(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTextureCube(e||uu,s)}function R0(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||cu,s)}function P0(i){switch(i){case 5126:return u0;case 35664:return d0;case 35665:return f0;case 35666:return p0;case 35674:return m0;case 35675:return g0;case 35676:return v0;case 5124:case 35670:return _0;case 35667:case 35671:return x0;case 35668:case 35672:return y0;case 35669:case 35673:return M0;case 5125:return S0;case 36294:return b0;case 36295:return w0;case 36296:return E0;case 35678:case 36198:case 36298:case 36306:case 35682:return A0;case 35679:case 36299:case 36307:return T0;case 35680:case 36300:case 36308:case 36293:return C0;case 36289:case 36303:case 36311:case 36292:return R0}}function L0(i,e){i.uniform1fv(this.addr,e)}function D0(i,e){const t=vs(e,this.size,2);i.uniform2fv(this.addr,t)}function I0(i,e){const t=vs(e,this.size,3);i.uniform3fv(this.addr,t)}function U0(i,e){const t=vs(e,this.size,4);i.uniform4fv(this.addr,t)}function N0(i,e){const t=vs(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function O0(i,e){const t=vs(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function F0(i,e){const t=vs(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function B0(i,e){i.uniform1iv(this.addr,e)}function z0(i,e){i.uniform2iv(this.addr,e)}function k0(i,e){i.uniform3iv(this.addr,e)}function V0(i,e){i.uniform4iv(this.addr,e)}function H0(i,e){i.uniform1uiv(this.addr,e)}function G0(i,e){i.uniform2uiv(this.addr,e)}function W0(i,e){i.uniform3uiv(this.addr,e)}function X0(i,e){i.uniform4uiv(this.addr,e)}function $0(i,e,t){const n=this.cache,s=e.length,r=ao(t,s);Dt(n,r)||(i.uniform1iv(this.addr,r),It(n,r));for(let o=0;o!==s;++o)t.setTexture2D(e[o]||lu,r[o])}function q0(i,e,t){const n=this.cache,s=e.length,r=ao(t,s);Dt(n,r)||(i.uniform1iv(this.addr,r),It(n,r));for(let o=0;o!==s;++o)t.setTexture3D(e[o]||hu,r[o])}function Y0(i,e,t){const n=this.cache,s=e.length,r=ao(t,s);Dt(n,r)||(i.uniform1iv(this.addr,r),It(n,r));for(let o=0;o!==s;++o)t.setTextureCube(e[o]||uu,r[o])}function j0(i,e,t){const n=this.cache,s=e.length,r=ao(t,s);Dt(n,r)||(i.uniform1iv(this.addr,r),It(n,r));for(let o=0;o!==s;++o)t.setTexture2DArray(e[o]||cu,r[o])}function K0(i){switch(i){case 5126:return L0;case 35664:return D0;case 35665:return I0;case 35666:return U0;case 35674:return N0;case 35675:return O0;case 35676:return F0;case 5124:case 35670:return B0;case 35667:case 35671:return z0;case 35668:case 35672:return k0;case 35669:case 35673:return V0;case 5125:return H0;case 36294:return G0;case 36295:return W0;case 36296:return X0;case 35678:case 36198:case 36298:case 36306:case 35682:return $0;case 35679:case 36299:case 36307:return q0;case 35680:case 36300:case 36308:case 36293:return Y0;case 36289:case 36303:case 36311:case 36292:return j0}}class Z0{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=P0(t.type)}}class J0{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=K0(t.type)}}class Q0{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const s=this.seq;for(let r=0,o=s.length;r!==o;++r){const a=s[r];a.setValue(e,t[a.id],n)}}}const Yo=/(\w+)(\])?(\[|\.)?/g;function jc(i,e){i.seq.push(e),i.map[e.id]=e}function ev(i,e,t){const n=i.name,s=n.length;for(Yo.lastIndex=0;;){const r=Yo.exec(n),o=Yo.lastIndex;let a=r[1];const l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===s){jc(t,c===void 0?new Z0(a,i,e):new J0(a,i,e));break}else{let u=t.map[a];u===void 0&&(u=new Q0(a),jc(t,u)),t=u}}}class qr{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){const r=e.getActiveUniform(t,s),o=e.getUniformLocation(t,r.name);ev(r,o,this)}}setValue(e,t,n,s){const r=this.map[t];r!==void 0&&r.setValue(e,n,s)}setOptional(e,t,n){const s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let r=0,o=t.length;r!==o;++r){const a=t[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(e,l.value,s)}}static seqWithValue(e,t){const n=[];for(let s=0,r=e.length;s!==r;++s){const o=e[s];o.id in t&&n.push(o)}return n}}function Kc(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const tv=37297;let nv=0;function iv(i,e){const t=i.split(`
`),n=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let o=s;o<r;o++){const a=o+1;n.push(`${a===e?">":" "} ${a}: ${t[o]}`)}return n.join(`
`)}const Zc=new je;function sv(i){ht._getMatrix(Zc,ht.workingColorSpace,i);const e=`mat3( ${Zc.elements.map(t=>t.toFixed(4))} )`;switch(ht.getTransfer(i)){case jr:return[e,"LinearTransferOETF"];case gt:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function Jc(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),r=(i.getShaderInfoLog(e)||"").trim();if(n&&r==="")return"";const o=/ERROR: 0:(\d+)/.exec(r);if(o){const a=parseInt(o[1]);return t.toUpperCase()+`

`+r+`

`+iv(i.getShaderSource(e),a)}else return r}function rv(i,e){const t=sv(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function ov(i,e){let t;switch(e){case od:t="Linear";break;case ad:t="Reinhard";break;case ld:t="Cineon";break;case Ch:t="ACESFilmic";break;case hd:t="AgX";break;case ud:t="Neutral";break;case cd:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const Nr=new P;function av(){ht.getLuminanceCoefficients(Nr);const i=Nr.x.toFixed(4),e=Nr.y.toFixed(4),t=Nr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function lv(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Ls).join(`
`)}function cv(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function hv(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const r=i.getActiveAttrib(e,s),o=r.name;let a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),t[o]={type:r.type,location:i.getAttribLocation(e,o),locationSize:a}}return t}function Ls(i){return i!==""}function Qc(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function eh(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const uv=/^[ \t]*#include +<([\w\d./]+)>/gm;function Qa(i){return i.replace(uv,fv)}const dv=new Map;function fv(i,e){let t=Je[e];if(t===void 0){const n=dv.get(e);if(n!==void 0)t=Je[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return Qa(t)}const pv=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function th(i){return i.replace(pv,mv)}function mv(i,e,t,n){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function nh(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function gv(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Ah?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===Th?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===Hn&&(e="SHADOWMAP_TYPE_VSM"),e}function vv(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case ls:case cs:e="ENVMAP_TYPE_CUBE";break;case no:e="ENVMAP_TYPE_CUBE_UV";break}return e}function _v(i){let e="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case cs:e="ENVMAP_MODE_REFRACTION";break}return e}function xv(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case cl:e="ENVMAP_BLENDING_MULTIPLY";break;case sd:e="ENVMAP_BLENDING_MIX";break;case rd:e="ENVMAP_BLENDING_ADD";break}return e}function yv(i){const e=i.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function Mv(i,e,t,n){const s=i.getContext(),r=t.defines;let o=t.vertexShader,a=t.fragmentShader;const l=gv(t),c=vv(t),h=_v(t),u=xv(t),d=yv(t),f=lv(t),g=cv(r),_=s.createProgram();let m,p,y=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Ls).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Ls).join(`
`),p.length>0&&(p+=`
`)):(m=[nh(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ls).join(`
`),p=[nh(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==ci?"#define TONE_MAPPING":"",t.toneMapping!==ci?Je.tonemapping_pars_fragment:"",t.toneMapping!==ci?ov("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Je.colorspace_pars_fragment,rv("linearToOutputTexel",t.outputColorSpace),av(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Ls).join(`
`)),o=Qa(o),o=Qc(o,t),o=eh(o,t),a=Qa(a),a=Qc(a,t),a=eh(a,t),o=th(o),a=th(a),t.isRawShaderMaterial!==!0&&(y=`#version 300 es
`,m=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",t.glslVersion===Zl?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Zl?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);const x=y+m+o,v=y+p+a,w=Kc(s,s.VERTEX_SHADER,x),M=Kc(s,s.FRAGMENT_SHADER,v);s.attachShader(_,w),s.attachShader(_,M),t.index0AttributeName!==void 0?s.bindAttribLocation(_,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(_,0,"position"),s.linkProgram(_);function A(D){if(i.debug.checkShaderErrors){const I=s.getProgramInfoLog(_)||"",U=s.getShaderInfoLog(w)||"",B=s.getShaderInfoLog(M)||"",k=I.trim(),V=U.trim(),te=B.trim();let H=!0,Q=!0;if(s.getProgramParameter(_,s.LINK_STATUS)===!1)if(H=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,_,w,M);else{const re=Jc(s,w,"vertex"),ge=Jc(s,M,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(_,s.VALIDATE_STATUS)+`

Material Name: `+D.name+`
Material Type: `+D.type+`

Program Info Log: `+k+`
`+re+`
`+ge)}else k!==""?console.warn("THREE.WebGLProgram: Program Info Log:",k):(V===""||te==="")&&(Q=!1);Q&&(D.diagnostics={runnable:H,programLog:k,vertexShader:{log:V,prefix:m},fragmentShader:{log:te,prefix:p}})}s.deleteShader(w),s.deleteShader(M),T=new qr(s,_),S=hv(s,_)}let T;this.getUniforms=function(){return T===void 0&&A(this),T};let S;this.getAttributes=function(){return S===void 0&&A(this),S};let b=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return b===!1&&(b=s.getProgramParameter(_,tv)),b},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(_),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=nv++,this.cacheKey=e,this.usedTimes=1,this.program=_,this.vertexShader=w,this.fragmentShader=M,this}let Sv=0;class bv{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,s=this._getShaderStage(t),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(e);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new wv(e),t.set(e,n)),n}}class wv{constructor(e){this.id=Sv++,this.code=e,this.usedTimes=0}}function Ev(i,e,t,n,s,r,o){const a=new yl,l=new bv,c=new Set,h=[],u=s.logarithmicDepthBuffer,d=s.vertexTextures;let f=s.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(S){return c.add(S),S===0?"uv":`uv${S}`}function m(S,b,D,I,U){const B=I.fog,k=U.geometry,V=S.isMeshStandardMaterial?I.environment:null,te=(S.isMeshStandardMaterial?t:e).get(S.envMap||V),H=te&&te.mapping===no?te.image.height:null,Q=g[S.type];S.precision!==null&&(f=s.getMaxPrecision(S.precision),f!==S.precision&&console.warn("THREE.WebGLProgram.getParameters:",S.precision,"not supported, using",f,"instead."));const re=k.morphAttributes.position||k.morphAttributes.normal||k.morphAttributes.color,ge=re!==void 0?re.length:0;let xe=0;k.morphAttributes.position!==void 0&&(xe=1),k.morphAttributes.normal!==void 0&&(xe=2),k.morphAttributes.color!==void 0&&(xe=3);let Qe,ot,qe,J;if(Q){const dt=Jt[Q];Qe=dt.vertexShader,ot=dt.fragmentShader}else Qe=S.vertexShader,ot=S.fragmentShader,l.update(S),qe=l.getVertexShaderID(S),J=l.getFragmentShaderID(S);const ee=i.getRenderTarget(),Se=i.state.buffers.depth.getReversed(),Te=U.isInstancedMesh===!0,Ee=U.isBatchedMesh===!0,et=!!S.map,Ie=!!S.matcap,L=!!te,Z=!!S.aoMap,j=!!S.lightMap,Y=!!S.bumpMap,K=!!S.normalMap,he=!!S.displacementMap,se=!!S.emissiveMap,fe=!!S.metalnessMap,Xe=!!S.roughnessMap,Ge=S.anisotropy>0,R=S.clearcoat>0,E=S.dispersion>0,z=S.iridescence>0,X=S.sheen>0,ie=S.transmission>0,$=Ge&&!!S.anisotropyMap,De=R&&!!S.clearcoatMap,de=R&&!!S.clearcoatNormalMap,Re=R&&!!S.clearcoatRoughnessMap,Pe=z&&!!S.iridescenceMap,oe=z&&!!S.iridescenceThicknessMap,ye=X&&!!S.sheenColorMap,Ve=X&&!!S.sheenRoughnessMap,Ue=!!S.specularMap,ve=!!S.specularColorMap,Ye=!!S.specularIntensityMap,N=ie&&!!S.transmissionMap,ce=ie&&!!S.thicknessMap,pe=!!S.gradientMap,Ae=!!S.alphaMap,ae=S.alphaTest>0,ne=!!S.alphaHash,Le=!!S.extensions;let $e=ci;S.toneMapped&&(ee===null||ee.isXRRenderTarget===!0)&&($e=i.toneMapping);const _t={shaderID:Q,shaderType:S.type,shaderName:S.name,vertexShader:Qe,fragmentShader:ot,defines:S.defines,customVertexShaderID:qe,customFragmentShaderID:J,isRawShaderMaterial:S.isRawShaderMaterial===!0,glslVersion:S.glslVersion,precision:f,batching:Ee,batchingColor:Ee&&U._colorsTexture!==null,instancing:Te,instancingColor:Te&&U.instanceColor!==null,instancingMorph:Te&&U.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:ee===null?i.outputColorSpace:ee.isXRRenderTarget===!0?ee.texture.colorSpace:hs,alphaToCoverage:!!S.alphaToCoverage,map:et,matcap:Ie,envMap:L,envMapMode:L&&te.mapping,envMapCubeUVHeight:H,aoMap:Z,lightMap:j,bumpMap:Y,normalMap:K,displacementMap:d&&he,emissiveMap:se,normalMapObjectSpace:K&&S.normalMapType===md,normalMapTangentSpace:K&&S.normalMapType===vl,metalnessMap:fe,roughnessMap:Xe,anisotropy:Ge,anisotropyMap:$,clearcoat:R,clearcoatMap:De,clearcoatNormalMap:de,clearcoatRoughnessMap:Re,dispersion:E,iridescence:z,iridescenceMap:Pe,iridescenceThicknessMap:oe,sheen:X,sheenColorMap:ye,sheenRoughnessMap:Ve,specularMap:Ue,specularColorMap:ve,specularIntensityMap:Ye,transmission:ie,transmissionMap:N,thicknessMap:ce,gradientMap:pe,opaque:S.transparent===!1&&S.blending===es&&S.alphaToCoverage===!1,alphaMap:Ae,alphaTest:ae,alphaHash:ne,combine:S.combine,mapUv:et&&_(S.map.channel),aoMapUv:Z&&_(S.aoMap.channel),lightMapUv:j&&_(S.lightMap.channel),bumpMapUv:Y&&_(S.bumpMap.channel),normalMapUv:K&&_(S.normalMap.channel),displacementMapUv:he&&_(S.displacementMap.channel),emissiveMapUv:se&&_(S.emissiveMap.channel),metalnessMapUv:fe&&_(S.metalnessMap.channel),roughnessMapUv:Xe&&_(S.roughnessMap.channel),anisotropyMapUv:$&&_(S.anisotropyMap.channel),clearcoatMapUv:De&&_(S.clearcoatMap.channel),clearcoatNormalMapUv:de&&_(S.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Re&&_(S.clearcoatRoughnessMap.channel),iridescenceMapUv:Pe&&_(S.iridescenceMap.channel),iridescenceThicknessMapUv:oe&&_(S.iridescenceThicknessMap.channel),sheenColorMapUv:ye&&_(S.sheenColorMap.channel),sheenRoughnessMapUv:Ve&&_(S.sheenRoughnessMap.channel),specularMapUv:Ue&&_(S.specularMap.channel),specularColorMapUv:ve&&_(S.specularColorMap.channel),specularIntensityMapUv:Ye&&_(S.specularIntensityMap.channel),transmissionMapUv:N&&_(S.transmissionMap.channel),thicknessMapUv:ce&&_(S.thicknessMap.channel),alphaMapUv:Ae&&_(S.alphaMap.channel),vertexTangents:!!k.attributes.tangent&&(K||Ge),vertexColors:S.vertexColors,vertexAlphas:S.vertexColors===!0&&!!k.attributes.color&&k.attributes.color.itemSize===4,pointsUvs:U.isPoints===!0&&!!k.attributes.uv&&(et||Ae),fog:!!B,useFog:S.fog===!0,fogExp2:!!B&&B.isFogExp2,flatShading:S.flatShading===!0&&S.wireframe===!1,sizeAttenuation:S.sizeAttenuation===!0,logarithmicDepthBuffer:u,reversedDepthBuffer:Se,skinning:U.isSkinnedMesh===!0,morphTargets:k.morphAttributes.position!==void 0,morphNormals:k.morphAttributes.normal!==void 0,morphColors:k.morphAttributes.color!==void 0,morphTargetsCount:ge,morphTextureStride:xe,numDirLights:b.directional.length,numPointLights:b.point.length,numSpotLights:b.spot.length,numSpotLightMaps:b.spotLightMap.length,numRectAreaLights:b.rectArea.length,numHemiLights:b.hemi.length,numDirLightShadows:b.directionalShadowMap.length,numPointLightShadows:b.pointShadowMap.length,numSpotLightShadows:b.spotShadowMap.length,numSpotLightShadowsWithMaps:b.numSpotLightShadowsWithMaps,numLightProbes:b.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:S.dithering,shadowMapEnabled:i.shadowMap.enabled&&D.length>0,shadowMapType:i.shadowMap.type,toneMapping:$e,decodeVideoTexture:et&&S.map.isVideoTexture===!0&&ht.getTransfer(S.map.colorSpace)===gt,decodeVideoTextureEmissive:se&&S.emissiveMap.isVideoTexture===!0&&ht.getTransfer(S.emissiveMap.colorSpace)===gt,premultipliedAlpha:S.premultipliedAlpha,doubleSided:S.side===wt,flipSided:S.side===jt,useDepthPacking:S.depthPacking>=0,depthPacking:S.depthPacking||0,index0AttributeName:S.index0AttributeName,extensionClipCullDistance:Le&&S.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Le&&S.extensions.multiDraw===!0||Ee)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:S.customProgramCacheKey()};return _t.vertexUv1s=c.has(1),_t.vertexUv2s=c.has(2),_t.vertexUv3s=c.has(3),c.clear(),_t}function p(S){const b=[];if(S.shaderID?b.push(S.shaderID):(b.push(S.customVertexShaderID),b.push(S.customFragmentShaderID)),S.defines!==void 0)for(const D in S.defines)b.push(D),b.push(S.defines[D]);return S.isRawShaderMaterial===!1&&(y(b,S),x(b,S),b.push(i.outputColorSpace)),b.push(S.customProgramCacheKey),b.join()}function y(S,b){S.push(b.precision),S.push(b.outputColorSpace),S.push(b.envMapMode),S.push(b.envMapCubeUVHeight),S.push(b.mapUv),S.push(b.alphaMapUv),S.push(b.lightMapUv),S.push(b.aoMapUv),S.push(b.bumpMapUv),S.push(b.normalMapUv),S.push(b.displacementMapUv),S.push(b.emissiveMapUv),S.push(b.metalnessMapUv),S.push(b.roughnessMapUv),S.push(b.anisotropyMapUv),S.push(b.clearcoatMapUv),S.push(b.clearcoatNormalMapUv),S.push(b.clearcoatRoughnessMapUv),S.push(b.iridescenceMapUv),S.push(b.iridescenceThicknessMapUv),S.push(b.sheenColorMapUv),S.push(b.sheenRoughnessMapUv),S.push(b.specularMapUv),S.push(b.specularColorMapUv),S.push(b.specularIntensityMapUv),S.push(b.transmissionMapUv),S.push(b.thicknessMapUv),S.push(b.combine),S.push(b.fogExp2),S.push(b.sizeAttenuation),S.push(b.morphTargetsCount),S.push(b.morphAttributeCount),S.push(b.numDirLights),S.push(b.numPointLights),S.push(b.numSpotLights),S.push(b.numSpotLightMaps),S.push(b.numHemiLights),S.push(b.numRectAreaLights),S.push(b.numDirLightShadows),S.push(b.numPointLightShadows),S.push(b.numSpotLightShadows),S.push(b.numSpotLightShadowsWithMaps),S.push(b.numLightProbes),S.push(b.shadowMapType),S.push(b.toneMapping),S.push(b.numClippingPlanes),S.push(b.numClipIntersection),S.push(b.depthPacking)}function x(S,b){a.disableAll(),b.supportsVertexTextures&&a.enable(0),b.instancing&&a.enable(1),b.instancingColor&&a.enable(2),b.instancingMorph&&a.enable(3),b.matcap&&a.enable(4),b.envMap&&a.enable(5),b.normalMapObjectSpace&&a.enable(6),b.normalMapTangentSpace&&a.enable(7),b.clearcoat&&a.enable(8),b.iridescence&&a.enable(9),b.alphaTest&&a.enable(10),b.vertexColors&&a.enable(11),b.vertexAlphas&&a.enable(12),b.vertexUv1s&&a.enable(13),b.vertexUv2s&&a.enable(14),b.vertexUv3s&&a.enable(15),b.vertexTangents&&a.enable(16),b.anisotropy&&a.enable(17),b.alphaHash&&a.enable(18),b.batching&&a.enable(19),b.dispersion&&a.enable(20),b.batchingColor&&a.enable(21),b.gradientMap&&a.enable(22),S.push(a.mask),a.disableAll(),b.fog&&a.enable(0),b.useFog&&a.enable(1),b.flatShading&&a.enable(2),b.logarithmicDepthBuffer&&a.enable(3),b.reversedDepthBuffer&&a.enable(4),b.skinning&&a.enable(5),b.morphTargets&&a.enable(6),b.morphNormals&&a.enable(7),b.morphColors&&a.enable(8),b.premultipliedAlpha&&a.enable(9),b.shadowMapEnabled&&a.enable(10),b.doubleSided&&a.enable(11),b.flipSided&&a.enable(12),b.useDepthPacking&&a.enable(13),b.dithering&&a.enable(14),b.transmission&&a.enable(15),b.sheen&&a.enable(16),b.opaque&&a.enable(17),b.pointsUvs&&a.enable(18),b.decodeVideoTexture&&a.enable(19),b.decodeVideoTextureEmissive&&a.enable(20),b.alphaToCoverage&&a.enable(21),S.push(a.mask)}function v(S){const b=g[S.type];let D;if(b){const I=Jt[b];D=Ml.clone(I.uniforms)}else D=S.uniforms;return D}function w(S,b){let D;for(let I=0,U=h.length;I<U;I++){const B=h[I];if(B.cacheKey===b){D=B,++D.usedTimes;break}}return D===void 0&&(D=new Mv(i,b,S,r),h.push(D)),D}function M(S){if(--S.usedTimes===0){const b=h.indexOf(S);h[b]=h[h.length-1],h.pop(),S.destroy()}}function A(S){l.remove(S)}function T(){l.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:v,acquireProgram:w,releaseProgram:M,releaseShaderCache:A,programs:h,dispose:T}}function Av(){let i=new WeakMap;function e(o){return i.has(o)}function t(o){let a=i.get(o);return a===void 0&&(a={},i.set(o,a)),a}function n(o){i.delete(o)}function s(o,a,l){i.get(o)[a]=l}function r(){i=new WeakMap}return{has:e,get:t,remove:n,update:s,dispose:r}}function Tv(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function ih(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function sh(){const i=[];let e=0;const t=[],n=[],s=[];function r(){e=0,t.length=0,n.length=0,s.length=0}function o(u,d,f,g,_,m){let p=i[e];return p===void 0?(p={id:u.id,object:u,geometry:d,material:f,groupOrder:g,renderOrder:u.renderOrder,z:_,group:m},i[e]=p):(p.id=u.id,p.object=u,p.geometry=d,p.material=f,p.groupOrder=g,p.renderOrder=u.renderOrder,p.z=_,p.group=m),e++,p}function a(u,d,f,g,_,m){const p=o(u,d,f,g,_,m);f.transmission>0?n.push(p):f.transparent===!0?s.push(p):t.push(p)}function l(u,d,f,g,_,m){const p=o(u,d,f,g,_,m);f.transmission>0?n.unshift(p):f.transparent===!0?s.unshift(p):t.unshift(p)}function c(u,d){t.length>1&&t.sort(u||Tv),n.length>1&&n.sort(d||ih),s.length>1&&s.sort(d||ih)}function h(){for(let u=e,d=i.length;u<d;u++){const f=i[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:t,transmissive:n,transparent:s,init:r,push:a,unshift:l,finish:h,sort:c}}function Cv(){let i=new WeakMap;function e(n,s){const r=i.get(n);let o;return r===void 0?(o=new sh,i.set(n,[o])):s>=r.length?(o=new sh,r.push(o)):o=r[s],o}function t(){i=new WeakMap}return{get:e,dispose:t}}function Rv(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new P,color:new Oe};break;case"SpotLight":t={position:new P,direction:new P,color:new Oe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new P,color:new Oe,distance:0,decay:0};break;case"HemisphereLight":t={direction:new P,skyColor:new Oe,groundColor:new Oe};break;case"RectAreaLight":t={color:new Oe,position:new P,halfWidth:new P,halfHeight:new P};break}return i[e.id]=t,t}}}function Pv(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ue};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ue};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ue,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let Lv=0;function Dv(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function Iv(i){const e=new Rv,t=Pv(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new P);const s=new P,r=new st,o=new st;function a(c){let h=0,u=0,d=0;for(let S=0;S<9;S++)n.probe[S].set(0,0,0);let f=0,g=0,_=0,m=0,p=0,y=0,x=0,v=0,w=0,M=0,A=0;c.sort(Dv);for(let S=0,b=c.length;S<b;S++){const D=c[S],I=D.color,U=D.intensity,B=D.distance,k=D.shadow&&D.shadow.map?D.shadow.map.texture:null;if(D.isAmbientLight)h+=I.r*U,u+=I.g*U,d+=I.b*U;else if(D.isLightProbe){for(let V=0;V<9;V++)n.probe[V].addScaledVector(D.sh.coefficients[V],U);A++}else if(D.isDirectionalLight){const V=e.get(D);if(V.color.copy(D.color).multiplyScalar(D.intensity),D.castShadow){const te=D.shadow,H=t.get(D);H.shadowIntensity=te.intensity,H.shadowBias=te.bias,H.shadowNormalBias=te.normalBias,H.shadowRadius=te.radius,H.shadowMapSize=te.mapSize,n.directionalShadow[f]=H,n.directionalShadowMap[f]=k,n.directionalShadowMatrix[f]=D.shadow.matrix,y++}n.directional[f]=V,f++}else if(D.isSpotLight){const V=e.get(D);V.position.setFromMatrixPosition(D.matrixWorld),V.color.copy(I).multiplyScalar(U),V.distance=B,V.coneCos=Math.cos(D.angle),V.penumbraCos=Math.cos(D.angle*(1-D.penumbra)),V.decay=D.decay,n.spot[_]=V;const te=D.shadow;if(D.map&&(n.spotLightMap[w]=D.map,w++,te.updateMatrices(D),D.castShadow&&M++),n.spotLightMatrix[_]=te.matrix,D.castShadow){const H=t.get(D);H.shadowIntensity=te.intensity,H.shadowBias=te.bias,H.shadowNormalBias=te.normalBias,H.shadowRadius=te.radius,H.shadowMapSize=te.mapSize,n.spotShadow[_]=H,n.spotShadowMap[_]=k,v++}_++}else if(D.isRectAreaLight){const V=e.get(D);V.color.copy(I).multiplyScalar(U),V.halfWidth.set(D.width*.5,0,0),V.halfHeight.set(0,D.height*.5,0),n.rectArea[m]=V,m++}else if(D.isPointLight){const V=e.get(D);if(V.color.copy(D.color).multiplyScalar(D.intensity),V.distance=D.distance,V.decay=D.decay,D.castShadow){const te=D.shadow,H=t.get(D);H.shadowIntensity=te.intensity,H.shadowBias=te.bias,H.shadowNormalBias=te.normalBias,H.shadowRadius=te.radius,H.shadowMapSize=te.mapSize,H.shadowCameraNear=te.camera.near,H.shadowCameraFar=te.camera.far,n.pointShadow[g]=H,n.pointShadowMap[g]=k,n.pointShadowMatrix[g]=D.shadow.matrix,x++}n.point[g]=V,g++}else if(D.isHemisphereLight){const V=e.get(D);V.skyColor.copy(D.color).multiplyScalar(U),V.groundColor.copy(D.groundColor).multiplyScalar(U),n.hemi[p]=V,p++}}m>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=me.LTC_FLOAT_1,n.rectAreaLTC2=me.LTC_FLOAT_2):(n.rectAreaLTC1=me.LTC_HALF_1,n.rectAreaLTC2=me.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;const T=n.hash;(T.directionalLength!==f||T.pointLength!==g||T.spotLength!==_||T.rectAreaLength!==m||T.hemiLength!==p||T.numDirectionalShadows!==y||T.numPointShadows!==x||T.numSpotShadows!==v||T.numSpotMaps!==w||T.numLightProbes!==A)&&(n.directional.length=f,n.spot.length=_,n.rectArea.length=m,n.point.length=g,n.hemi.length=p,n.directionalShadow.length=y,n.directionalShadowMap.length=y,n.pointShadow.length=x,n.pointShadowMap.length=x,n.spotShadow.length=v,n.spotShadowMap.length=v,n.directionalShadowMatrix.length=y,n.pointShadowMatrix.length=x,n.spotLightMatrix.length=v+w-M,n.spotLightMap.length=w,n.numSpotLightShadowsWithMaps=M,n.numLightProbes=A,T.directionalLength=f,T.pointLength=g,T.spotLength=_,T.rectAreaLength=m,T.hemiLength=p,T.numDirectionalShadows=y,T.numPointShadows=x,T.numSpotShadows=v,T.numSpotMaps=w,T.numLightProbes=A,n.version=Lv++)}function l(c,h){let u=0,d=0,f=0,g=0,_=0;const m=h.matrixWorldInverse;for(let p=0,y=c.length;p<y;p++){const x=c[p];if(x.isDirectionalLight){const v=n.directional[u];v.direction.setFromMatrixPosition(x.matrixWorld),s.setFromMatrixPosition(x.target.matrixWorld),v.direction.sub(s),v.direction.transformDirection(m),u++}else if(x.isSpotLight){const v=n.spot[f];v.position.setFromMatrixPosition(x.matrixWorld),v.position.applyMatrix4(m),v.direction.setFromMatrixPosition(x.matrixWorld),s.setFromMatrixPosition(x.target.matrixWorld),v.direction.sub(s),v.direction.transformDirection(m),f++}else if(x.isRectAreaLight){const v=n.rectArea[g];v.position.setFromMatrixPosition(x.matrixWorld),v.position.applyMatrix4(m),o.identity(),r.copy(x.matrixWorld),r.premultiply(m),o.extractRotation(r),v.halfWidth.set(x.width*.5,0,0),v.halfHeight.set(0,x.height*.5,0),v.halfWidth.applyMatrix4(o),v.halfHeight.applyMatrix4(o),g++}else if(x.isPointLight){const v=n.point[d];v.position.setFromMatrixPosition(x.matrixWorld),v.position.applyMatrix4(m),d++}else if(x.isHemisphereLight){const v=n.hemi[_];v.direction.setFromMatrixPosition(x.matrixWorld),v.direction.transformDirection(m),_++}}}return{setup:a,setupView:l,state:n}}function rh(i){const e=new Iv(i),t=[],n=[];function s(h){c.camera=h,t.length=0,n.length=0}function r(h){t.push(h)}function o(h){n.push(h)}function a(){e.setup(t)}function l(h){e.setupView(t,h)}const c={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:s,state:c,setupLights:a,setupLightsView:l,pushLight:r,pushShadow:o}}function Uv(i){let e=new WeakMap;function t(s,r=0){const o=e.get(s);let a;return o===void 0?(a=new rh(i),e.set(s,[a])):r>=o.length?(a=new rh(i),o.push(a)):a=o[r],a}function n(){e=new WeakMap}return{get:t,dispose:n}}const Nv=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Ov=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function Fv(i,e,t){let n=new bl;const s=new ue,r=new ue,o=new at,a=new Qf({depthPacking:pd}),l=new ep,c={},h=t.maxTextureSize,u={[jn]:jt,[jt]:jn,[wt]:wt},d=new nn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ue},radius:{value:4}},vertexShader:Nv,fragmentShader:Ov}),f=d.clone();f.defines.HORIZONTAL_PASS=1;const g=new it;g.setAttribute("position",new zt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const _=new Ne(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Ah;let p=this.type;this.render=function(M,A,T){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||M.length===0)return;const S=i.getRenderTarget(),b=i.getActiveCubeFace(),D=i.getActiveMipmapLevel(),I=i.state;I.setBlending(li),I.buffers.depth.getReversed()===!0?I.buffers.color.setClear(0,0,0,0):I.buffers.color.setClear(1,1,1,1),I.buffers.depth.setTest(!0),I.setScissorTest(!1);const U=p!==Hn&&this.type===Hn,B=p===Hn&&this.type!==Hn;for(let k=0,V=M.length;k<V;k++){const te=M[k],H=te.shadow;if(H===void 0){console.warn("THREE.WebGLShadowMap:",te,"has no shadow.");continue}if(H.autoUpdate===!1&&H.needsUpdate===!1)continue;s.copy(H.mapSize);const Q=H.getFrameExtents();if(s.multiply(Q),r.copy(H.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/Q.x),s.x=r.x*Q.x,H.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/Q.y),s.y=r.y*Q.y,H.mapSize.y=r.y)),H.map===null||U===!0||B===!0){const ge=this.type!==Hn?{minFilter:tn,magFilter:tn}:{};H.map!==null&&H.map.dispose(),H.map=new Ti(s.x,s.y,ge),H.map.texture.name=te.name+".shadowMap",H.camera.updateProjectionMatrix()}i.setRenderTarget(H.map),i.clear();const re=H.getViewportCount();for(let ge=0;ge<re;ge++){const xe=H.getViewport(ge);o.set(r.x*xe.x,r.y*xe.y,r.x*xe.z,r.y*xe.w),I.viewport(o),H.updateMatrices(te,ge),n=H.getFrustum(),v(A,T,H.camera,te,this.type)}H.isPointLightShadow!==!0&&this.type===Hn&&y(H,T),H.needsUpdate=!1}p=this.type,m.needsUpdate=!1,i.setRenderTarget(S,b,D)};function y(M,A){const T=e.update(_);d.defines.VSM_SAMPLES!==M.blurSamples&&(d.defines.VSM_SAMPLES=M.blurSamples,f.defines.VSM_SAMPLES=M.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),M.mapPass===null&&(M.mapPass=new Ti(s.x,s.y)),d.uniforms.shadow_pass.value=M.map.texture,d.uniforms.resolution.value=M.mapSize,d.uniforms.radius.value=M.radius,i.setRenderTarget(M.mapPass),i.clear(),i.renderBufferDirect(A,null,T,d,_,null),f.uniforms.shadow_pass.value=M.mapPass.texture,f.uniforms.resolution.value=M.mapSize,f.uniforms.radius.value=M.radius,i.setRenderTarget(M.map),i.clear(),i.renderBufferDirect(A,null,T,f,_,null)}function x(M,A,T,S){let b=null;const D=T.isPointLight===!0?M.customDistanceMaterial:M.customDepthMaterial;if(D!==void 0)b=D;else if(b=T.isPointLight===!0?l:a,i.localClippingEnabled&&A.clipShadows===!0&&Array.isArray(A.clippingPlanes)&&A.clippingPlanes.length!==0||A.displacementMap&&A.displacementScale!==0||A.alphaMap&&A.alphaTest>0||A.map&&A.alphaTest>0||A.alphaToCoverage===!0){const I=b.uuid,U=A.uuid;let B=c[I];B===void 0&&(B={},c[I]=B);let k=B[U];k===void 0&&(k=b.clone(),B[U]=k,A.addEventListener("dispose",w)),b=k}if(b.visible=A.visible,b.wireframe=A.wireframe,S===Hn?b.side=A.shadowSide!==null?A.shadowSide:A.side:b.side=A.shadowSide!==null?A.shadowSide:u[A.side],b.alphaMap=A.alphaMap,b.alphaTest=A.alphaToCoverage===!0?.5:A.alphaTest,b.map=A.map,b.clipShadows=A.clipShadows,b.clippingPlanes=A.clippingPlanes,b.clipIntersection=A.clipIntersection,b.displacementMap=A.displacementMap,b.displacementScale=A.displacementScale,b.displacementBias=A.displacementBias,b.wireframeLinewidth=A.wireframeLinewidth,b.linewidth=A.linewidth,T.isPointLight===!0&&b.isMeshDistanceMaterial===!0){const I=i.properties.get(b);I.light=T}return b}function v(M,A,T,S,b){if(M.visible===!1)return;if(M.layers.test(A.layers)&&(M.isMesh||M.isLine||M.isPoints)&&(M.castShadow||M.receiveShadow&&b===Hn)&&(!M.frustumCulled||n.intersectsObject(M))){M.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,M.matrixWorld);const U=e.update(M),B=M.material;if(Array.isArray(B)){const k=U.groups;for(let V=0,te=k.length;V<te;V++){const H=k[V],Q=B[H.materialIndex];if(Q&&Q.visible){const re=x(M,Q,S,b);M.onBeforeShadow(i,M,A,T,U,re,H),i.renderBufferDirect(T,null,U,re,M,H),M.onAfterShadow(i,M,A,T,U,re,H)}}}else if(B.visible){const k=x(M,B,S,b);M.onBeforeShadow(i,M,A,T,U,k,null),i.renderBufferDirect(T,null,U,k,M,null),M.onAfterShadow(i,M,A,T,U,k,null)}}const I=M.children;for(let U=0,B=I.length;U<B;U++)v(I[U],A,T,S,b)}function w(M){M.target.removeEventListener("dispose",w);for(const T in c){const S=c[T],b=M.target.uuid;b in S&&(S[b].dispose(),delete S[b])}}}const Bv={[la]:ca,[ha]:fa,[ua]:pa,[as]:da,[ca]:la,[fa]:ha,[pa]:ua,[da]:as};function zv(i,e){function t(){let N=!1;const ce=new at;let pe=null;const Ae=new at(0,0,0,0);return{setMask:function(ae){pe!==ae&&!N&&(i.colorMask(ae,ae,ae,ae),pe=ae)},setLocked:function(ae){N=ae},setClear:function(ae,ne,Le,$e,_t){_t===!0&&(ae*=$e,ne*=$e,Le*=$e),ce.set(ae,ne,Le,$e),Ae.equals(ce)===!1&&(i.clearColor(ae,ne,Le,$e),Ae.copy(ce))},reset:function(){N=!1,pe=null,Ae.set(-1,0,0,0)}}}function n(){let N=!1,ce=!1,pe=null,Ae=null,ae=null;return{setReversed:function(ne){if(ce!==ne){const Le=e.get("EXT_clip_control");ne?Le.clipControlEXT(Le.LOWER_LEFT_EXT,Le.ZERO_TO_ONE_EXT):Le.clipControlEXT(Le.LOWER_LEFT_EXT,Le.NEGATIVE_ONE_TO_ONE_EXT),ce=ne;const $e=ae;ae=null,this.setClear($e)}},getReversed:function(){return ce},setTest:function(ne){ne?ee(i.DEPTH_TEST):Se(i.DEPTH_TEST)},setMask:function(ne){pe!==ne&&!N&&(i.depthMask(ne),pe=ne)},setFunc:function(ne){if(ce&&(ne=Bv[ne]),Ae!==ne){switch(ne){case la:i.depthFunc(i.NEVER);break;case ca:i.depthFunc(i.ALWAYS);break;case ha:i.depthFunc(i.LESS);break;case as:i.depthFunc(i.LEQUAL);break;case ua:i.depthFunc(i.EQUAL);break;case da:i.depthFunc(i.GEQUAL);break;case fa:i.depthFunc(i.GREATER);break;case pa:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}Ae=ne}},setLocked:function(ne){N=ne},setClear:function(ne){ae!==ne&&(ce&&(ne=1-ne),i.clearDepth(ne),ae=ne)},reset:function(){N=!1,pe=null,Ae=null,ae=null,ce=!1}}}function s(){let N=!1,ce=null,pe=null,Ae=null,ae=null,ne=null,Le=null,$e=null,_t=null;return{setTest:function(dt){N||(dt?ee(i.STENCIL_TEST):Se(i.STENCIL_TEST))},setMask:function(dt){ce!==dt&&!N&&(i.stencilMask(dt),ce=dt)},setFunc:function(dt,Nn,An){(pe!==dt||Ae!==Nn||ae!==An)&&(i.stencilFunc(dt,Nn,An),pe=dt,Ae=Nn,ae=An)},setOp:function(dt,Nn,An){(ne!==dt||Le!==Nn||$e!==An)&&(i.stencilOp(dt,Nn,An),ne=dt,Le=Nn,$e=An)},setLocked:function(dt){N=dt},setClear:function(dt){_t!==dt&&(i.clearStencil(dt),_t=dt)},reset:function(){N=!1,ce=null,pe=null,Ae=null,ae=null,ne=null,Le=null,$e=null,_t=null}}}const r=new t,o=new n,a=new s,l=new WeakMap,c=new WeakMap;let h={},u={},d=new WeakMap,f=[],g=null,_=!1,m=null,p=null,y=null,x=null,v=null,w=null,M=null,A=new Oe(0,0,0),T=0,S=!1,b=null,D=null,I=null,U=null,B=null;const k=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let V=!1,te=0;const H=i.getParameter(i.VERSION);H.indexOf("WebGL")!==-1?(te=parseFloat(/^WebGL (\d)/.exec(H)[1]),V=te>=1):H.indexOf("OpenGL ES")!==-1&&(te=parseFloat(/^OpenGL ES (\d)/.exec(H)[1]),V=te>=2);let Q=null,re={};const ge=i.getParameter(i.SCISSOR_BOX),xe=i.getParameter(i.VIEWPORT),Qe=new at().fromArray(ge),ot=new at().fromArray(xe);function qe(N,ce,pe,Ae){const ae=new Uint8Array(4),ne=i.createTexture();i.bindTexture(N,ne),i.texParameteri(N,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(N,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Le=0;Le<pe;Le++)N===i.TEXTURE_3D||N===i.TEXTURE_2D_ARRAY?i.texImage3D(ce,0,i.RGBA,1,1,Ae,0,i.RGBA,i.UNSIGNED_BYTE,ae):i.texImage2D(ce+Le,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,ae);return ne}const J={};J[i.TEXTURE_2D]=qe(i.TEXTURE_2D,i.TEXTURE_2D,1),J[i.TEXTURE_CUBE_MAP]=qe(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),J[i.TEXTURE_2D_ARRAY]=qe(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),J[i.TEXTURE_3D]=qe(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),ee(i.DEPTH_TEST),o.setFunc(as),Y(!1),K($l),ee(i.CULL_FACE),Z(li);function ee(N){h[N]!==!0&&(i.enable(N),h[N]=!0)}function Se(N){h[N]!==!1&&(i.disable(N),h[N]=!1)}function Te(N,ce){return u[N]!==ce?(i.bindFramebuffer(N,ce),u[N]=ce,N===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=ce),N===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=ce),!0):!1}function Ee(N,ce){let pe=f,Ae=!1;if(N){pe=d.get(ce),pe===void 0&&(pe=[],d.set(ce,pe));const ae=N.textures;if(pe.length!==ae.length||pe[0]!==i.COLOR_ATTACHMENT0){for(let ne=0,Le=ae.length;ne<Le;ne++)pe[ne]=i.COLOR_ATTACHMENT0+ne;pe.length=ae.length,Ae=!0}}else pe[0]!==i.BACK&&(pe[0]=i.BACK,Ae=!0);Ae&&i.drawBuffers(pe)}function et(N){return g!==N?(i.useProgram(N),g=N,!0):!1}const Ie={[Mi]:i.FUNC_ADD,[Vu]:i.FUNC_SUBTRACT,[Hu]:i.FUNC_REVERSE_SUBTRACT};Ie[Gu]=i.MIN,Ie[Wu]=i.MAX;const L={[Xu]:i.ZERO,[$u]:i.ONE,[qu]:i.SRC_COLOR,[oa]:i.SRC_ALPHA,[Qu]:i.SRC_ALPHA_SATURATE,[Zu]:i.DST_COLOR,[ju]:i.DST_ALPHA,[Yu]:i.ONE_MINUS_SRC_COLOR,[aa]:i.ONE_MINUS_SRC_ALPHA,[Ju]:i.ONE_MINUS_DST_COLOR,[Ku]:i.ONE_MINUS_DST_ALPHA,[ed]:i.CONSTANT_COLOR,[td]:i.ONE_MINUS_CONSTANT_COLOR,[nd]:i.CONSTANT_ALPHA,[id]:i.ONE_MINUS_CONSTANT_ALPHA};function Z(N,ce,pe,Ae,ae,ne,Le,$e,_t,dt){if(N===li){_===!0&&(Se(i.BLEND),_=!1);return}if(_===!1&&(ee(i.BLEND),_=!0),N!==ku){if(N!==m||dt!==S){if((p!==Mi||v!==Mi)&&(i.blendEquation(i.FUNC_ADD),p=Mi,v=Mi),dt)switch(N){case es:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case ql:i.blendFunc(i.ONE,i.ONE);break;case Yl:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case jl:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}else switch(N){case es:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case ql:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case Yl:console.error("THREE.WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case jl:console.error("THREE.WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}y=null,x=null,w=null,M=null,A.set(0,0,0),T=0,m=N,S=dt}return}ae=ae||ce,ne=ne||pe,Le=Le||Ae,(ce!==p||ae!==v)&&(i.blendEquationSeparate(Ie[ce],Ie[ae]),p=ce,v=ae),(pe!==y||Ae!==x||ne!==w||Le!==M)&&(i.blendFuncSeparate(L[pe],L[Ae],L[ne],L[Le]),y=pe,x=Ae,w=ne,M=Le),($e.equals(A)===!1||_t!==T)&&(i.blendColor($e.r,$e.g,$e.b,_t),A.copy($e),T=_t),m=N,S=!1}function j(N,ce){N.side===wt?Se(i.CULL_FACE):ee(i.CULL_FACE);let pe=N.side===jt;ce&&(pe=!pe),Y(pe),N.blending===es&&N.transparent===!1?Z(li):Z(N.blending,N.blendEquation,N.blendSrc,N.blendDst,N.blendEquationAlpha,N.blendSrcAlpha,N.blendDstAlpha,N.blendColor,N.blendAlpha,N.premultipliedAlpha),o.setFunc(N.depthFunc),o.setTest(N.depthTest),o.setMask(N.depthWrite),r.setMask(N.colorWrite);const Ae=N.stencilWrite;a.setTest(Ae),Ae&&(a.setMask(N.stencilWriteMask),a.setFunc(N.stencilFunc,N.stencilRef,N.stencilFuncMask),a.setOp(N.stencilFail,N.stencilZFail,N.stencilZPass)),se(N.polygonOffset,N.polygonOffsetFactor,N.polygonOffsetUnits),N.alphaToCoverage===!0?ee(i.SAMPLE_ALPHA_TO_COVERAGE):Se(i.SAMPLE_ALPHA_TO_COVERAGE)}function Y(N){b!==N&&(N?i.frontFace(i.CW):i.frontFace(i.CCW),b=N)}function K(N){N!==Bu?(ee(i.CULL_FACE),N!==D&&(N===$l?i.cullFace(i.BACK):N===zu?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Se(i.CULL_FACE),D=N}function he(N){N!==I&&(V&&i.lineWidth(N),I=N)}function se(N,ce,pe){N?(ee(i.POLYGON_OFFSET_FILL),(U!==ce||B!==pe)&&(i.polygonOffset(ce,pe),U=ce,B=pe)):Se(i.POLYGON_OFFSET_FILL)}function fe(N){N?ee(i.SCISSOR_TEST):Se(i.SCISSOR_TEST)}function Xe(N){N===void 0&&(N=i.TEXTURE0+k-1),Q!==N&&(i.activeTexture(N),Q=N)}function Ge(N,ce,pe){pe===void 0&&(Q===null?pe=i.TEXTURE0+k-1:pe=Q);let Ae=re[pe];Ae===void 0&&(Ae={type:void 0,texture:void 0},re[pe]=Ae),(Ae.type!==N||Ae.texture!==ce)&&(Q!==pe&&(i.activeTexture(pe),Q=pe),i.bindTexture(N,ce||J[N]),Ae.type=N,Ae.texture=ce)}function R(){const N=re[Q];N!==void 0&&N.type!==void 0&&(i.bindTexture(N.type,null),N.type=void 0,N.texture=void 0)}function E(){try{i.compressedTexImage2D(...arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function z(){try{i.compressedTexImage3D(...arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function X(){try{i.texSubImage2D(...arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function ie(){try{i.texSubImage3D(...arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function $(){try{i.compressedTexSubImage2D(...arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function De(){try{i.compressedTexSubImage3D(...arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function de(){try{i.texStorage2D(...arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Re(){try{i.texStorage3D(...arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Pe(){try{i.texImage2D(...arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function oe(){try{i.texImage3D(...arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function ye(N){Qe.equals(N)===!1&&(i.scissor(N.x,N.y,N.z,N.w),Qe.copy(N))}function Ve(N){ot.equals(N)===!1&&(i.viewport(N.x,N.y,N.z,N.w),ot.copy(N))}function Ue(N,ce){let pe=c.get(ce);pe===void 0&&(pe=new WeakMap,c.set(ce,pe));let Ae=pe.get(N);Ae===void 0&&(Ae=i.getUniformBlockIndex(ce,N.name),pe.set(N,Ae))}function ve(N,ce){const Ae=c.get(ce).get(N);l.get(ce)!==Ae&&(i.uniformBlockBinding(ce,Ae,N.__bindingPointIndex),l.set(ce,Ae))}function Ye(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),o.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),h={},Q=null,re={},u={},d=new WeakMap,f=[],g=null,_=!1,m=null,p=null,y=null,x=null,v=null,w=null,M=null,A=new Oe(0,0,0),T=0,S=!1,b=null,D=null,I=null,U=null,B=null,Qe.set(0,0,i.canvas.width,i.canvas.height),ot.set(0,0,i.canvas.width,i.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:ee,disable:Se,bindFramebuffer:Te,drawBuffers:Ee,useProgram:et,setBlending:Z,setMaterial:j,setFlipSided:Y,setCullFace:K,setLineWidth:he,setPolygonOffset:se,setScissorTest:fe,activeTexture:Xe,bindTexture:Ge,unbindTexture:R,compressedTexImage2D:E,compressedTexImage3D:z,texImage2D:Pe,texImage3D:oe,updateUBOMapping:Ue,uniformBlockBinding:ve,texStorage2D:de,texStorage3D:Re,texSubImage2D:X,texSubImage3D:ie,compressedTexSubImage2D:$,compressedTexSubImage3D:De,scissor:ye,viewport:Ve,reset:Ye}}function kv(i,e,t,n,s,r,o){const a=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new ue,h=new WeakMap;let u;const d=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(R,E){return f?new OffscreenCanvas(R,E):Xs("canvas")}function _(R,E,z){let X=1;const ie=Ge(R);if((ie.width>z||ie.height>z)&&(X=z/Math.max(ie.width,ie.height)),X<1)if(typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&R instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&R instanceof ImageBitmap||typeof VideoFrame<"u"&&R instanceof VideoFrame){const $=Math.floor(X*ie.width),De=Math.floor(X*ie.height);u===void 0&&(u=g($,De));const de=E?g($,De):u;return de.width=$,de.height=De,de.getContext("2d").drawImage(R,0,0,$,De),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+ie.width+"x"+ie.height+") to ("+$+"x"+De+")."),de}else return"data"in R&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+ie.width+"x"+ie.height+")."),R;return R}function m(R){return R.generateMipmaps}function p(R){i.generateMipmap(R)}function y(R){return R.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:R.isWebGL3DRenderTarget?i.TEXTURE_3D:R.isWebGLArrayRenderTarget||R.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function x(R,E,z,X,ie=!1){if(R!==null){if(i[R]!==void 0)return i[R];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+R+"'")}let $=E;if(E===i.RED&&(z===i.FLOAT&&($=i.R32F),z===i.HALF_FLOAT&&($=i.R16F),z===i.UNSIGNED_BYTE&&($=i.R8)),E===i.RED_INTEGER&&(z===i.UNSIGNED_BYTE&&($=i.R8UI),z===i.UNSIGNED_SHORT&&($=i.R16UI),z===i.UNSIGNED_INT&&($=i.R32UI),z===i.BYTE&&($=i.R8I),z===i.SHORT&&($=i.R16I),z===i.INT&&($=i.R32I)),E===i.RG&&(z===i.FLOAT&&($=i.RG32F),z===i.HALF_FLOAT&&($=i.RG16F),z===i.UNSIGNED_BYTE&&($=i.RG8)),E===i.RG_INTEGER&&(z===i.UNSIGNED_BYTE&&($=i.RG8UI),z===i.UNSIGNED_SHORT&&($=i.RG16UI),z===i.UNSIGNED_INT&&($=i.RG32UI),z===i.BYTE&&($=i.RG8I),z===i.SHORT&&($=i.RG16I),z===i.INT&&($=i.RG32I)),E===i.RGB_INTEGER&&(z===i.UNSIGNED_BYTE&&($=i.RGB8UI),z===i.UNSIGNED_SHORT&&($=i.RGB16UI),z===i.UNSIGNED_INT&&($=i.RGB32UI),z===i.BYTE&&($=i.RGB8I),z===i.SHORT&&($=i.RGB16I),z===i.INT&&($=i.RGB32I)),E===i.RGBA_INTEGER&&(z===i.UNSIGNED_BYTE&&($=i.RGBA8UI),z===i.UNSIGNED_SHORT&&($=i.RGBA16UI),z===i.UNSIGNED_INT&&($=i.RGBA32UI),z===i.BYTE&&($=i.RGBA8I),z===i.SHORT&&($=i.RGBA16I),z===i.INT&&($=i.RGBA32I)),E===i.RGB&&(z===i.UNSIGNED_INT_5_9_9_9_REV&&($=i.RGB9_E5),z===i.UNSIGNED_INT_10F_11F_11F_REV&&($=i.R11F_G11F_B10F)),E===i.RGBA){const De=ie?jr:ht.getTransfer(X);z===i.FLOAT&&($=i.RGBA32F),z===i.HALF_FLOAT&&($=i.RGBA16F),z===i.UNSIGNED_BYTE&&($=De===gt?i.SRGB8_ALPHA8:i.RGBA8),z===i.UNSIGNED_SHORT_4_4_4_4&&($=i.RGBA4),z===i.UNSIGNED_SHORT_5_5_5_1&&($=i.RGB5_A1)}return($===i.R16F||$===i.R32F||$===i.RG16F||$===i.RG32F||$===i.RGBA16F||$===i.RGBA32F)&&e.get("EXT_color_buffer_float"),$}function v(R,E){let z;return R?E===null||E===Ai||E===Vs?z=i.DEPTH24_STENCIL8:E===Pn?z=i.DEPTH32F_STENCIL8:E===ks&&(z=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):E===null||E===Ai||E===Vs?z=i.DEPTH_COMPONENT24:E===Pn?z=i.DEPTH_COMPONENT32F:E===ks&&(z=i.DEPTH_COMPONENT16),z}function w(R,E){return m(R)===!0||R.isFramebufferTexture&&R.minFilter!==tn&&R.minFilter!==Sn?Math.log2(Math.max(E.width,E.height))+1:R.mipmaps!==void 0&&R.mipmaps.length>0?R.mipmaps.length:R.isCompressedTexture&&Array.isArray(R.image)?E.mipmaps.length:1}function M(R){const E=R.target;E.removeEventListener("dispose",M),T(E),E.isVideoTexture&&h.delete(E)}function A(R){const E=R.target;E.removeEventListener("dispose",A),b(E)}function T(R){const E=n.get(R);if(E.__webglInit===void 0)return;const z=R.source,X=d.get(z);if(X){const ie=X[E.__cacheKey];ie.usedTimes--,ie.usedTimes===0&&S(R),Object.keys(X).length===0&&d.delete(z)}n.remove(R)}function S(R){const E=n.get(R);i.deleteTexture(E.__webglTexture);const z=R.source,X=d.get(z);delete X[E.__cacheKey],o.memory.textures--}function b(R){const E=n.get(R);if(R.depthTexture&&(R.depthTexture.dispose(),n.remove(R.depthTexture)),R.isWebGLCubeRenderTarget)for(let X=0;X<6;X++){if(Array.isArray(E.__webglFramebuffer[X]))for(let ie=0;ie<E.__webglFramebuffer[X].length;ie++)i.deleteFramebuffer(E.__webglFramebuffer[X][ie]);else i.deleteFramebuffer(E.__webglFramebuffer[X]);E.__webglDepthbuffer&&i.deleteRenderbuffer(E.__webglDepthbuffer[X])}else{if(Array.isArray(E.__webglFramebuffer))for(let X=0;X<E.__webglFramebuffer.length;X++)i.deleteFramebuffer(E.__webglFramebuffer[X]);else i.deleteFramebuffer(E.__webglFramebuffer);if(E.__webglDepthbuffer&&i.deleteRenderbuffer(E.__webglDepthbuffer),E.__webglMultisampledFramebuffer&&i.deleteFramebuffer(E.__webglMultisampledFramebuffer),E.__webglColorRenderbuffer)for(let X=0;X<E.__webglColorRenderbuffer.length;X++)E.__webglColorRenderbuffer[X]&&i.deleteRenderbuffer(E.__webglColorRenderbuffer[X]);E.__webglDepthRenderbuffer&&i.deleteRenderbuffer(E.__webglDepthRenderbuffer)}const z=R.textures;for(let X=0,ie=z.length;X<ie;X++){const $=n.get(z[X]);$.__webglTexture&&(i.deleteTexture($.__webglTexture),o.memory.textures--),n.remove(z[X])}n.remove(R)}let D=0;function I(){D=0}function U(){const R=D;return R>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+R+" texture units while this GPU supports only "+s.maxTextures),D+=1,R}function B(R){const E=[];return E.push(R.wrapS),E.push(R.wrapT),E.push(R.wrapR||0),E.push(R.magFilter),E.push(R.minFilter),E.push(R.anisotropy),E.push(R.internalFormat),E.push(R.format),E.push(R.type),E.push(R.generateMipmaps),E.push(R.premultiplyAlpha),E.push(R.flipY),E.push(R.unpackAlignment),E.push(R.colorSpace),E.join()}function k(R,E){const z=n.get(R);if(R.isVideoTexture&&fe(R),R.isRenderTargetTexture===!1&&R.isExternalTexture!==!0&&R.version>0&&z.__version!==R.version){const X=R.image;if(X===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(X.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{J(z,R,E);return}}else R.isExternalTexture&&(z.__webglTexture=R.sourceTexture?R.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,z.__webglTexture,i.TEXTURE0+E)}function V(R,E){const z=n.get(R);if(R.isRenderTargetTexture===!1&&R.version>0&&z.__version!==R.version){J(z,R,E);return}t.bindTexture(i.TEXTURE_2D_ARRAY,z.__webglTexture,i.TEXTURE0+E)}function te(R,E){const z=n.get(R);if(R.isRenderTargetTexture===!1&&R.version>0&&z.__version!==R.version){J(z,R,E);return}t.bindTexture(i.TEXTURE_3D,z.__webglTexture,i.TEXTURE0+E)}function H(R,E){const z=n.get(R);if(R.version>0&&z.__version!==R.version){ee(z,R,E);return}t.bindTexture(i.TEXTURE_CUBE_MAP,z.__webglTexture,i.TEXTURE0+E)}const Q={[zs]:i.REPEAT,[bi]:i.CLAMP_TO_EDGE,[va]:i.MIRRORED_REPEAT},re={[tn]:i.NEAREST,[dd]:i.NEAREST_MIPMAP_NEAREST,[ar]:i.NEAREST_MIPMAP_LINEAR,[Sn]:i.LINEAR,[fo]:i.LINEAR_MIPMAP_NEAREST,[oi]:i.LINEAR_MIPMAP_LINEAR},ge={[gd]:i.NEVER,[Sd]:i.ALWAYS,[vd]:i.LESS,[Fh]:i.LEQUAL,[_d]:i.EQUAL,[Md]:i.GEQUAL,[xd]:i.GREATER,[yd]:i.NOTEQUAL};function xe(R,E){if(E.type===Pn&&e.has("OES_texture_float_linear")===!1&&(E.magFilter===Sn||E.magFilter===fo||E.magFilter===ar||E.magFilter===oi||E.minFilter===Sn||E.minFilter===fo||E.minFilter===ar||E.minFilter===oi)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(R,i.TEXTURE_WRAP_S,Q[E.wrapS]),i.texParameteri(R,i.TEXTURE_WRAP_T,Q[E.wrapT]),(R===i.TEXTURE_3D||R===i.TEXTURE_2D_ARRAY)&&i.texParameteri(R,i.TEXTURE_WRAP_R,Q[E.wrapR]),i.texParameteri(R,i.TEXTURE_MAG_FILTER,re[E.magFilter]),i.texParameteri(R,i.TEXTURE_MIN_FILTER,re[E.minFilter]),E.compareFunction&&(i.texParameteri(R,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(R,i.TEXTURE_COMPARE_FUNC,ge[E.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(E.magFilter===tn||E.minFilter!==ar&&E.minFilter!==oi||E.type===Pn&&e.has("OES_texture_float_linear")===!1)return;if(E.anisotropy>1||n.get(E).__currentAnisotropy){const z=e.get("EXT_texture_filter_anisotropic");i.texParameterf(R,z.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(E.anisotropy,s.getMaxAnisotropy())),n.get(E).__currentAnisotropy=E.anisotropy}}}function Qe(R,E){let z=!1;R.__webglInit===void 0&&(R.__webglInit=!0,E.addEventListener("dispose",M));const X=E.source;let ie=d.get(X);ie===void 0&&(ie={},d.set(X,ie));const $=B(E);if($!==R.__cacheKey){ie[$]===void 0&&(ie[$]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,z=!0),ie[$].usedTimes++;const De=ie[R.__cacheKey];De!==void 0&&(ie[R.__cacheKey].usedTimes--,De.usedTimes===0&&S(E)),R.__cacheKey=$,R.__webglTexture=ie[$].texture}return z}function ot(R,E,z){return Math.floor(Math.floor(R/z)/E)}function qe(R,E,z,X){const $=R.updateRanges;if($.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,E.width,E.height,z,X,E.data);else{$.sort((oe,ye)=>oe.start-ye.start);let De=0;for(let oe=1;oe<$.length;oe++){const ye=$[De],Ve=$[oe],Ue=ye.start+ye.count,ve=ot(Ve.start,E.width,4),Ye=ot(ye.start,E.width,4);Ve.start<=Ue+1&&ve===Ye&&ot(Ve.start+Ve.count-1,E.width,4)===ve?ye.count=Math.max(ye.count,Ve.start+Ve.count-ye.start):(++De,$[De]=Ve)}$.length=De+1;const de=i.getParameter(i.UNPACK_ROW_LENGTH),Re=i.getParameter(i.UNPACK_SKIP_PIXELS),Pe=i.getParameter(i.UNPACK_SKIP_ROWS);i.pixelStorei(i.UNPACK_ROW_LENGTH,E.width);for(let oe=0,ye=$.length;oe<ye;oe++){const Ve=$[oe],Ue=Math.floor(Ve.start/4),ve=Math.ceil(Ve.count/4),Ye=Ue%E.width,N=Math.floor(Ue/E.width),ce=ve,pe=1;i.pixelStorei(i.UNPACK_SKIP_PIXELS,Ye),i.pixelStorei(i.UNPACK_SKIP_ROWS,N),t.texSubImage2D(i.TEXTURE_2D,0,Ye,N,ce,pe,z,X,E.data)}R.clearUpdateRanges(),i.pixelStorei(i.UNPACK_ROW_LENGTH,de),i.pixelStorei(i.UNPACK_SKIP_PIXELS,Re),i.pixelStorei(i.UNPACK_SKIP_ROWS,Pe)}}function J(R,E,z){let X=i.TEXTURE_2D;(E.isDataArrayTexture||E.isCompressedArrayTexture)&&(X=i.TEXTURE_2D_ARRAY),E.isData3DTexture&&(X=i.TEXTURE_3D);const ie=Qe(R,E),$=E.source;t.bindTexture(X,R.__webglTexture,i.TEXTURE0+z);const De=n.get($);if($.version!==De.__version||ie===!0){t.activeTexture(i.TEXTURE0+z);const de=ht.getPrimaries(ht.workingColorSpace),Re=E.colorSpace===Gn?null:ht.getPrimaries(E.colorSpace),Pe=E.colorSpace===Gn||de===Re?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Pe);let oe=_(E.image,!1,s.maxTextureSize);oe=Xe(E,oe);const ye=r.convert(E.format,E.colorSpace),Ve=r.convert(E.type);let Ue=x(E.internalFormat,ye,Ve,E.colorSpace,E.isVideoTexture);xe(X,E);let ve;const Ye=E.mipmaps,N=E.isVideoTexture!==!0,ce=De.__version===void 0||ie===!0,pe=$.dataReady,Ae=w(E,oe);if(E.isDepthTexture)Ue=v(E.format===Gs,E.type),ce&&(N?t.texStorage2D(i.TEXTURE_2D,1,Ue,oe.width,oe.height):t.texImage2D(i.TEXTURE_2D,0,Ue,oe.width,oe.height,0,ye,Ve,null));else if(E.isDataTexture)if(Ye.length>0){N&&ce&&t.texStorage2D(i.TEXTURE_2D,Ae,Ue,Ye[0].width,Ye[0].height);for(let ae=0,ne=Ye.length;ae<ne;ae++)ve=Ye[ae],N?pe&&t.texSubImage2D(i.TEXTURE_2D,ae,0,0,ve.width,ve.height,ye,Ve,ve.data):t.texImage2D(i.TEXTURE_2D,ae,Ue,ve.width,ve.height,0,ye,Ve,ve.data);E.generateMipmaps=!1}else N?(ce&&t.texStorage2D(i.TEXTURE_2D,Ae,Ue,oe.width,oe.height),pe&&qe(E,oe,ye,Ve)):t.texImage2D(i.TEXTURE_2D,0,Ue,oe.width,oe.height,0,ye,Ve,oe.data);else if(E.isCompressedTexture)if(E.isCompressedArrayTexture){N&&ce&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Ae,Ue,Ye[0].width,Ye[0].height,oe.depth);for(let ae=0,ne=Ye.length;ae<ne;ae++)if(ve=Ye[ae],E.format!==bn)if(ye!==null)if(N){if(pe)if(E.layerUpdates.size>0){const Le=Nc(ve.width,ve.height,E.format,E.type);for(const $e of E.layerUpdates){const _t=ve.data.subarray($e*Le/ve.data.BYTES_PER_ELEMENT,($e+1)*Le/ve.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ae,0,0,$e,ve.width,ve.height,1,ye,_t)}E.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ae,0,0,0,ve.width,ve.height,oe.depth,ye,ve.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ae,Ue,ve.width,ve.height,oe.depth,0,ve.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else N?pe&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,ae,0,0,0,ve.width,ve.height,oe.depth,ye,Ve,ve.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ae,Ue,ve.width,ve.height,oe.depth,0,ye,Ve,ve.data)}else{N&&ce&&t.texStorage2D(i.TEXTURE_2D,Ae,Ue,Ye[0].width,Ye[0].height);for(let ae=0,ne=Ye.length;ae<ne;ae++)ve=Ye[ae],E.format!==bn?ye!==null?N?pe&&t.compressedTexSubImage2D(i.TEXTURE_2D,ae,0,0,ve.width,ve.height,ye,ve.data):t.compressedTexImage2D(i.TEXTURE_2D,ae,Ue,ve.width,ve.height,0,ve.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):N?pe&&t.texSubImage2D(i.TEXTURE_2D,ae,0,0,ve.width,ve.height,ye,Ve,ve.data):t.texImage2D(i.TEXTURE_2D,ae,Ue,ve.width,ve.height,0,ye,Ve,ve.data)}else if(E.isDataArrayTexture)if(N){if(ce&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Ae,Ue,oe.width,oe.height,oe.depth),pe)if(E.layerUpdates.size>0){const ae=Nc(oe.width,oe.height,E.format,E.type);for(const ne of E.layerUpdates){const Le=oe.data.subarray(ne*ae/oe.data.BYTES_PER_ELEMENT,(ne+1)*ae/oe.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,ne,oe.width,oe.height,1,ye,Ve,Le)}E.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,oe.width,oe.height,oe.depth,ye,Ve,oe.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Ue,oe.width,oe.height,oe.depth,0,ye,Ve,oe.data);else if(E.isData3DTexture)N?(ce&&t.texStorage3D(i.TEXTURE_3D,Ae,Ue,oe.width,oe.height,oe.depth),pe&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,oe.width,oe.height,oe.depth,ye,Ve,oe.data)):t.texImage3D(i.TEXTURE_3D,0,Ue,oe.width,oe.height,oe.depth,0,ye,Ve,oe.data);else if(E.isFramebufferTexture){if(ce)if(N)t.texStorage2D(i.TEXTURE_2D,Ae,Ue,oe.width,oe.height);else{let ae=oe.width,ne=oe.height;for(let Le=0;Le<Ae;Le++)t.texImage2D(i.TEXTURE_2D,Le,Ue,ae,ne,0,ye,Ve,null),ae>>=1,ne>>=1}}else if(Ye.length>0){if(N&&ce){const ae=Ge(Ye[0]);t.texStorage2D(i.TEXTURE_2D,Ae,Ue,ae.width,ae.height)}for(let ae=0,ne=Ye.length;ae<ne;ae++)ve=Ye[ae],N?pe&&t.texSubImage2D(i.TEXTURE_2D,ae,0,0,ye,Ve,ve):t.texImage2D(i.TEXTURE_2D,ae,Ue,ye,Ve,ve);E.generateMipmaps=!1}else if(N){if(ce){const ae=Ge(oe);t.texStorage2D(i.TEXTURE_2D,Ae,Ue,ae.width,ae.height)}pe&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,ye,Ve,oe)}else t.texImage2D(i.TEXTURE_2D,0,Ue,ye,Ve,oe);m(E)&&p(X),De.__version=$.version,E.onUpdate&&E.onUpdate(E)}R.__version=E.version}function ee(R,E,z){if(E.image.length!==6)return;const X=Qe(R,E),ie=E.source;t.bindTexture(i.TEXTURE_CUBE_MAP,R.__webglTexture,i.TEXTURE0+z);const $=n.get(ie);if(ie.version!==$.__version||X===!0){t.activeTexture(i.TEXTURE0+z);const De=ht.getPrimaries(ht.workingColorSpace),de=E.colorSpace===Gn?null:ht.getPrimaries(E.colorSpace),Re=E.colorSpace===Gn||De===de?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Re);const Pe=E.isCompressedTexture||E.image[0].isCompressedTexture,oe=E.image[0]&&E.image[0].isDataTexture,ye=[];for(let ne=0;ne<6;ne++)!Pe&&!oe?ye[ne]=_(E.image[ne],!0,s.maxCubemapSize):ye[ne]=oe?E.image[ne].image:E.image[ne],ye[ne]=Xe(E,ye[ne]);const Ve=ye[0],Ue=r.convert(E.format,E.colorSpace),ve=r.convert(E.type),Ye=x(E.internalFormat,Ue,ve,E.colorSpace),N=E.isVideoTexture!==!0,ce=$.__version===void 0||X===!0,pe=ie.dataReady;let Ae=w(E,Ve);xe(i.TEXTURE_CUBE_MAP,E);let ae;if(Pe){N&&ce&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Ae,Ye,Ve.width,Ve.height);for(let ne=0;ne<6;ne++){ae=ye[ne].mipmaps;for(let Le=0;Le<ae.length;Le++){const $e=ae[Le];E.format!==bn?Ue!==null?N?pe&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Le,0,0,$e.width,$e.height,Ue,$e.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Le,Ye,$e.width,$e.height,0,$e.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):N?pe&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Le,0,0,$e.width,$e.height,Ue,ve,$e.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Le,Ye,$e.width,$e.height,0,Ue,ve,$e.data)}}}else{if(ae=E.mipmaps,N&&ce){ae.length>0&&Ae++;const ne=Ge(ye[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,Ae,Ye,ne.width,ne.height)}for(let ne=0;ne<6;ne++)if(oe){N?pe&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,0,0,ye[ne].width,ye[ne].height,Ue,ve,ye[ne].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,Ye,ye[ne].width,ye[ne].height,0,Ue,ve,ye[ne].data);for(let Le=0;Le<ae.length;Le++){const _t=ae[Le].image[ne].image;N?pe&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Le+1,0,0,_t.width,_t.height,Ue,ve,_t.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Le+1,Ye,_t.width,_t.height,0,Ue,ve,_t.data)}}else{N?pe&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,0,0,Ue,ve,ye[ne]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,Ye,Ue,ve,ye[ne]);for(let Le=0;Le<ae.length;Le++){const $e=ae[Le];N?pe&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Le+1,0,0,Ue,ve,$e.image[ne]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Le+1,Ye,Ue,ve,$e.image[ne])}}}m(E)&&p(i.TEXTURE_CUBE_MAP),$.__version=ie.version,E.onUpdate&&E.onUpdate(E)}R.__version=E.version}function Se(R,E,z,X,ie,$){const De=r.convert(z.format,z.colorSpace),de=r.convert(z.type),Re=x(z.internalFormat,De,de,z.colorSpace),Pe=n.get(E),oe=n.get(z);if(oe.__renderTarget=E,!Pe.__hasExternalTextures){const ye=Math.max(1,E.width>>$),Ve=Math.max(1,E.height>>$);ie===i.TEXTURE_3D||ie===i.TEXTURE_2D_ARRAY?t.texImage3D(ie,$,Re,ye,Ve,E.depth,0,De,de,null):t.texImage2D(ie,$,Re,ye,Ve,0,De,de,null)}t.bindFramebuffer(i.FRAMEBUFFER,R),se(E)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,X,ie,oe.__webglTexture,0,he(E)):(ie===i.TEXTURE_2D||ie>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&ie<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,X,ie,oe.__webglTexture,$),t.bindFramebuffer(i.FRAMEBUFFER,null)}function Te(R,E,z){if(i.bindRenderbuffer(i.RENDERBUFFER,R),E.depthBuffer){const X=E.depthTexture,ie=X&&X.isDepthTexture?X.type:null,$=v(E.stencilBuffer,ie),De=E.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,de=he(E);se(E)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,de,$,E.width,E.height):z?i.renderbufferStorageMultisample(i.RENDERBUFFER,de,$,E.width,E.height):i.renderbufferStorage(i.RENDERBUFFER,$,E.width,E.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,De,i.RENDERBUFFER,R)}else{const X=E.textures;for(let ie=0;ie<X.length;ie++){const $=X[ie],De=r.convert($.format,$.colorSpace),de=r.convert($.type),Re=x($.internalFormat,De,de,$.colorSpace),Pe=he(E);z&&se(E)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Pe,Re,E.width,E.height):se(E)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Pe,Re,E.width,E.height):i.renderbufferStorage(i.RENDERBUFFER,Re,E.width,E.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Ee(R,E){if(E&&E.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,R),!(E.depthTexture&&E.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const X=n.get(E.depthTexture);X.__renderTarget=E,(!X.__webglTexture||E.depthTexture.image.width!==E.width||E.depthTexture.image.height!==E.height)&&(E.depthTexture.image.width=E.width,E.depthTexture.image.height=E.height,E.depthTexture.needsUpdate=!0),k(E.depthTexture,0);const ie=X.__webglTexture,$=he(E);if(E.depthTexture.format===Hs)se(E)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,ie,0,$):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,ie,0);else if(E.depthTexture.format===Gs)se(E)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,ie,0,$):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,ie,0);else throw new Error("Unknown depthTexture format")}function et(R){const E=n.get(R),z=R.isWebGLCubeRenderTarget===!0;if(E.__boundDepthTexture!==R.depthTexture){const X=R.depthTexture;if(E.__depthDisposeCallback&&E.__depthDisposeCallback(),X){const ie=()=>{delete E.__boundDepthTexture,delete E.__depthDisposeCallback,X.removeEventListener("dispose",ie)};X.addEventListener("dispose",ie),E.__depthDisposeCallback=ie}E.__boundDepthTexture=X}if(R.depthTexture&&!E.__autoAllocateDepthBuffer){if(z)throw new Error("target.depthTexture not supported in Cube render targets");const X=R.texture.mipmaps;X&&X.length>0?Ee(E.__webglFramebuffer[0],R):Ee(E.__webglFramebuffer,R)}else if(z){E.__webglDepthbuffer=[];for(let X=0;X<6;X++)if(t.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer[X]),E.__webglDepthbuffer[X]===void 0)E.__webglDepthbuffer[X]=i.createRenderbuffer(),Te(E.__webglDepthbuffer[X],R,!1);else{const ie=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,$=E.__webglDepthbuffer[X];i.bindRenderbuffer(i.RENDERBUFFER,$),i.framebufferRenderbuffer(i.FRAMEBUFFER,ie,i.RENDERBUFFER,$)}}else{const X=R.texture.mipmaps;if(X&&X.length>0?t.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer),E.__webglDepthbuffer===void 0)E.__webglDepthbuffer=i.createRenderbuffer(),Te(E.__webglDepthbuffer,R,!1);else{const ie=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,$=E.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,$),i.framebufferRenderbuffer(i.FRAMEBUFFER,ie,i.RENDERBUFFER,$)}}t.bindFramebuffer(i.FRAMEBUFFER,null)}function Ie(R,E,z){const X=n.get(R);E!==void 0&&Se(X.__webglFramebuffer,R,R.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),z!==void 0&&et(R)}function L(R){const E=R.texture,z=n.get(R),X=n.get(E);R.addEventListener("dispose",A);const ie=R.textures,$=R.isWebGLCubeRenderTarget===!0,De=ie.length>1;if(De||(X.__webglTexture===void 0&&(X.__webglTexture=i.createTexture()),X.__version=E.version,o.memory.textures++),$){z.__webglFramebuffer=[];for(let de=0;de<6;de++)if(E.mipmaps&&E.mipmaps.length>0){z.__webglFramebuffer[de]=[];for(let Re=0;Re<E.mipmaps.length;Re++)z.__webglFramebuffer[de][Re]=i.createFramebuffer()}else z.__webglFramebuffer[de]=i.createFramebuffer()}else{if(E.mipmaps&&E.mipmaps.length>0){z.__webglFramebuffer=[];for(let de=0;de<E.mipmaps.length;de++)z.__webglFramebuffer[de]=i.createFramebuffer()}else z.__webglFramebuffer=i.createFramebuffer();if(De)for(let de=0,Re=ie.length;de<Re;de++){const Pe=n.get(ie[de]);Pe.__webglTexture===void 0&&(Pe.__webglTexture=i.createTexture(),o.memory.textures++)}if(R.samples>0&&se(R)===!1){z.__webglMultisampledFramebuffer=i.createFramebuffer(),z.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,z.__webglMultisampledFramebuffer);for(let de=0;de<ie.length;de++){const Re=ie[de];z.__webglColorRenderbuffer[de]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,z.__webglColorRenderbuffer[de]);const Pe=r.convert(Re.format,Re.colorSpace),oe=r.convert(Re.type),ye=x(Re.internalFormat,Pe,oe,Re.colorSpace,R.isXRRenderTarget===!0),Ve=he(R);i.renderbufferStorageMultisample(i.RENDERBUFFER,Ve,ye,R.width,R.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+de,i.RENDERBUFFER,z.__webglColorRenderbuffer[de])}i.bindRenderbuffer(i.RENDERBUFFER,null),R.depthBuffer&&(z.__webglDepthRenderbuffer=i.createRenderbuffer(),Te(z.__webglDepthRenderbuffer,R,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if($){t.bindTexture(i.TEXTURE_CUBE_MAP,X.__webglTexture),xe(i.TEXTURE_CUBE_MAP,E);for(let de=0;de<6;de++)if(E.mipmaps&&E.mipmaps.length>0)for(let Re=0;Re<E.mipmaps.length;Re++)Se(z.__webglFramebuffer[de][Re],R,E,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+de,Re);else Se(z.__webglFramebuffer[de],R,E,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+de,0);m(E)&&p(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(De){for(let de=0,Re=ie.length;de<Re;de++){const Pe=ie[de],oe=n.get(Pe);let ye=i.TEXTURE_2D;(R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(ye=R.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(ye,oe.__webglTexture),xe(ye,Pe),Se(z.__webglFramebuffer,R,Pe,i.COLOR_ATTACHMENT0+de,ye,0),m(Pe)&&p(ye)}t.unbindTexture()}else{let de=i.TEXTURE_2D;if((R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(de=R.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(de,X.__webglTexture),xe(de,E),E.mipmaps&&E.mipmaps.length>0)for(let Re=0;Re<E.mipmaps.length;Re++)Se(z.__webglFramebuffer[Re],R,E,i.COLOR_ATTACHMENT0,de,Re);else Se(z.__webglFramebuffer,R,E,i.COLOR_ATTACHMENT0,de,0);m(E)&&p(de),t.unbindTexture()}R.depthBuffer&&et(R)}function Z(R){const E=R.textures;for(let z=0,X=E.length;z<X;z++){const ie=E[z];if(m(ie)){const $=y(R),De=n.get(ie).__webglTexture;t.bindTexture($,De),p($),t.unbindTexture()}}}const j=[],Y=[];function K(R){if(R.samples>0){if(se(R)===!1){const E=R.textures,z=R.width,X=R.height;let ie=i.COLOR_BUFFER_BIT;const $=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,De=n.get(R),de=E.length>1;if(de)for(let Pe=0;Pe<E.length;Pe++)t.bindFramebuffer(i.FRAMEBUFFER,De.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Pe,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,De.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Pe,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,De.__webglMultisampledFramebuffer);const Re=R.texture.mipmaps;Re&&Re.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,De.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,De.__webglFramebuffer);for(let Pe=0;Pe<E.length;Pe++){if(R.resolveDepthBuffer&&(R.depthBuffer&&(ie|=i.DEPTH_BUFFER_BIT),R.stencilBuffer&&R.resolveStencilBuffer&&(ie|=i.STENCIL_BUFFER_BIT)),de){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,De.__webglColorRenderbuffer[Pe]);const oe=n.get(E[Pe]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,oe,0)}i.blitFramebuffer(0,0,z,X,0,0,z,X,ie,i.NEAREST),l===!0&&(j.length=0,Y.length=0,j.push(i.COLOR_ATTACHMENT0+Pe),R.depthBuffer&&R.resolveDepthBuffer===!1&&(j.push($),Y.push($),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,Y)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,j))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),de)for(let Pe=0;Pe<E.length;Pe++){t.bindFramebuffer(i.FRAMEBUFFER,De.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Pe,i.RENDERBUFFER,De.__webglColorRenderbuffer[Pe]);const oe=n.get(E[Pe]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,De.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Pe,i.TEXTURE_2D,oe,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,De.__webglMultisampledFramebuffer)}else if(R.depthBuffer&&R.resolveDepthBuffer===!1&&l){const E=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[E])}}}function he(R){return Math.min(s.maxSamples,R.samples)}function se(R){const E=n.get(R);return R.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&E.__useRenderToTexture!==!1}function fe(R){const E=o.render.frame;h.get(R)!==E&&(h.set(R,E),R.update())}function Xe(R,E){const z=R.colorSpace,X=R.format,ie=R.type;return R.isCompressedTexture===!0||R.isVideoTexture===!0||z!==hs&&z!==Gn&&(ht.getTransfer(z)===gt?(X!==bn||ie!==In)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",z)),E}function Ge(R){return typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement?(c.width=R.naturalWidth||R.width,c.height=R.naturalHeight||R.height):typeof VideoFrame<"u"&&R instanceof VideoFrame?(c.width=R.displayWidth,c.height=R.displayHeight):(c.width=R.width,c.height=R.height),c}this.allocateTextureUnit=U,this.resetTextureUnits=I,this.setTexture2D=k,this.setTexture2DArray=V,this.setTexture3D=te,this.setTextureCube=H,this.rebindTextures=Ie,this.setupRenderTarget=L,this.updateRenderTargetMipmap=Z,this.updateMultisampleRenderTarget=K,this.setupDepthRenderbuffer=et,this.setupFrameBufferTexture=Se,this.useMultisampledRTT=se}function Vv(i,e){function t(n,s=Gn){let r;const o=ht.getTransfer(s);if(n===In)return i.UNSIGNED_BYTE;if(n===ul)return i.UNSIGNED_SHORT_4_4_4_4;if(n===dl)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Dh)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===Ih)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===Ph)return i.BYTE;if(n===Lh)return i.SHORT;if(n===ks)return i.UNSIGNED_SHORT;if(n===hl)return i.INT;if(n===Ai)return i.UNSIGNED_INT;if(n===Pn)return i.FLOAT;if(n===er)return i.HALF_FLOAT;if(n===Uh)return i.ALPHA;if(n===Nh)return i.RGB;if(n===bn)return i.RGBA;if(n===Hs)return i.DEPTH_COMPONENT;if(n===Gs)return i.DEPTH_STENCIL;if(n===fl)return i.RED;if(n===pl)return i.RED_INTEGER;if(n===Oh)return i.RG;if(n===ml)return i.RG_INTEGER;if(n===gl)return i.RGBA_INTEGER;if(n===Gr||n===Wr||n===Xr||n===$r)if(o===gt)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===Gr)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Wr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Xr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===$r)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===Gr)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Wr)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Xr)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===$r)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===_a||n===xa||n===ya||n===Ma)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===_a)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===xa)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===ya)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Ma)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Sa||n===ba||n===wa)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(n===Sa||n===ba)return o===gt?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===wa)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Ea||n===Aa||n===Ta||n===Ca||n===Ra||n===Pa||n===La||n===Da||n===Ia||n===Ua||n===Na||n===Oa||n===Fa||n===Ba)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Ea)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Aa)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Ta)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Ca)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Ra)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Pa)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===La)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Da)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Ia)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Ua)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Na)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Oa)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Fa)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Ba)return o===gt?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===za||n===ka||n===Va)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(n===za)return o===gt?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===ka)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Va)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Ha||n===Ga||n===Wa||n===Xa)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(n===Ha)return r.COMPRESSED_RED_RGTC1_EXT;if(n===Ga)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Wa)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Xa)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Vs?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const Hv=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Gv=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Wv{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new jh(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new nn({vertexShader:Hv,fragmentShader:Gv,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new Ne(new gs(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Xv extends ps{constructor(e,t){super();const n=this;let s=null,r=1,o=null,a="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,g=null;const _=typeof XRWebGLBinding<"u",m=new Wv,p={},y=t.getContextAttributes();let x=null,v=null;const w=[],M=[],A=new ue;let T=null;const S=new fn;S.viewport=new at;const b=new fn;b.viewport=new at;const D=[S,b],I=new cp;let U=null,B=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(J){let ee=w[J];return ee===void 0&&(ee=new Uo,w[J]=ee),ee.getTargetRaySpace()},this.getControllerGrip=function(J){let ee=w[J];return ee===void 0&&(ee=new Uo,w[J]=ee),ee.getGripSpace()},this.getHand=function(J){let ee=w[J];return ee===void 0&&(ee=new Uo,w[J]=ee),ee.getHandSpace()};function k(J){const ee=M.indexOf(J.inputSource);if(ee===-1)return;const Se=w[ee];Se!==void 0&&(Se.update(J.inputSource,J.frame,c||o),Se.dispatchEvent({type:J.type,data:J.inputSource}))}function V(){s.removeEventListener("select",k),s.removeEventListener("selectstart",k),s.removeEventListener("selectend",k),s.removeEventListener("squeeze",k),s.removeEventListener("squeezestart",k),s.removeEventListener("squeezeend",k),s.removeEventListener("end",V),s.removeEventListener("inputsourceschange",te);for(let J=0;J<w.length;J++){const ee=M[J];ee!==null&&(M[J]=null,w[J].disconnect(ee))}U=null,B=null,m.reset();for(const J in p)delete p[J];e.setRenderTarget(x),f=null,d=null,u=null,s=null,v=null,qe.stop(),n.isPresenting=!1,e.setPixelRatio(T),e.setSize(A.width,A.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(J){r=J,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(J){a=J,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(J){c=J},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u===null&&_&&(u=new XRWebGLBinding(s,t)),u},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(J){if(s=J,s!==null){if(x=e.getRenderTarget(),s.addEventListener("select",k),s.addEventListener("selectstart",k),s.addEventListener("selectend",k),s.addEventListener("squeeze",k),s.addEventListener("squeezestart",k),s.addEventListener("squeezeend",k),s.addEventListener("end",V),s.addEventListener("inputsourceschange",te),y.xrCompatible!==!0&&await t.makeXRCompatible(),T=e.getPixelRatio(),e.getSize(A),_&&"createProjectionLayer"in XRWebGLBinding.prototype){let Se=null,Te=null,Ee=null;y.depth&&(Ee=y.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,Se=y.stencil?Gs:Hs,Te=y.stencil?Vs:Ai);const et={colorFormat:t.RGBA8,depthFormat:Ee,scaleFactor:r};u=this.getBinding(),d=u.createProjectionLayer(et),s.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),v=new Ti(d.textureWidth,d.textureHeight,{format:bn,type:In,depthTexture:new Yh(d.textureWidth,d.textureHeight,Te,void 0,void 0,void 0,void 0,void 0,void 0,Se),stencilBuffer:y.stencil,colorSpace:e.outputColorSpace,samples:y.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1})}else{const Se={antialias:y.antialias,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,t,Se),s.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),v=new Ti(f.framebufferWidth,f.framebufferHeight,{format:bn,type:In,colorSpace:e.outputColorSpace,stencilBuffer:y.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1})}v.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await s.requestReferenceSpace(a),qe.setContext(s),qe.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function te(J){for(let ee=0;ee<J.removed.length;ee++){const Se=J.removed[ee],Te=M.indexOf(Se);Te>=0&&(M[Te]=null,w[Te].disconnect(Se))}for(let ee=0;ee<J.added.length;ee++){const Se=J.added[ee];let Te=M.indexOf(Se);if(Te===-1){for(let et=0;et<w.length;et++)if(et>=M.length){M.push(Se),Te=et;break}else if(M[et]===null){M[et]=Se,Te=et;break}if(Te===-1)break}const Ee=w[Te];Ee&&Ee.connect(Se)}}const H=new P,Q=new P;function re(J,ee,Se){H.setFromMatrixPosition(ee.matrixWorld),Q.setFromMatrixPosition(Se.matrixWorld);const Te=H.distanceTo(Q),Ee=ee.projectionMatrix.elements,et=Se.projectionMatrix.elements,Ie=Ee[14]/(Ee[10]-1),L=Ee[14]/(Ee[10]+1),Z=(Ee[9]+1)/Ee[5],j=(Ee[9]-1)/Ee[5],Y=(Ee[8]-1)/Ee[0],K=(et[8]+1)/et[0],he=Ie*Y,se=Ie*K,fe=Te/(-Y+K),Xe=fe*-Y;if(ee.matrixWorld.decompose(J.position,J.quaternion,J.scale),J.translateX(Xe),J.translateZ(fe),J.matrixWorld.compose(J.position,J.quaternion,J.scale),J.matrixWorldInverse.copy(J.matrixWorld).invert(),Ee[10]===-1)J.projectionMatrix.copy(ee.projectionMatrix),J.projectionMatrixInverse.copy(ee.projectionMatrixInverse);else{const Ge=Ie+fe,R=L+fe,E=he-Xe,z=se+(Te-Xe),X=Z*L/R*Ge,ie=j*L/R*Ge;J.projectionMatrix.makePerspective(E,z,X,ie,Ge,R),J.projectionMatrixInverse.copy(J.projectionMatrix).invert()}}function ge(J,ee){ee===null?J.matrixWorld.copy(J.matrix):J.matrixWorld.multiplyMatrices(ee.matrixWorld,J.matrix),J.matrixWorldInverse.copy(J.matrixWorld).invert()}this.updateCamera=function(J){if(s===null)return;let ee=J.near,Se=J.far;m.texture!==null&&(m.depthNear>0&&(ee=m.depthNear),m.depthFar>0&&(Se=m.depthFar)),I.near=b.near=S.near=ee,I.far=b.far=S.far=Se,(U!==I.near||B!==I.far)&&(s.updateRenderState({depthNear:I.near,depthFar:I.far}),U=I.near,B=I.far),I.layers.mask=J.layers.mask|6,S.layers.mask=I.layers.mask&3,b.layers.mask=I.layers.mask&5;const Te=J.parent,Ee=I.cameras;ge(I,Te);for(let et=0;et<Ee.length;et++)ge(Ee[et],Te);Ee.length===2?re(I,S,b):I.projectionMatrix.copy(S.projectionMatrix),xe(J,I,Te)};function xe(J,ee,Se){Se===null?J.matrix.copy(ee.matrixWorld):(J.matrix.copy(Se.matrixWorld),J.matrix.invert(),J.matrix.multiply(ee.matrixWorld)),J.matrix.decompose(J.position,J.quaternion,J.scale),J.updateMatrixWorld(!0),J.projectionMatrix.copy(ee.projectionMatrix),J.projectionMatrixInverse.copy(ee.projectionMatrixInverse),J.isPerspectiveCamera&&(J.fov=Ws*2*Math.atan(1/J.projectionMatrix.elements[5]),J.zoom=1)}this.getCamera=function(){return I},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(J){l=J,d!==null&&(d.fixedFoveation=J),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=J)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(I)},this.getCameraTexture=function(J){return p[J]};let Qe=null;function ot(J,ee){if(h=ee.getViewerPose(c||o),g=ee,h!==null){const Se=h.views;f!==null&&(e.setRenderTargetFramebuffer(v,f.framebuffer),e.setRenderTarget(v));let Te=!1;Se.length!==I.cameras.length&&(I.cameras.length=0,Te=!0);for(let L=0;L<Se.length;L++){const Z=Se[L];let j=null;if(f!==null)j=f.getViewport(Z);else{const K=u.getViewSubImage(d,Z);j=K.viewport,L===0&&(e.setRenderTargetTextures(v,K.colorTexture,K.depthStencilTexture),e.setRenderTarget(v))}let Y=D[L];Y===void 0&&(Y=new fn,Y.layers.enable(L),Y.viewport=new at,D[L]=Y),Y.matrix.fromArray(Z.transform.matrix),Y.matrix.decompose(Y.position,Y.quaternion,Y.scale),Y.projectionMatrix.fromArray(Z.projectionMatrix),Y.projectionMatrixInverse.copy(Y.projectionMatrix).invert(),Y.viewport.set(j.x,j.y,j.width,j.height),L===0&&(I.matrix.copy(Y.matrix),I.matrix.decompose(I.position,I.quaternion,I.scale)),Te===!0&&I.cameras.push(Y)}const Ee=s.enabledFeatures;if(Ee&&Ee.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&_){u=n.getBinding();const L=u.getDepthInformation(Se[0]);L&&L.isValid&&L.texture&&m.init(L,s.renderState)}if(Ee&&Ee.includes("camera-access")&&_){e.state.unbindTexture(),u=n.getBinding();for(let L=0;L<Se.length;L++){const Z=Se[L].camera;if(Z){let j=p[Z];j||(j=new jh,p[Z]=j);const Y=u.getCameraImage(Z);j.sourceTexture=Y}}}}for(let Se=0;Se<w.length;Se++){const Te=M[Se],Ee=w[Se];Te!==null&&Ee!==void 0&&Ee.update(Te,ee,c||o)}Qe&&Qe(J,ee),ee.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:ee}),g=null}const qe=new au;qe.setAnimationLoop(ot),this.setAnimationLoop=function(J){Qe=J},this.dispose=function(){}}}const vi=new En,$v=new st;function qv(i,e){function t(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,Gh(i)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function s(m,p,y,x,v){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(m,p):p.isMeshToonMaterial?(r(m,p),u(m,p)):p.isMeshPhongMaterial?(r(m,p),h(m,p)):p.isMeshStandardMaterial?(r(m,p),d(m,p),p.isMeshPhysicalMaterial&&f(m,p,v)):p.isMeshMatcapMaterial?(r(m,p),g(m,p)):p.isMeshDepthMaterial?r(m,p):p.isMeshDistanceMaterial?(r(m,p),_(m,p)):p.isMeshNormalMaterial?r(m,p):p.isLineBasicMaterial?(o(m,p),p.isLineDashedMaterial&&a(m,p)):p.isPointsMaterial?l(m,p,y,x):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,t(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===jt&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,t(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===jt&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,t(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,t(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const y=e.get(p),x=y.envMap,v=y.envMapRotation;x&&(m.envMap.value=x,vi.copy(v),vi.x*=-1,vi.y*=-1,vi.z*=-1,x.isCubeTexture&&x.isRenderTargetTexture===!1&&(vi.y*=-1,vi.z*=-1),m.envMapRotation.value.setFromMatrix4($v.makeRotationFromEuler(vi)),m.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,t(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,m.aoMapTransform))}function o(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform))}function a(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,y,x){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*y,m.scale.value=x*.5,p.map&&(m.map.value=p.map,t(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function u(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function d(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,y){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===jt&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=y.texture,m.transmissionSamplerSize.value.set(y.width,y.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function _(m,p){const y=e.get(p).light;m.referencePosition.value.setFromMatrixPosition(y.matrixWorld),m.nearDistance.value=y.shadow.camera.near,m.farDistance.value=y.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function Yv(i,e,t,n){let s={},r={},o=[];const a=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(y,x){const v=x.program;n.uniformBlockBinding(y,v)}function c(y,x){let v=s[y.id];v===void 0&&(g(y),v=h(y),s[y.id]=v,y.addEventListener("dispose",m));const w=x.program;n.updateUBOMapping(y,w);const M=e.render.frame;r[y.id]!==M&&(d(y),r[y.id]=M)}function h(y){const x=u();y.__bindingPointIndex=x;const v=i.createBuffer(),w=y.__size,M=y.usage;return i.bindBuffer(i.UNIFORM_BUFFER,v),i.bufferData(i.UNIFORM_BUFFER,w,M),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,x,v),v}function u(){for(let y=0;y<a;y++)if(o.indexOf(y)===-1)return o.push(y),y;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(y){const x=s[y.id],v=y.uniforms,w=y.__cache;i.bindBuffer(i.UNIFORM_BUFFER,x);for(let M=0,A=v.length;M<A;M++){const T=Array.isArray(v[M])?v[M]:[v[M]];for(let S=0,b=T.length;S<b;S++){const D=T[S];if(f(D,M,S,w)===!0){const I=D.__offset,U=Array.isArray(D.value)?D.value:[D.value];let B=0;for(let k=0;k<U.length;k++){const V=U[k],te=_(V);typeof V=="number"||typeof V=="boolean"?(D.__data[0]=V,i.bufferSubData(i.UNIFORM_BUFFER,I+B,D.__data)):V.isMatrix3?(D.__data[0]=V.elements[0],D.__data[1]=V.elements[1],D.__data[2]=V.elements[2],D.__data[3]=0,D.__data[4]=V.elements[3],D.__data[5]=V.elements[4],D.__data[6]=V.elements[5],D.__data[7]=0,D.__data[8]=V.elements[6],D.__data[9]=V.elements[7],D.__data[10]=V.elements[8],D.__data[11]=0):(V.toArray(D.__data,B),B+=te.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,I,D.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(y,x,v,w){const M=y.value,A=x+"_"+v;if(w[A]===void 0)return typeof M=="number"||typeof M=="boolean"?w[A]=M:w[A]=M.clone(),!0;{const T=w[A];if(typeof M=="number"||typeof M=="boolean"){if(T!==M)return w[A]=M,!0}else if(T.equals(M)===!1)return T.copy(M),!0}return!1}function g(y){const x=y.uniforms;let v=0;const w=16;for(let A=0,T=x.length;A<T;A++){const S=Array.isArray(x[A])?x[A]:[x[A]];for(let b=0,D=S.length;b<D;b++){const I=S[b],U=Array.isArray(I.value)?I.value:[I.value];for(let B=0,k=U.length;B<k;B++){const V=U[B],te=_(V),H=v%w,Q=H%te.boundary,re=H+Q;v+=Q,re!==0&&w-re<te.storage&&(v+=w-re),I.__data=new Float32Array(te.storage/Float32Array.BYTES_PER_ELEMENT),I.__offset=v,v+=te.storage}}}const M=v%w;return M>0&&(v+=w-M),y.__size=v,y.__cache={},this}function _(y){const x={boundary:0,storage:0};return typeof y=="number"||typeof y=="boolean"?(x.boundary=4,x.storage=4):y.isVector2?(x.boundary=8,x.storage=8):y.isVector3||y.isColor?(x.boundary=16,x.storage=12):y.isVector4?(x.boundary=16,x.storage=16):y.isMatrix3?(x.boundary=48,x.storage=48):y.isMatrix4?(x.boundary=64,x.storage=64):y.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",y),x}function m(y){const x=y.target;x.removeEventListener("dispose",m);const v=o.indexOf(x.__bindingPointIndex);o.splice(v,1),i.deleteBuffer(s[x.id]),delete s[x.id],delete r[x.id]}function p(){for(const y in s)i.deleteBuffer(s[y]);o=[],s={},r={}}return{bind:l,update:c,dispose:p}}class jv{constructor(e={}){const{canvas:t=kd(),context:n=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:d=!1}=e;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=o;const g=new Uint32Array(4),_=new Int32Array(4);let m=null,p=null;const y=[],x=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=ci,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const v=this;let w=!1;this._outputColorSpace=Wt;let M=0,A=0,T=null,S=-1,b=null;const D=new at,I=new at;let U=null;const B=new Oe(0);let k=0,V=t.width,te=t.height,H=1,Q=null,re=null;const ge=new at(0,0,V,te),xe=new at(0,0,V,te);let Qe=!1;const ot=new bl;let qe=!1,J=!1;const ee=new st,Se=new P,Te=new at,Ee={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let et=!1;function Ie(){return T===null?H:1}let L=n;function Z(C,O){return t.getContext(C,O)}try{const C={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${ll}`),t.addEventListener("webglcontextlost",pe,!1),t.addEventListener("webglcontextrestored",Ae,!1),t.addEventListener("webglcontextcreationerror",ae,!1),L===null){const O="webgl2";if(L=Z(O,C),L===null)throw Z(O)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(C){throw console.error("THREE.WebGLRenderer: "+C.message),C}let j,Y,K,he,se,fe,Xe,Ge,R,E,z,X,ie,$,De,de,Re,Pe,oe,ye,Ve,Ue,ve,Ye;function N(){j=new r0(L),j.init(),Ue=new Vv(L,j),Y=new Jg(L,j,e,Ue),K=new zv(L,j),Y.reversedDepthBuffer&&d&&K.buffers.depth.setReversed(!0),he=new l0(L),se=new Av,fe=new kv(L,j,K,se,Y,Ue,he),Xe=new e0(v),Ge=new s0(v),R=new pp(L),ve=new Kg(L,R),E=new o0(L,R,he,ve),z=new h0(L,E,R,he),oe=new c0(L,Y,fe),de=new Qg(se),X=new Ev(v,Xe,Ge,j,Y,ve,de),ie=new qv(v,se),$=new Cv,De=new Uv(j),Pe=new jg(v,Xe,Ge,K,z,f,l),Re=new Fv(v,z,Y),Ye=new Yv(L,he,Y,K),ye=new Zg(L,j,he),Ve=new a0(L,j,he),he.programs=X.programs,v.capabilities=Y,v.extensions=j,v.properties=se,v.renderLists=$,v.shadowMap=Re,v.state=K,v.info=he}N();const ce=new Xv(v,L);this.xr=ce,this.getContext=function(){return L},this.getContextAttributes=function(){return L.getContextAttributes()},this.forceContextLoss=function(){const C=j.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){const C=j.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return H},this.setPixelRatio=function(C){C!==void 0&&(H=C,this.setSize(V,te,!1))},this.getSize=function(C){return C.set(V,te)},this.setSize=function(C,O,G=!0){if(ce.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}V=C,te=O,t.width=Math.floor(C*H),t.height=Math.floor(O*H),G===!0&&(t.style.width=C+"px",t.style.height=O+"px"),this.setViewport(0,0,C,O)},this.getDrawingBufferSize=function(C){return C.set(V*H,te*H).floor()},this.setDrawingBufferSize=function(C,O,G){V=C,te=O,H=G,t.width=Math.floor(C*G),t.height=Math.floor(O*G),this.setViewport(0,0,C,O)},this.getCurrentViewport=function(C){return C.copy(D)},this.getViewport=function(C){return C.copy(ge)},this.setViewport=function(C,O,G,W){C.isVector4?ge.set(C.x,C.y,C.z,C.w):ge.set(C,O,G,W),K.viewport(D.copy(ge).multiplyScalar(H).round())},this.getScissor=function(C){return C.copy(xe)},this.setScissor=function(C,O,G,W){C.isVector4?xe.set(C.x,C.y,C.z,C.w):xe.set(C,O,G,W),K.scissor(I.copy(xe).multiplyScalar(H).round())},this.getScissorTest=function(){return Qe},this.setScissorTest=function(C){K.setScissorTest(Qe=C)},this.setOpaqueSort=function(C){Q=C},this.setTransparentSort=function(C){re=C},this.getClearColor=function(C){return C.copy(Pe.getClearColor())},this.setClearColor=function(){Pe.setClearColor(...arguments)},this.getClearAlpha=function(){return Pe.getClearAlpha()},this.setClearAlpha=function(){Pe.setClearAlpha(...arguments)},this.clear=function(C=!0,O=!0,G=!0){let W=0;if(C){let F=!1;if(T!==null){const le=T.texture.format;F=le===gl||le===ml||le===pl}if(F){const le=T.texture.type,_e=le===In||le===Ai||le===ks||le===Vs||le===ul||le===dl,Ce=Pe.getClearColor(),we=Pe.getClearAlpha(),ze=Ce.r,He=Ce.g,Fe=Ce.b;_e?(g[0]=ze,g[1]=He,g[2]=Fe,g[3]=we,L.clearBufferuiv(L.COLOR,0,g)):(_[0]=ze,_[1]=He,_[2]=Fe,_[3]=we,L.clearBufferiv(L.COLOR,0,_))}else W|=L.COLOR_BUFFER_BIT}O&&(W|=L.DEPTH_BUFFER_BIT),G&&(W|=L.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),L.clear(W)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",pe,!1),t.removeEventListener("webglcontextrestored",Ae,!1),t.removeEventListener("webglcontextcreationerror",ae,!1),Pe.dispose(),$.dispose(),De.dispose(),se.dispose(),Xe.dispose(),Ge.dispose(),z.dispose(),ve.dispose(),Ye.dispose(),X.dispose(),ce.dispose(),ce.removeEventListener("sessionstart",An),ce.removeEventListener("sessionend",kl),hi.stop()};function pe(C){C.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),w=!0}function Ae(){console.log("THREE.WebGLRenderer: Context Restored."),w=!1;const C=he.autoReset,O=Re.enabled,G=Re.autoUpdate,W=Re.needsUpdate,F=Re.type;N(),he.autoReset=C,Re.enabled=O,Re.autoUpdate=G,Re.needsUpdate=W,Re.type=F}function ae(C){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function ne(C){const O=C.target;O.removeEventListener("dispose",ne),Le(O)}function Le(C){$e(C),se.remove(C)}function $e(C){const O=se.get(C).programs;O!==void 0&&(O.forEach(function(G){X.releaseProgram(G)}),C.isShaderMaterial&&X.releaseShaderCache(C))}this.renderBufferDirect=function(C,O,G,W,F,le){O===null&&(O=Ee);const _e=F.isMesh&&F.matrixWorld.determinant()<0,Ce=Pu(C,O,G,W,F);K.setMaterial(W,_e);let we=G.index,ze=1;if(W.wireframe===!0){if(we=E.getWireframeAttribute(G),we===void 0)return;ze=2}const He=G.drawRange,Fe=G.attributes.position;let nt=He.start*ze,pt=(He.start+He.count)*ze;le!==null&&(nt=Math.max(nt,le.start*ze),pt=Math.min(pt,(le.start+le.count)*ze)),we!==null?(nt=Math.max(nt,0),pt=Math.min(pt,we.count)):Fe!=null&&(nt=Math.max(nt,0),pt=Math.min(pt,Fe.count));const At=pt-nt;if(At<0||At===1/0)return;ve.setup(F,W,Ce,G,we);let Mt,vt=ye;if(we!==null&&(Mt=R.get(we),vt=Ve,vt.setIndex(Mt)),F.isMesh)W.wireframe===!0?(K.setLineWidth(W.wireframeLinewidth*Ie()),vt.setMode(L.LINES)):vt.setMode(L.TRIANGLES);else if(F.isLine){let Be=W.linewidth;Be===void 0&&(Be=1),K.setLineWidth(Be*Ie()),F.isLineSegments?vt.setMode(L.LINES):F.isLineLoop?vt.setMode(L.LINE_LOOP):vt.setMode(L.LINE_STRIP)}else F.isPoints?vt.setMode(L.POINTS):F.isSprite&&vt.setMode(L.TRIANGLES);if(F.isBatchedMesh)if(F._multiDrawInstances!==null)$s("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),vt.renderMultiDrawInstances(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount,F._multiDrawInstances);else if(j.get("WEBGL_multi_draw"))vt.renderMultiDraw(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount);else{const Be=F._multiDrawStarts,St=F._multiDrawCounts,lt=F._multiDrawCount,sn=we?R.get(we).bytesPerElement:1,Pi=se.get(W).currentProgram.getUniforms();for(let rn=0;rn<lt;rn++)Pi.setValue(L,"_gl_DrawID",rn),vt.render(Be[rn]/sn,St[rn])}else if(F.isInstancedMesh)vt.renderInstances(nt,At,F.count);else if(G.isInstancedBufferGeometry){const Be=G._maxInstanceCount!==void 0?G._maxInstanceCount:1/0,St=Math.min(G.instanceCount,Be);vt.renderInstances(nt,At,St)}else vt.render(nt,At)};function _t(C,O,G){C.transparent===!0&&C.side===wt&&C.forceSinglePass===!1?(C.side=jt,C.needsUpdate=!0,or(C,O,G),C.side=jn,C.needsUpdate=!0,or(C,O,G),C.side=wt):or(C,O,G)}this.compile=function(C,O,G=null){G===null&&(G=C),p=De.get(G),p.init(O),x.push(p),G.traverseVisible(function(F){F.isLight&&F.layers.test(O.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),C!==G&&C.traverseVisible(function(F){F.isLight&&F.layers.test(O.layers)&&(p.pushLight(F),F.castShadow&&p.pushShadow(F))}),p.setupLights();const W=new Set;return C.traverse(function(F){if(!(F.isMesh||F.isPoints||F.isLine||F.isSprite))return;const le=F.material;if(le)if(Array.isArray(le))for(let _e=0;_e<le.length;_e++){const Ce=le[_e];_t(Ce,G,F),W.add(Ce)}else _t(le,G,F),W.add(le)}),p=x.pop(),W},this.compileAsync=function(C,O,G=null){const W=this.compile(C,O,G);return new Promise(F=>{function le(){if(W.forEach(function(_e){se.get(_e).currentProgram.isReady()&&W.delete(_e)}),W.size===0){F(C);return}setTimeout(le,10)}j.get("KHR_parallel_shader_compile")!==null?le():setTimeout(le,10)})};let dt=null;function Nn(C){dt&&dt(C)}function An(){hi.stop()}function kl(){hi.start()}const hi=new au;hi.setAnimationLoop(Nn),typeof self<"u"&&hi.setContext(self),this.setAnimationLoop=function(C){dt=C,ce.setAnimationLoop(C),C===null?hi.stop():hi.start()},ce.addEventListener("sessionstart",An),ce.addEventListener("sessionend",kl),this.render=function(C,O){if(O!==void 0&&O.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(w===!0)return;if(C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),O.parent===null&&O.matrixWorldAutoUpdate===!0&&O.updateMatrixWorld(),ce.enabled===!0&&ce.isPresenting===!0&&(ce.cameraAutoUpdate===!0&&ce.updateCamera(O),O=ce.getCamera()),C.isScene===!0&&C.onBeforeRender(v,C,O,T),p=De.get(C,x.length),p.init(O),x.push(p),ee.multiplyMatrices(O.projectionMatrix,O.matrixWorldInverse),ot.setFromProjectionMatrix(ee,Ln,O.reversedDepth),J=this.localClippingEnabled,qe=de.init(this.clippingPlanes,J),m=$.get(C,y.length),m.init(),y.push(m),ce.enabled===!0&&ce.isPresenting===!0){const le=v.xr.getDepthSensingMesh();le!==null&&ho(le,O,-1/0,v.sortObjects)}ho(C,O,0,v.sortObjects),m.finish(),v.sortObjects===!0&&m.sort(Q,re),et=ce.enabled===!1||ce.isPresenting===!1||ce.hasDepthSensing()===!1,et&&Pe.addToRenderList(m,C),this.info.render.frame++,qe===!0&&de.beginShadows();const G=p.state.shadowsArray;Re.render(G,C,O),qe===!0&&de.endShadows(),this.info.autoReset===!0&&this.info.reset();const W=m.opaque,F=m.transmissive;if(p.setupLights(),O.isArrayCamera){const le=O.cameras;if(F.length>0)for(let _e=0,Ce=le.length;_e<Ce;_e++){const we=le[_e];Hl(W,F,C,we)}et&&Pe.render(C);for(let _e=0,Ce=le.length;_e<Ce;_e++){const we=le[_e];Vl(m,C,we,we.viewport)}}else F.length>0&&Hl(W,F,C,O),et&&Pe.render(C),Vl(m,C,O);T!==null&&A===0&&(fe.updateMultisampleRenderTarget(T),fe.updateRenderTargetMipmap(T)),C.isScene===!0&&C.onAfterRender(v,C,O),ve.resetDefaultState(),S=-1,b=null,x.pop(),x.length>0?(p=x[x.length-1],qe===!0&&de.setGlobalState(v.clippingPlanes,p.state.camera)):p=null,y.pop(),y.length>0?m=y[y.length-1]:m=null};function ho(C,O,G,W){if(C.visible===!1)return;if(C.layers.test(O.layers)){if(C.isGroup)G=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(O);else if(C.isLight)p.pushLight(C),C.castShadow&&p.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||ot.intersectsSprite(C)){W&&Te.setFromMatrixPosition(C.matrixWorld).applyMatrix4(ee);const _e=z.update(C),Ce=C.material;Ce.visible&&m.push(C,_e,Ce,G,Te.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||ot.intersectsObject(C))){const _e=z.update(C),Ce=C.material;if(W&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),Te.copy(C.boundingSphere.center)):(_e.boundingSphere===null&&_e.computeBoundingSphere(),Te.copy(_e.boundingSphere.center)),Te.applyMatrix4(C.matrixWorld).applyMatrix4(ee)),Array.isArray(Ce)){const we=_e.groups;for(let ze=0,He=we.length;ze<He;ze++){const Fe=we[ze],nt=Ce[Fe.materialIndex];nt&&nt.visible&&m.push(C,_e,nt,G,Te.z,Fe)}}else Ce.visible&&m.push(C,_e,Ce,G,Te.z,null)}}const le=C.children;for(let _e=0,Ce=le.length;_e<Ce;_e++)ho(le[_e],O,G,W)}function Vl(C,O,G,W){const F=C.opaque,le=C.transmissive,_e=C.transparent;p.setupLightsView(G),qe===!0&&de.setGlobalState(v.clippingPlanes,G),W&&K.viewport(D.copy(W)),F.length>0&&rr(F,O,G),le.length>0&&rr(le,O,G),_e.length>0&&rr(_e,O,G),K.buffers.depth.setTest(!0),K.buffers.depth.setMask(!0),K.buffers.color.setMask(!0),K.setPolygonOffset(!1)}function Hl(C,O,G,W){if((G.isScene===!0?G.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[W.id]===void 0&&(p.state.transmissionRenderTarget[W.id]=new Ti(1,1,{generateMipmaps:!0,type:j.has("EXT_color_buffer_half_float")||j.has("EXT_color_buffer_float")?er:In,minFilter:oi,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:ht.workingColorSpace}));const le=p.state.transmissionRenderTarget[W.id],_e=W.viewport||D;le.setSize(_e.z*v.transmissionResolutionScale,_e.w*v.transmissionResolutionScale);const Ce=v.getRenderTarget(),we=v.getActiveCubeFace(),ze=v.getActiveMipmapLevel();v.setRenderTarget(le),v.getClearColor(B),k=v.getClearAlpha(),k<1&&v.setClearColor(16777215,.5),v.clear(),et&&Pe.render(G);const He=v.toneMapping;v.toneMapping=ci;const Fe=W.viewport;if(W.viewport!==void 0&&(W.viewport=void 0),p.setupLightsView(W),qe===!0&&de.setGlobalState(v.clippingPlanes,W),rr(C,G,W),fe.updateMultisampleRenderTarget(le),fe.updateRenderTargetMipmap(le),j.has("WEBGL_multisampled_render_to_texture")===!1){let nt=!1;for(let pt=0,At=O.length;pt<At;pt++){const Mt=O[pt],vt=Mt.object,Be=Mt.geometry,St=Mt.material,lt=Mt.group;if(St.side===wt&&vt.layers.test(W.layers)){const sn=St.side;St.side=jt,St.needsUpdate=!0,Gl(vt,G,W,Be,St,lt),St.side=sn,St.needsUpdate=!0,nt=!0}}nt===!0&&(fe.updateMultisampleRenderTarget(le),fe.updateRenderTargetMipmap(le))}v.setRenderTarget(Ce,we,ze),v.setClearColor(B,k),Fe!==void 0&&(W.viewport=Fe),v.toneMapping=He}function rr(C,O,G){const W=O.isScene===!0?O.overrideMaterial:null;for(let F=0,le=C.length;F<le;F++){const _e=C[F],Ce=_e.object,we=_e.geometry,ze=_e.group;let He=_e.material;He.allowOverride===!0&&W!==null&&(He=W),Ce.layers.test(G.layers)&&Gl(Ce,O,G,we,He,ze)}}function Gl(C,O,G,W,F,le){C.onBeforeRender(v,O,G,W,F,le),C.modelViewMatrix.multiplyMatrices(G.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),F.onBeforeRender(v,O,G,W,C,le),F.transparent===!0&&F.side===wt&&F.forceSinglePass===!1?(F.side=jt,F.needsUpdate=!0,v.renderBufferDirect(G,O,W,F,C,le),F.side=jn,F.needsUpdate=!0,v.renderBufferDirect(G,O,W,F,C,le),F.side=wt):v.renderBufferDirect(G,O,W,F,C,le),C.onAfterRender(v,O,G,W,F,le)}function or(C,O,G){O.isScene!==!0&&(O=Ee);const W=se.get(C),F=p.state.lights,le=p.state.shadowsArray,_e=F.state.version,Ce=X.getParameters(C,F.state,le,O,G),we=X.getProgramCacheKey(Ce);let ze=W.programs;W.environment=C.isMeshStandardMaterial?O.environment:null,W.fog=O.fog,W.envMap=(C.isMeshStandardMaterial?Ge:Xe).get(C.envMap||W.environment),W.envMapRotation=W.environment!==null&&C.envMap===null?O.environmentRotation:C.envMapRotation,ze===void 0&&(C.addEventListener("dispose",ne),ze=new Map,W.programs=ze);let He=ze.get(we);if(He!==void 0){if(W.currentProgram===He&&W.lightsStateVersion===_e)return Xl(C,Ce),He}else Ce.uniforms=X.getUniforms(C),C.onBeforeCompile(Ce,v),He=X.acquireProgram(Ce,we),ze.set(we,He),W.uniforms=Ce.uniforms;const Fe=W.uniforms;return(!C.isShaderMaterial&&!C.isRawShaderMaterial||C.clipping===!0)&&(Fe.clippingPlanes=de.uniform),Xl(C,Ce),W.needsLights=Du(C),W.lightsStateVersion=_e,W.needsLights&&(Fe.ambientLightColor.value=F.state.ambient,Fe.lightProbe.value=F.state.probe,Fe.directionalLights.value=F.state.directional,Fe.directionalLightShadows.value=F.state.directionalShadow,Fe.spotLights.value=F.state.spot,Fe.spotLightShadows.value=F.state.spotShadow,Fe.rectAreaLights.value=F.state.rectArea,Fe.ltc_1.value=F.state.rectAreaLTC1,Fe.ltc_2.value=F.state.rectAreaLTC2,Fe.pointLights.value=F.state.point,Fe.pointLightShadows.value=F.state.pointShadow,Fe.hemisphereLights.value=F.state.hemi,Fe.directionalShadowMap.value=F.state.directionalShadowMap,Fe.directionalShadowMatrix.value=F.state.directionalShadowMatrix,Fe.spotShadowMap.value=F.state.spotShadowMap,Fe.spotLightMatrix.value=F.state.spotLightMatrix,Fe.spotLightMap.value=F.state.spotLightMap,Fe.pointShadowMap.value=F.state.pointShadowMap,Fe.pointShadowMatrix.value=F.state.pointShadowMatrix),W.currentProgram=He,W.uniformsList=null,He}function Wl(C){if(C.uniformsList===null){const O=C.currentProgram.getUniforms();C.uniformsList=qr.seqWithValue(O.seq,C.uniforms)}return C.uniformsList}function Xl(C,O){const G=se.get(C);G.outputColorSpace=O.outputColorSpace,G.batching=O.batching,G.batchingColor=O.batchingColor,G.instancing=O.instancing,G.instancingColor=O.instancingColor,G.instancingMorph=O.instancingMorph,G.skinning=O.skinning,G.morphTargets=O.morphTargets,G.morphNormals=O.morphNormals,G.morphColors=O.morphColors,G.morphTargetsCount=O.morphTargetsCount,G.numClippingPlanes=O.numClippingPlanes,G.numIntersection=O.numClipIntersection,G.vertexAlphas=O.vertexAlphas,G.vertexTangents=O.vertexTangents,G.toneMapping=O.toneMapping}function Pu(C,O,G,W,F){O.isScene!==!0&&(O=Ee),fe.resetTextureUnits();const le=O.fog,_e=W.isMeshStandardMaterial?O.environment:null,Ce=T===null?v.outputColorSpace:T.isXRRenderTarget===!0?T.texture.colorSpace:hs,we=(W.isMeshStandardMaterial?Ge:Xe).get(W.envMap||_e),ze=W.vertexColors===!0&&!!G.attributes.color&&G.attributes.color.itemSize===4,He=!!G.attributes.tangent&&(!!W.normalMap||W.anisotropy>0),Fe=!!G.morphAttributes.position,nt=!!G.morphAttributes.normal,pt=!!G.morphAttributes.color;let At=ci;W.toneMapped&&(T===null||T.isXRRenderTarget===!0)&&(At=v.toneMapping);const Mt=G.morphAttributes.position||G.morphAttributes.normal||G.morphAttributes.color,vt=Mt!==void 0?Mt.length:0,Be=se.get(W),St=p.state.lights;if(qe===!0&&(J===!0||C!==b)){const $t=C===b&&W.id===S;de.setState(W,C,$t)}let lt=!1;W.version===Be.__version?(Be.needsLights&&Be.lightsStateVersion!==St.state.version||Be.outputColorSpace!==Ce||F.isBatchedMesh&&Be.batching===!1||!F.isBatchedMesh&&Be.batching===!0||F.isBatchedMesh&&Be.batchingColor===!0&&F.colorTexture===null||F.isBatchedMesh&&Be.batchingColor===!1&&F.colorTexture!==null||F.isInstancedMesh&&Be.instancing===!1||!F.isInstancedMesh&&Be.instancing===!0||F.isSkinnedMesh&&Be.skinning===!1||!F.isSkinnedMesh&&Be.skinning===!0||F.isInstancedMesh&&Be.instancingColor===!0&&F.instanceColor===null||F.isInstancedMesh&&Be.instancingColor===!1&&F.instanceColor!==null||F.isInstancedMesh&&Be.instancingMorph===!0&&F.morphTexture===null||F.isInstancedMesh&&Be.instancingMorph===!1&&F.morphTexture!==null||Be.envMap!==we||W.fog===!0&&Be.fog!==le||Be.numClippingPlanes!==void 0&&(Be.numClippingPlanes!==de.numPlanes||Be.numIntersection!==de.numIntersection)||Be.vertexAlphas!==ze||Be.vertexTangents!==He||Be.morphTargets!==Fe||Be.morphNormals!==nt||Be.morphColors!==pt||Be.toneMapping!==At||Be.morphTargetsCount!==vt)&&(lt=!0):(lt=!0,Be.__version=W.version);let sn=Be.currentProgram;lt===!0&&(sn=or(W,O,F));let Pi=!1,rn=!1,_s=!1;const bt=sn.getUniforms(),hn=Be.uniforms;if(K.useProgram(sn.program)&&(Pi=!0,rn=!0,_s=!0),W.id!==S&&(S=W.id,rn=!0),Pi||b!==C){K.buffers.depth.getReversed()&&C.reversedDepth!==!0&&(C._reversedDepth=!0,C.updateProjectionMatrix()),bt.setValue(L,"projectionMatrix",C.projectionMatrix),bt.setValue(L,"viewMatrix",C.matrixWorldInverse);const Kt=bt.map.cameraPosition;Kt!==void 0&&Kt.setValue(L,Se.setFromMatrixPosition(C.matrixWorld)),Y.logarithmicDepthBuffer&&bt.setValue(L,"logDepthBufFC",2/(Math.log(C.far+1)/Math.LN2)),(W.isMeshPhongMaterial||W.isMeshToonMaterial||W.isMeshLambertMaterial||W.isMeshBasicMaterial||W.isMeshStandardMaterial||W.isShaderMaterial)&&bt.setValue(L,"isOrthographic",C.isOrthographicCamera===!0),b!==C&&(b=C,rn=!0,_s=!0)}if(F.isSkinnedMesh){bt.setOptional(L,F,"bindMatrix"),bt.setOptional(L,F,"bindMatrixInverse");const $t=F.skeleton;$t&&($t.boneTexture===null&&$t.computeBoneTexture(),bt.setValue(L,"boneTexture",$t.boneTexture,fe))}F.isBatchedMesh&&(bt.setOptional(L,F,"batchingTexture"),bt.setValue(L,"batchingTexture",F._matricesTexture,fe),bt.setOptional(L,F,"batchingIdTexture"),bt.setValue(L,"batchingIdTexture",F._indirectTexture,fe),bt.setOptional(L,F,"batchingColorTexture"),F._colorsTexture!==null&&bt.setValue(L,"batchingColorTexture",F._colorsTexture,fe));const un=G.morphAttributes;if((un.position!==void 0||un.normal!==void 0||un.color!==void 0)&&oe.update(F,G,sn),(rn||Be.receiveShadow!==F.receiveShadow)&&(Be.receiveShadow=F.receiveShadow,bt.setValue(L,"receiveShadow",F.receiveShadow)),W.isMeshGouraudMaterial&&W.envMap!==null&&(hn.envMap.value=we,hn.flipEnvMap.value=we.isCubeTexture&&we.isRenderTargetTexture===!1?-1:1),W.isMeshStandardMaterial&&W.envMap===null&&O.environment!==null&&(hn.envMapIntensity.value=O.environmentIntensity),rn&&(bt.setValue(L,"toneMappingExposure",v.toneMappingExposure),Be.needsLights&&Lu(hn,_s),le&&W.fog===!0&&ie.refreshFogUniforms(hn,le),ie.refreshMaterialUniforms(hn,W,H,te,p.state.transmissionRenderTarget[C.id]),qr.upload(L,Wl(Be),hn,fe)),W.isShaderMaterial&&W.uniformsNeedUpdate===!0&&(qr.upload(L,Wl(Be),hn,fe),W.uniformsNeedUpdate=!1),W.isSpriteMaterial&&bt.setValue(L,"center",F.center),bt.setValue(L,"modelViewMatrix",F.modelViewMatrix),bt.setValue(L,"normalMatrix",F.normalMatrix),bt.setValue(L,"modelMatrix",F.matrixWorld),W.isShaderMaterial||W.isRawShaderMaterial){const $t=W.uniformsGroups;for(let Kt=0,uo=$t.length;Kt<uo;Kt++){const ui=$t[Kt];Ye.update(ui,sn),Ye.bind(ui,sn)}}return sn}function Lu(C,O){C.ambientLightColor.needsUpdate=O,C.lightProbe.needsUpdate=O,C.directionalLights.needsUpdate=O,C.directionalLightShadows.needsUpdate=O,C.pointLights.needsUpdate=O,C.pointLightShadows.needsUpdate=O,C.spotLights.needsUpdate=O,C.spotLightShadows.needsUpdate=O,C.rectAreaLights.needsUpdate=O,C.hemisphereLights.needsUpdate=O}function Du(C){return C.isMeshLambertMaterial||C.isMeshToonMaterial||C.isMeshPhongMaterial||C.isMeshStandardMaterial||C.isShadowMaterial||C.isShaderMaterial&&C.lights===!0}this.getActiveCubeFace=function(){return M},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return T},this.setRenderTargetTextures=function(C,O,G){const W=se.get(C);W.__autoAllocateDepthBuffer=C.resolveDepthBuffer===!1,W.__autoAllocateDepthBuffer===!1&&(W.__useRenderToTexture=!1),se.get(C.texture).__webglTexture=O,se.get(C.depthTexture).__webglTexture=W.__autoAllocateDepthBuffer?void 0:G,W.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(C,O){const G=se.get(C);G.__webglFramebuffer=O,G.__useDefaultFramebuffer=O===void 0};const Iu=L.createFramebuffer();this.setRenderTarget=function(C,O=0,G=0){T=C,M=O,A=G;let W=!0,F=null,le=!1,_e=!1;if(C){const we=se.get(C);if(we.__useDefaultFramebuffer!==void 0)K.bindFramebuffer(L.FRAMEBUFFER,null),W=!1;else if(we.__webglFramebuffer===void 0)fe.setupRenderTarget(C);else if(we.__hasExternalTextures)fe.rebindTextures(C,se.get(C.texture).__webglTexture,se.get(C.depthTexture).__webglTexture);else if(C.depthBuffer){const Fe=C.depthTexture;if(we.__boundDepthTexture!==Fe){if(Fe!==null&&se.has(Fe)&&(C.width!==Fe.image.width||C.height!==Fe.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");fe.setupDepthRenderbuffer(C)}}const ze=C.texture;(ze.isData3DTexture||ze.isDataArrayTexture||ze.isCompressedArrayTexture)&&(_e=!0);const He=se.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(Array.isArray(He[O])?F=He[O][G]:F=He[O],le=!0):C.samples>0&&fe.useMultisampledRTT(C)===!1?F=se.get(C).__webglMultisampledFramebuffer:Array.isArray(He)?F=He[G]:F=He,D.copy(C.viewport),I.copy(C.scissor),U=C.scissorTest}else D.copy(ge).multiplyScalar(H).floor(),I.copy(xe).multiplyScalar(H).floor(),U=Qe;if(G!==0&&(F=Iu),K.bindFramebuffer(L.FRAMEBUFFER,F)&&W&&K.drawBuffers(C,F),K.viewport(D),K.scissor(I),K.setScissorTest(U),le){const we=se.get(C.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_CUBE_MAP_POSITIVE_X+O,we.__webglTexture,G)}else if(_e){const we=O;for(let ze=0;ze<C.textures.length;ze++){const He=se.get(C.textures[ze]);L.framebufferTextureLayer(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0+ze,He.__webglTexture,G,we)}}else if(C!==null&&G!==0){const we=se.get(C.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,we.__webglTexture,G)}S=-1},this.readRenderTargetPixels=function(C,O,G,W,F,le,_e,Ce=0){if(!(C&&C.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let we=se.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&_e!==void 0&&(we=we[_e]),we){K.bindFramebuffer(L.FRAMEBUFFER,we);try{const ze=C.textures[Ce],He=ze.format,Fe=ze.type;if(!Y.textureFormatReadable(He)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Y.textureTypeReadable(Fe)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}O>=0&&O<=C.width-W&&G>=0&&G<=C.height-F&&(C.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+Ce),L.readPixels(O,G,W,F,Ue.convert(He),Ue.convert(Fe),le))}finally{const ze=T!==null?se.get(T).__webglFramebuffer:null;K.bindFramebuffer(L.FRAMEBUFFER,ze)}}},this.readRenderTargetPixelsAsync=async function(C,O,G,W,F,le,_e,Ce=0){if(!(C&&C.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let we=se.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&_e!==void 0&&(we=we[_e]),we)if(O>=0&&O<=C.width-W&&G>=0&&G<=C.height-F){K.bindFramebuffer(L.FRAMEBUFFER,we);const ze=C.textures[Ce],He=ze.format,Fe=ze.type;if(!Y.textureFormatReadable(He))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Y.textureTypeReadable(Fe))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const nt=L.createBuffer();L.bindBuffer(L.PIXEL_PACK_BUFFER,nt),L.bufferData(L.PIXEL_PACK_BUFFER,le.byteLength,L.STREAM_READ),C.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+Ce),L.readPixels(O,G,W,F,Ue.convert(He),Ue.convert(Fe),0);const pt=T!==null?se.get(T).__webglFramebuffer:null;K.bindFramebuffer(L.FRAMEBUFFER,pt);const At=L.fenceSync(L.SYNC_GPU_COMMANDS_COMPLETE,0);return L.flush(),await Vd(L,At,4),L.bindBuffer(L.PIXEL_PACK_BUFFER,nt),L.getBufferSubData(L.PIXEL_PACK_BUFFER,0,le),L.deleteBuffer(nt),L.deleteSync(At),le}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(C,O=null,G=0){const W=Math.pow(2,-G),F=Math.floor(C.image.width*W),le=Math.floor(C.image.height*W),_e=O!==null?O.x:0,Ce=O!==null?O.y:0;fe.setTexture2D(C,0),L.copyTexSubImage2D(L.TEXTURE_2D,G,0,0,_e,Ce,F,le),K.unbindTexture()};const Uu=L.createFramebuffer(),Nu=L.createFramebuffer();this.copyTextureToTexture=function(C,O,G=null,W=null,F=0,le=null){le===null&&(F!==0?($s("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),le=F,F=0):le=0);let _e,Ce,we,ze,He,Fe,nt,pt,At;const Mt=C.isCompressedTexture?C.mipmaps[le]:C.image;if(G!==null)_e=G.max.x-G.min.x,Ce=G.max.y-G.min.y,we=G.isBox3?G.max.z-G.min.z:1,ze=G.min.x,He=G.min.y,Fe=G.isBox3?G.min.z:0;else{const un=Math.pow(2,-F);_e=Math.floor(Mt.width*un),Ce=Math.floor(Mt.height*un),C.isDataArrayTexture?we=Mt.depth:C.isData3DTexture?we=Math.floor(Mt.depth*un):we=1,ze=0,He=0,Fe=0}W!==null?(nt=W.x,pt=W.y,At=W.z):(nt=0,pt=0,At=0);const vt=Ue.convert(O.format),Be=Ue.convert(O.type);let St;O.isData3DTexture?(fe.setTexture3D(O,0),St=L.TEXTURE_3D):O.isDataArrayTexture||O.isCompressedArrayTexture?(fe.setTexture2DArray(O,0),St=L.TEXTURE_2D_ARRAY):(fe.setTexture2D(O,0),St=L.TEXTURE_2D),L.pixelStorei(L.UNPACK_FLIP_Y_WEBGL,O.flipY),L.pixelStorei(L.UNPACK_PREMULTIPLY_ALPHA_WEBGL,O.premultiplyAlpha),L.pixelStorei(L.UNPACK_ALIGNMENT,O.unpackAlignment);const lt=L.getParameter(L.UNPACK_ROW_LENGTH),sn=L.getParameter(L.UNPACK_IMAGE_HEIGHT),Pi=L.getParameter(L.UNPACK_SKIP_PIXELS),rn=L.getParameter(L.UNPACK_SKIP_ROWS),_s=L.getParameter(L.UNPACK_SKIP_IMAGES);L.pixelStorei(L.UNPACK_ROW_LENGTH,Mt.width),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,Mt.height),L.pixelStorei(L.UNPACK_SKIP_PIXELS,ze),L.pixelStorei(L.UNPACK_SKIP_ROWS,He),L.pixelStorei(L.UNPACK_SKIP_IMAGES,Fe);const bt=C.isDataArrayTexture||C.isData3DTexture,hn=O.isDataArrayTexture||O.isData3DTexture;if(C.isDepthTexture){const un=se.get(C),$t=se.get(O),Kt=se.get(un.__renderTarget),uo=se.get($t.__renderTarget);K.bindFramebuffer(L.READ_FRAMEBUFFER,Kt.__webglFramebuffer),K.bindFramebuffer(L.DRAW_FRAMEBUFFER,uo.__webglFramebuffer);for(let ui=0;ui<we;ui++)bt&&(L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,se.get(C).__webglTexture,F,Fe+ui),L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,se.get(O).__webglTexture,le,At+ui)),L.blitFramebuffer(ze,He,_e,Ce,nt,pt,_e,Ce,L.DEPTH_BUFFER_BIT,L.NEAREST);K.bindFramebuffer(L.READ_FRAMEBUFFER,null),K.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else if(F!==0||C.isRenderTargetTexture||se.has(C)){const un=se.get(C),$t=se.get(O);K.bindFramebuffer(L.READ_FRAMEBUFFER,Uu),K.bindFramebuffer(L.DRAW_FRAMEBUFFER,Nu);for(let Kt=0;Kt<we;Kt++)bt?L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,un.__webglTexture,F,Fe+Kt):L.framebufferTexture2D(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,un.__webglTexture,F),hn?L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,$t.__webglTexture,le,At+Kt):L.framebufferTexture2D(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,$t.__webglTexture,le),F!==0?L.blitFramebuffer(ze,He,_e,Ce,nt,pt,_e,Ce,L.COLOR_BUFFER_BIT,L.NEAREST):hn?L.copyTexSubImage3D(St,le,nt,pt,At+Kt,ze,He,_e,Ce):L.copyTexSubImage2D(St,le,nt,pt,ze,He,_e,Ce);K.bindFramebuffer(L.READ_FRAMEBUFFER,null),K.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else hn?C.isDataTexture||C.isData3DTexture?L.texSubImage3D(St,le,nt,pt,At,_e,Ce,we,vt,Be,Mt.data):O.isCompressedArrayTexture?L.compressedTexSubImage3D(St,le,nt,pt,At,_e,Ce,we,vt,Mt.data):L.texSubImage3D(St,le,nt,pt,At,_e,Ce,we,vt,Be,Mt):C.isDataTexture?L.texSubImage2D(L.TEXTURE_2D,le,nt,pt,_e,Ce,vt,Be,Mt.data):C.isCompressedTexture?L.compressedTexSubImage2D(L.TEXTURE_2D,le,nt,pt,Mt.width,Mt.height,vt,Mt.data):L.texSubImage2D(L.TEXTURE_2D,le,nt,pt,_e,Ce,vt,Be,Mt);L.pixelStorei(L.UNPACK_ROW_LENGTH,lt),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,sn),L.pixelStorei(L.UNPACK_SKIP_PIXELS,Pi),L.pixelStorei(L.UNPACK_SKIP_ROWS,rn),L.pixelStorei(L.UNPACK_SKIP_IMAGES,_s),le===0&&O.generateMipmaps&&L.generateMipmap(St),K.unbindTexture()},this.initRenderTarget=function(C){se.get(C).__webglFramebuffer===void 0&&fe.setupRenderTarget(C)},this.initTexture=function(C){C.isCubeTexture?fe.setTextureCube(C,0):C.isData3DTexture?fe.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?fe.setTexture2DArray(C,0):fe.setTexture2D(C,0),K.unbindTexture()},this.resetState=function(){M=0,A=0,T=null,K.reset(),ve.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Ln}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=ht._getDrawingBufferColorSpace(e),t.unpackColorSpace=ht._getUnpackColorSpace()}}const Ze=6371,ke=Math.PI/180;function $n(i,e){const t=i*ke,n=e*ke,s=new P(Math.cos(t)*Math.sin(n),Math.sin(t),Math.cos(t)*Math.cos(n)),r=new P(Math.cos(n),0,-Math.sin(n));return{up:s,east:r,north:s.clone().cross(r)}}function Ke(i,e,t=0){const n=i*ke,s=e*ke,r=Ze+t,o=r*Math.cos(n);return new P(o*Math.sin(s),r*Math.sin(n),o*Math.cos(s))}const ct=(i,e,t)=>Math.max(e,Math.min(t,i));function ns(i,e){return((e-i)%360+540)%360-180}function tt(i){const e=ct(i,0,1);return e*e*(3-2*e)}const Js=new Map(Fu.map(i=>[i.id,i])),Ds=Js.values().next().value,el={island:{id:"island",name:"Island · Reykjanes",stepId:4209,regionalDistance:1e3},japan:{id:"japan",name:"Japan · Tōhoku",stepId:2629,regionalDistance:1200},san:{id:"san",name:"Kalifornien · San Andreas",stepId:2877,regionalDistance:950}},si={id:"nyos",name:"Nyos-See · Kamerun",target:{lat:6.4384,lon:10.2986,d:3.27,tilt:42,bearing:26},overview:{d:15,tilt:34,bearing:4}},Kv=[si,...Array.from(Js.values(),({id:i,name:e})=>({id:i,name:e})),...Object.values(el)];class Zv{constructor(e){this.region=e,this.xScale=this.zScale*Math.cos(e.target.lat*ke)}xScale;zScale=Ze*ke;project=([e,t])=>[(e-this.region.target.lon)*this.xScale,(this.region.target.lat-t)*this.zScale];contains(e,t){const[n,s,r,o]=this.region.bounds;return t>=n&&t<=r&&e>=s&&e<=o}}function Jv(i,e){for(const{bounds:[t,n,s,r]}of Js.values()){const o=Math.max(Math.abs(2*e-t-s)/(s-t),Math.abs(2*i-r-n)/(r-n));if(o<2)return tt(o-1)}return 1}function Qv(i,e,t){const n=ct(e,0,1)*(i.width-1),s=ct(t,0,1)*(i.height-1),r=Math.min(i.width-2,Math.floor(n)),o=Math.min(i.height-2,Math.floor(s)),a=i.meters;return((1-s+o)*((1-n+r)*a[o*i.width+r]+(n-r)*a[o*i.width+r+1])+(s-o)*((1-n+r)*a[(o+1)*i.width+r]+(n-r)*a[(o+1)*i.width+r+1]))*.001}const du=(i,e,t=[])=>{const n=document.createElementNS("http://www.w3.org/2000/svg",i);return Object.keys(e).forEach(s=>{n.setAttribute(s,String(e[s]))}),t.length&&t.forEach(s=>{const r=du(...s);n.appendChild(r)}),n};var e_=([i,e,t])=>du(i,e,t);const t_=i=>Array.from(i.attributes).reduce((e,t)=>(e[t.name]=t.value,e),{}),n_=i=>typeof i=="string"?i:!i||!i.class?"":i.class&&typeof i.class=="string"?i.class.split(" "):i.class&&Array.isArray(i.class)?i.class:"",i_=i=>i.flatMap(n_).map(t=>t.trim()).filter(Boolean).filter((t,n,s)=>s.indexOf(t)===n).join(" "),s_=i=>i.replace(/(\w)(\w*)(_|-|\s*)/g,(e,t,n)=>t.toUpperCase()+n.toLowerCase()),oh=(i,{nameAttr:e,icons:t,attrs:n})=>{const s=i.getAttribute(e);if(s==null)return;const r=s_(s),o=t[r];if(!o)return console.warn(`${i.outerHTML} icon name was not found in the provided icons object.`);const a=t_(i),[l,c,h]=o,u={...c,"data-lucide":s,...n,...a},d=i_(["lucide",`lucide-${s}`,a,n]);d&&Object.assign(u,{class:d});const f=e_([l,u,h]);return i.parentNode?.replaceChild(f,i)};const kt={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};const r_=["svg",kt,[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z"}],["circle",{cx:"12",cy:"12",r:"10"}]]];const o_=["svg",kt,[["path",{d:"M21.54 15H17a2 2 0 0 0-2 2v4.54"}],["path",{d:"M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17"}],["path",{d:"M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05"}],["circle",{cx:"12",cy:"12",r:"10"}]]];const a_=["svg",kt,[["path",{d:"M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"}],["path",{d:"M14.084 14.158a3 3 0 0 1-4.242-4.242"}],["path",{d:"M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"}],["path",{d:"m2 2 20 20"}]]];const l_=["svg",kt,[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"}],["circle",{cx:"12",cy:"12",r:"3"}]]];const c_=["svg",kt,[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M12 16v-4"}],["path",{d:"M12 8h.01"}]]];const h_=["svg",kt,[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17"}]]];const u_=["svg",kt,[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"}],["circle",{cx:"12",cy:"10",r:"3"}]]];const d_=["svg",kt,[["path",{d:"M8 3H5a2 2 0 0 0-2 2v3"}],["path",{d:"M21 8V5a2 2 0 0 0-2-2h-3"}],["path",{d:"M3 16v3a2 2 0 0 0 2 2h3"}],["path",{d:"M16 21h3a2 2 0 0 0 2-2v-3"}]]];const f_=["svg",kt,[["path",{d:"M8 3v3a2 2 0 0 1-2 2H3"}],["path",{d:"M21 8h-3a2 2 0 0 1-2-2V3"}],["path",{d:"M3 16h3a2 2 0 0 1 2 2v3"}],["path",{d:"M16 21v-3a2 2 0 0 1 2-2h3"}]]];const p_=["svg",kt,[["path",{d:"M5 12h14"}]]];const m_=["svg",kt,[["polygon",{points:"12 2 19 21 12 17 5 21 12 2"}]]];const g_=["svg",kt,[["circle",{cx:"12",cy:"12",r:"3"}],["circle",{cx:"19",cy:"5",r:"2"}],["circle",{cx:"5",cy:"19",r:"2"}],["path",{d:"M10.4 21.9a10 10 0 0 0 9.941-15.416"}],["path",{d:"M13.5 2.1a10 10 0 0 0-9.841 15.416"}]]];const v_=["svg",kt,[["path",{d:"M5 12h14"}],["path",{d:"M12 5v14"}]]];const __=["svg",kt,[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"}],["path",{d:"M3 3v5h5"}]]];const x_=["svg",kt,[["path",{d:"M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"}],["path",{d:"M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"}],["path",{d:"M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"}]]];const y_=["svg",kt,[["circle",{cx:"12",cy:"4.5",r:"2.5"}],["path",{d:"m10.2 6.3-3.9 3.9"}],["circle",{cx:"4.5",cy:"12",r:"2.5"}],["path",{d:"M7 12h10"}],["circle",{cx:"19.5",cy:"12",r:"2.5"}],["path",{d:"m13.8 17.7 3.9-3.9"}],["circle",{cx:"12",cy:"19.5",r:"2.5"}]]];const M_=["svg",kt,[["path",{d:"M18 6 6 18"}],["path",{d:"m6 6 12 12"}]]];const S_=({icons:i={},nameAttr:e="data-lucide",attrs:t={}}={})=>{if(!Object.values(i).length)throw new Error(`Please provide an icons object.
If you want to use all the icons you can import it like:
 \`import { createIcons, icons } from 'lucide';
lucide.createIcons({icons});\``);if(typeof document>"u")throw new Error("`createIcons()` only works in a browser environment.");const n=document.querySelectorAll(`[${e}]`);if(Array.from(n).forEach(s=>oh(s,{nameAttr:e,icons:i,attrs:t})),e==="data-lucide"){const s=document.querySelectorAll("[icon-name]");s.length>0&&(console.warn("[Lucide] Some icons were found with the now deprecated icon-name attribute. These will still be replaced for backwards compatibility, but will no longer be supported in v1.0 and you should switch to data-lucide"),Array.from(s).forEach(r=>oh(r,{nameAttr:"icon-name",icons:i,attrs:t})))}},ri={lat:18,lon:19,d:14450,tilt:0,bearing:0},ii=(i,e,t)=>i+(e-i)*t;class b_{constructor(e){this.canvas=e,e.addEventListener("wheel",t=>{t.preventDefault(),this.zoom(Math.exp(ct(t.deltaY*(t.deltaMode===1?.025:.0015),-1,1)))},{passive:!1}),e.oncontextmenu=t=>t.preventDefault(),e.onpointerdown=t=>{this.stop(),e.setPointerCapture(t.pointerId),this.pointers.set(t.pointerId,{x:t.clientX,y:t.clientY}),this.drag=0},e.onpointermove=t=>{const n=this.pointers.get(t.pointerId);if(!n)return;const s=[...this.pointers].find(([c])=>c!==t.pointerId)?.[1],r=t.clientX,o=t.clientY,a=r-n.x,l=o-n.y;if(this.drag+=Math.hypot(a,l),s){const c=Math.hypot(s.x-n.x,s.y-n.y),h=Math.hypot(s.x-r,s.y-o);c>5&&h>5&&this.zoom(c/h),this.goal.tilt=ct(this.goal.tilt+l*.18,0,75)}else t.shiftKey||t.buttons===2?(this.goal.bearing-=a*.3,this.goal.tilt=ct(this.goal.tilt+l*.22,0,75)):this.pan(a,l);this.pointers.set(t.pointerId,{x:r,y:o})},e.onpointerup=t=>{this.drag<4&&this.pointers.size===1&&this.onPick?.(t.clientX,t.clientY),this.pointers.delete(t.pointerId)},e.onpointercancel=t=>this.pointers.delete(t.pointerId)}camera=new fn(39,1,.01,6e4);reducedMotion=matchMedia("(prefers-reduced-motion: reduce)");pose={...ri};goal={...ri};orbit=!1;minimumDistance=.06;orbitMinimum=38;inputRevision=0;flight;pointers=new Map;drag=0;onPick;stop(){this.inputRevision++,this.flight&&(this.goal={...this.pose},this.flight=void 0)}zoom(e){this.stop(),this.goal.d=ct(this.goal.d*e,this.orbit?this.orbitMinimum:this.minimumDistance,35e3)}pan(e,t){if(this.stop(),this.orbit){this.goal.bearing-=e*.32,this.goal.tilt=ct(this.goal.tilt+t*.25,8,75);return}const n=Math.min(1.8,this.goal.d/Ze)*52/this.canvas.clientHeight,s=this.goal.bearing*ke;this.goal.lon-=(e*Math.cos(s)+t*Math.sin(s))*n/Math.max(.09,Math.cos(this.goal.lat*ke)),this.goal.lat=ct(this.goal.lat+(t*Math.cos(s)-e*Math.sin(s))*n,-89.7,89.7)}fly(e,t=!1,n=950){const s=this.pose,r=Ze*Math.acos(ct($n(s.lat,s.lon).up.dot($n(e.lat,e.lon).up),-1,1)),o=r>10&&Math.max(s.d,e.d)<r/3?Math.min(r*.8,10500):0,a=performance.now();this.flight={cruise:o,paced:t,elapsed:0,last:a,from:{...this.pose},to:{...e},start:a,ms:this.reducedMotion.matches?0:ct(Math.max(Math.abs(Math.log(s.d/e.d))*590,o*.55),n,6400)}}update(e,t,n,s,r=!1){if(this.flight){const{from:_,to:m,start:p,ms:y,cruise:x}=this.flight;r||(this.flight.elapsed+=ct(e-this.flight.last,0,125)),this.flight.last=e;const v=this.flight.paced?this.flight.elapsed:e-p,w=y?ct(v/y,0,1):1,M=tt(w),A=m.d<_.d?tt(ct(w/.44,0,1)):tt(ct((w-.56)/.44,0,1));if(this.pose={lat:ii(_.lat,m.lat,A),lon:_.lon+ns(_.lon,m.lon)*A,d:Math.exp(ii(Math.log(_.d),Math.log(m.d),M)),tilt:ii(_.tilt,m.tilt,M),bearing:_.bearing+ns(_.bearing,m.bearing)*M},x){this.pose.d=w<.5?Math.exp(ii(Math.log(_.d),Math.log(x),tt(2*w))):Math.exp(ii(Math.log(x),Math.log(m.d),tt(2*w-1)));const T=tt(ct((w-.16)/.68,0,1));this.pose.lat=ii(_.lat,m.lat,T),this.pose.lon=_.lon+ns(_.lon,m.lon)*T}this.goal={...this.pose},w===1&&(this.flight=void 0)}else{const _=1-Math.exp(-t*12);for(const m of["lat","lon","tilt","bearing"])this.pose[m]=ii(this.pose[m],this.goal[m],_);this.pose.d=Math.exp(ii(Math.log(this.pose.d),Math.log(this.goal.d),_))}const{lat:o,lon:a,d:l,tilt:c,bearing:h}=this.pose,u=$n(o,a),d=c*ke,f=u.north.clone().multiplyScalar(-Math.cos(h*ke)).addScaledVector(u.east,Math.sin(h*ke)),g=u.up.clone().multiplyScalar(Ze+n(this.pose));if(this.camera.position.copy(g).addScaledVector(u.up,l*Math.cos(d)).addScaledVector(f,l*Math.sin(d)),s){const _=this.camera.position,m=_.length(),p=s(Math.asin(_.y/m)/ke,Math.atan2(_.x,_.z)/ke);p!==null&&m<Ze+p+.045&&_.multiplyScalar((Ze+p+.045)/m)}this.camera.up.copy(u.up).multiplyScalar(Math.sin(d)).addScaledVector(f,-Math.cos(d)),this.camera.lookAt(g),this.camera.near=Math.max(8e-5,l*.001),this.camera.far=l+2.2*Ze,this.camera.updateProjectionMatrix(),this.camera.updateMatrixWorld()}}const eo={A:{name:"Realistisch",segments:24,sun:2.05,sky:1.55},B:{name:"Soft-Low-Poly",segments:12,sun:2.45,sky:1.4}},Qt=[{name:"Erdkruste",material:"Die Erdkruste besteht aus festem Gestein. Unter Ozeanen ist es meist dichter als unter Kontinenten.",origin:"Neue Kruste bildet sich, wenn Gesteinsschmelze abkühlt. Ältere Kruste verändert sich, etwa wenn Platten zusammenstoßen.",outer:6371,inner:6336,color:9215878,text:"Die dünne Außenschicht der Erde. Sie besteht aus festem Gestein."},{name:"Erdmantel",material:"Der Mantel besteht größtenteils aus heißem, festem Gestein. Über sehr lange Zeit kann es sich langsam verformen.",origin:"In der jungen Erde trennten sich schweres Metall und Gestein. Das Metall sank zum Kern. Der größte Teil des Gesteins bildete den Mantel.",outer:6336,inner:3481,color:12482128,text:"Er besteht überwiegend aus festem Gestein. Dieses kann sich über sehr lange Zeit langsam verformen."},{name:"Äußerer Erdkern",material:"Er besteht hauptsächlich aus flüssigem Eisen. Es enthält auch Nickel und leichtere Stoffe.",origin:"Als die junge Erde sehr heiß war, sank schweres Metall nach innen. Der äußere Teil des Kerns ist bis heute flüssig.",outer:3481,inner:1221,color:15314533,text:"Er besteht hauptsächlich aus flüssigem Metall."},{name:"Innerer Erdkern",material:"Er besteht hauptsächlich aus festem Eisen. Der hohe Druck hält es trotz der großen Hitze fest.",origin:"Als die Erde langsam abkühlte, begann Metall in ihrem Zentrum zu erstarren. Daraus wuchs der innere Erdkern.",outer:1221,inner:0,color:16767895,text:"Er besteht hauptsächlich aus festem Metall."}],Il=i=>os("data/"+i);async function yn(i){const e=await new oo().loadAsync(Il(i));return e.colorSpace=Wt,e.anisotropy=4,e}class w_{constructor(e){this.warn=e}group=new rt;uploadedTiles=new Set;cache=new Map;tick=0;stamp="";style="A";heightData;maps={};material=new mn({vertexColors:!0});light={value:new P(0,1,1).normalize()};mapWeights={value:new P};nyos={far:{value:null},mid:{value:null},farBounds:{value:new at(0,0,1,1)},midBounds:{value:new at(0,0,1,1)},bounds:{value:new at(0,0,1,1)},weights:{value:new P}};setNyosMaps(e,t,n,s,r){const o=(a,l)=>a.set(l[0],l[1],l[2]-l[0],l[3]-l[1]);o(this.nyos.bounds.value,e),t&&o(this.nyos.farBounds.value,t),s&&o(this.nyos.midBounds.value,s),this.nyos.far.value=n??this.baseline??null,this.nyos.mid.value=r??this.baseline??null}setNyosWeights(e,t,n){this.nyos.weights.value.set(e,t,n)}midMaps=[];regionalAtlas;regionalSampler={value:void 0};deadline=0;incomplete=!1;alternate=new Map;lightDirection(e){this.light.value.copy(e)}baseline;async init(){this.baseline=await yn("earth-base.webp"),this.material.map=this.baseline;const[e,t,n,s,r,o,a]=await Promise.allSettled([yn("earth.webp"),yn("earth-atlas.webp"),yn("north-europe.webp"),fetch(Il("relief.i16")).then(async l=>{if(!l.ok)throw Error();const c=new Int16Array(await l.arrayBuffer());if(c.length!==721*361)throw Error();return c}),yn("northsea-cover.webp"),yn("wadden-air.webp"),yn("north-europe-atlas.webp")]);e.status==="fulfilled"&&(this.maps.A=e.value),t.status==="fulfilled"&&(this.maps.B=t.value),s.status==="fulfilled"&&(this.heightData=s.value),[e,t,n,s].some(l=>l.status==="rejected")&&this.warn("Vereinfachte Weltkarte · Detaildaten fehlen"),this.midMaps=[n,r,o].map(l=>l.status==="fulfilled"?l.value:void 0),(r.status==="rejected"||o.status==="rejected")&&this.warn("Regionale Detailkarte fehlt · verfügbare Auflösungen aktiv"),this.regionalAtlas=a.status==="fulfilled"?a.value:void 0,this.material.onBeforeCompile=l=>{l.uniforms.sunUnit=this.light,l.uniforms.weights=this.mapWeights,Object.assign(l.uniforms,{nyosFar:this.nyos.far,nyosMid:this.nyos.mid,nyosFarBounds:this.nyos.farBounds,nyosMidBounds:this.nyos.midBounds,nyosBounds:this.nyos.bounds,nyosWeights:this.nyos.weights}),this.midMaps.forEach((c,h)=>l.uniforms["layer"+h]={value:c??this.baseline}),l.uniforms.layer0=this.regionalSampler,l.vertexShader=`uniform vec3 sunUnit;varying float earthLight;uniform vec3 nyosWeights;uniform vec4 nyosBounds;
`+l.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
 earthLight=.36+1.05*max(0.,dot(normalize(normal),sunUnit))+.10*normal.y;`).replace("#include <project_vertex>",`
          #include <project_vertex>
          if(nyosWeights.z>0.0) {
            vec2 p=(uv*vec2(360.,180.)-vec2(180.,90.)-nyosBounds.xy)/nyosBounds.zw;
            float margin=min(min(p.x,1.-p.x),min(p.y,1.-p.y));
            float footprint=smoothstep(-0.7,-0.15,margin);
            // Keep a continuous, opaque map beneath the DEM, including its feathered rim.
            // Change depth alone, preserving the geographic position of every background pixel.
            gl_Position.z += max(0.,gl_Position.w-gl_Position.z)*.96*nyosWeights.z*footprint;
          }`),l.fragmentShader=`
        varying float earthLight;uniform vec3 weights;uniform sampler2D layer0,layer1,layer2;
        uniform vec3 nyosWeights;uniform vec4 nyosFarBounds,nyosMidBounds,nyosBounds;
        uniform sampler2D nyosFar,nyosMid;
        vec4 sampleLayer(sampler2D img,vec2 ll,vec4 rect,float weight){
          vec2 uv=(ll-rect.xy)/rect.zw;float edge=min(min(uv.x,uv.y),min(1.-uv.x,1.-uv.y));
          if(edge<=0.||weight<=0.)return vec4(0.);
          vec4 c=texture2D(img,uv);return vec4(c.rgb,c.a*weight*smoothstep(0.,.1,edge));}
        `+l.fragmentShader.replace("#include <map_fragment>",`
          vec2 ll=vMapUv*vec2(360.,180.)-vec2(180.,90.);
          vec4 local=sampleLayer(layer2,ll,vec4(8.26,54.42,.62,.38),weights.z);
          vec4 cover=sampleLayer(layer1,ll,vec4(7.55,54.01,1.44,1.09),weights.y);
          vec3 earth=cover.rgb;
          if(cover.a<.9999){
            vec4 region=sampleLayer(layer0,ll,vec4(4.,51.,9.,8.),weights.x);
            earth=region.rgb;
            if(region.a<.9999)earth=mix(texture2D(map,vMapUv).rgb,region.rgb,region.a);
            earth=mix(earth,cover.rgb,cover.a);
          }
          if(nyosWeights.x>0.0) {
            vec4 farRegion=sampleLayer(nyosFar,ll,nyosFarBounds,nyosWeights.x);
            earth=mix(earth,farRegion.rgb,farRegion.a);
          }
          if(nyosWeights.y>0.0) {
            vec4 nearRegion=sampleLayer(nyosMid,ll,nyosMidBounds,nyosWeights.y);
            earth=mix(earth,nearRegion.rgb,nearRegion.a);
          }
          diffuseColor.rgb*=mix(earth,local.rgb,local.a);
          diffuseColor.rgb*=earthLight;`)},this.setStyle(this.style)}elevation(e,t){if(!this.heightData)return 0;const n=((t+180)%360+360)%360*2,s=ct((90-e)*2,0,359.999),r=Math.floor(n),o=Math.floor(s),a=n-r,l=s-o,c=this.heightData,h=(1-l)*((1-a)*c[o*721+r]+a*c[o*721+r+1])+l*((1-a)*c[(o+1)*721+r]+a*c[(o+1)*721+r+1]);return Math.max(0,h*.001)*Jv(e,t)}setStyle(e){if(this.style!==e){for(const{mesh:t}of this.cache.values())t.visible=!1;[this.cache,this.alternate]=[this.alternate,this.cache]}this.regionalSampler.value=(e==="B"?this.regionalAtlas:void 0)??this.midMaps[0]??this.baseline,this.style=e,this.material.map=this.maps[e]??this.baseline??null,this.material.needsUpdate=!0,this.stamp=""}tile(e,t,n){const s=[e,t,n].join("/");let r=this.cache.get(s);if(r){r.used=this.tick,r.mesh.visible=!0;return}const o=45/2**e,a=-180+t*o,l=-90+n*o,c=e<3?eo[this.style].segments:Math.max(6,eo[this.style].segments/3),h=Ke(l+o/2,a+o/2),u=[],d=[],f=[],g=[],_=[];for(let M=0;M<=c;M++)for(let A=0;A<=c;A++){const T=l+o*M/c,S=a+o*A/c,b=Ke(T,S,this.elevation(T,S)),D=b.clone().normalize();u.push(...b.sub(h).toArray()),f.push(D.x,D.y,D.z),d.push((S+180)/360,(T+90)/180)}for(let M=0;M<c;M++)for(let A=0;A<c;A++){const T=M*(c+1)+A,S=T+c+1;_.push(T,T+1,S,T+1,S+1,S)}const m=[...Array(c).keys()],p=[...m,...m.map(M=>M*(c+1)+c),...m.map(M=>c*(c+1)+c-M),...m.map(M=>(c-M)*(c+1))],y=Ze*(1-Math.cos(o*ke/c))+.003,x=u.length/3;p.forEach((M,A)=>{for(let S=0;S<3;S++)u.push(u[3*M+S]-f[3*M+S]*y),f.push(f[M*3+S]);d.push(d[2*M],d[2*M+1]);const T=(A+1)%p.length;_.push(M,x+A,p[T],p[T],x+A,x+T)});let v=new it;if(v.setAttribute("position",new Me(u,3)),v.setAttribute("normal",new Me(f,3)),v.setAttribute("uv",new Me(d,2)),v.setIndex(_),this.style==="B"){const M=v;v=v.toNonIndexed(),M.dispose();for(let A=0;A<v.attributes.position.count/3;A++){const T=.94+.12*(.5+.5*Math.sin(A*79.7+t*53+n*2));for(let S=0;S<3;S++)g.push(T,T,T)}}else for(let M=0;M<u.length/3;M++)g.push(1,1,1);v.setAttribute("color",new Me(g,3)),v.getAttribute("position").onUpload(()=>this.uploadedTiles.add(v));const w=new Ne(v,this.material);w.position.copy(h),this.group.add(w),this.cache.set(s,{mesh:w,used:this.tick})}update(e,t,n){t=((t+180)%360+360)%360-180,this.mapWeights.value.set(this.midMaps[0]?1-tt((n-240)/1200):0,this.midMaps[1]?1-tt((n-65)/380):0,this.midMaps[2]?(this.style==="A"?.95:.38)*(1-tt((n-12)/100)):0);const s=ct(Math.ceil(Math.log2(1300/n)),0,10),r=45/2**s/4,o=[s,Math.floor(t/r),Math.floor(e/r)].join(":");if(o===this.stamp&&!this.incomplete)return;this.incomplete=!1,this.deadline=performance.now()+3,this.stamp=o,this.tick++;for(const u of this.cache.values())u.mesh.visible=!1;const a=Math.acos(Ze/(Ze+Math.max(n,1300/2**Math.max(0,s-1))))+Math.acos(Ze/(Ze+9))+Math.asin(Math.min(1,n/Ze))+r*ke*2,l=Math.sin(e*ke),c=Math.cos(e*ke),h=(u,d,f)=>{const g=45/2**u,_=Math.abs(ns(-180+(d+.5)*g,t)),m=Math.abs(e-(-90+(f+.5)*g)),p=a+g*ke,y=(-90+(f+.5)*g)*ke;if(!(p<Math.PI&&l*Math.sin(y)+c*Math.cos(y)*Math.cos(_*ke)<Math.cos(p)))if(u<s&&_<1.05*g&&m<1.05*g){for(let x=0;x<2;x++)for(let v=0;v<2;v++){const w=[u+1,2*d+v,2*f+x].join("/"),M=this.cache.get(w);if(M){M.used=this.tick;continue}if(performance.now()>this.deadline){this.incomplete=!0,this.tile(u,d,f);return}this.tile(u+1,2*d+v,2*f+x),this.cache.get(w).mesh.visible=!1}for(let x=0;x<2;x++)for(let v=0;v<2;v++)h(u+1,2*d+v,2*f+x)}else this.tile(u,d,f)};for(let u=0;u<4;u++)for(let d=0;d<8;d++)h(0,d,u);for(const[u,d]of this.cache)this.cache.size>260&&d.used<this.tick-2&&!u.startsWith("0/")&&(this.group.remove(d.mesh),this.uploadedTiles.delete(d.mesh.geometry),d.mesh.geometry.dispose(),this.cache.delete(u))}get cachedTileCount(){return this.cache.size+this.alternate.size}get tileCount(){return this.cache.size}}function ah(i,e,t){let n=!1;for(let s=0,r=t.length-1;s<t.length;r=s++){const[o,a]=t[s],[l,c]=t[r];a>e!=c>e&&i<(l-o)*(e-a)/(c-a)+o&&(n=!n)}return n}const jo=(i,e)=>(i*i+e*e)/(2*Ze);class E_{constructor(e){this.region=e;const{lat:t,lon:n}=e.target,s=Ke(t,n),r=$n(t,n);this.frame=new Zv(e),this.group.position.copy(s),this.group.quaternion.setFromRotationMatrix(new st().makeBasis(r.east,r.up,r.north.clone().negate())),this.group.visible=!1}group=new rt;ready=!1;warning="";loading;data;map;ortho;detail;soft;mounds=[];coast=[];style="A";surface;buildings=new rt;time={value:0};weight={value:0};frame;grid;terrain;variants=new Map;load(){return this.loading??=this.fetchData().catch(()=>{this.warning=(this.region.id==="hooge"?"Hallig":this.region.name)+"-Detaildaten fehlen · regionale Küstenkarte aktiv"})}async fetchData(){const e=this.region,t=async l=>{const c=await fetch(Il(l));if(!c.ok)throw Error("Kartendatei fehlt: "+l);return c},[n,s,r,o]=await Promise.all([e.features?t(e.features).then(l=>l.json()):Promise.resolve({bounds:e.bounds,coast:[],mounds:[],buildings:[]}),yn(e.maps.base),t(e.mesh).then(l=>l.arrayBuffer()),e.height.kind==="dsm"?t(e.height.file).then(l=>l.json()):void 0]);this.data=n,this.map=s,this.grid=o,this.coast=n.coast.map(this.frame.project),this.mounds=n.mounds.map(l=>this.frame.project(l.point));const a=await Promise.allSettled([e.maps.A===e.maps.base?s:yn(e.maps.A),e.maps.B===e.maps.base?s:yn(e.maps.B),e.maps.detail?yn(e.maps.detail):void 0]);a[0].status==="fulfilled"&&(this.ortho=a[0].value),a[1].status==="fulfilled"&&(this.soft=a[1].value),a[2].status==="fulfilled"&&(this.detail=a[2].value),a.some(l=>l.status==="rejected")&&(this.warning="Luftbild unvollständig · lokale Ersatzkarte aktiv"),this.terrain=this.unpackTerrain(r),this.ready=!0,this.rebuild()}unpackTerrain(e){if(e.byteLength<8)throw Error("Geländedatei unvollständig");const[t,n]=new Uint32Array(e,0,2);if(t>65535||!t||!n||n%3||8+t*16+n*2!==e.byteLength)throw Error("Geländenetz ungültig");const s=new Float32Array(e,8,t*4),r=new Uint16Array(e,8+t*16,n),[o,a,l,c]=this.region.bounds,[h,u]=this.frame.project([o,c]),[d,f]=this.frame.project([l,a]);if(!s.every(Number.isFinite)||r.some(v=>v>=t))throw Error("Ungültige Geländekoordinaten");const g=new Float32Array(t*3),_=new Float32Array(t*2),m=new Float32Array(t);for(let v=0;v<t;v++){const w=s[v*4],M=s[v*4+1],A=h+(d-h)*w,T=u+(f-u)*M;g.set([A,s[v*4+2]+.0012-jo(A,T),T],v*3),_.set([w,1-M],v*2),m[v]=s[v*4+3]}const p=new it;p.setAttribute("position",new zt(g,3)),p.setAttribute("uv",new zt(_,2)),p.setAttribute("land",new zt(m,1));const y=[],x=[];for(let v=0;v<n;v+=3){const w=r[v],M=r[v+1],A=r[v+2];if(m[w]<=-1&&m[M]<=-1&&m[A]<=-1)continue;([w,M,A].every(S=>m[S]>=0&&Math.min(_[2*S],1-_[2*S],_[2*S+1],1-_[2*S+1])>.12)?y:x).push(w,M,A)}return p.setIndex(new zt(new Uint16Array(y.concat(x)),1)),p.addGroup(0,y.length,0),p.addGroup(y.length,x.length,1),p.computeVertexNormals(),p.computeBoundingSphere(),p}height(e,t,n=!0){const s=this.region.height;if(s.kind!=="mounds")return 0;let r=n?s.baseM*.001:0;if(n)for(const[o,a]of this.mounds){if(Math.abs(e-o)>s.radiusKm[0]*1.48||Math.abs(t-a)>s.radiusKm[1]*1.48)continue;const l=Math.hypot((e-o)/s.radiusKm[0],(t-a)/s.radiusKm[1]);l<1.48&&(r+=s.riseM*.001*(1-tt(l-.48)))}return r+.0012-jo(e,t)}ground(e,t){if(!this.ready||!this.frame.contains(e,t))return 0;const[n,s,r,o]=this.region.bounds;if(this.grid)return Qv(this.grid,(t-n)/(r-n),(o-e)/(o-s))+.0012;const[a,l]=this.frame.project([t,e]);return this.height(a,l,ah(a,l,this.coast))+jo(a,l)}setStyle(e){this.style!==e&&(this.style=e,this.ready&&this.rebuild())}rebuild(){if(!this.data||!this.terrain||!this.map)return;for(const[x,v]of this.variants)v.visible=x===this.style;const e=this.variants.get(this.style);if(e){this.surface=e.children[0],this.buildings=e.children[1];return}const t=new rt;this.variants.set(this.style,t),this.group.add(t);const n=this.terrain;this.buildings=new rt;const s=new Ps({map:(this.style==="A"?this.ortho:this.soft)??this.map,flatShading:this.style==="B",transparent:!0,depthWrite:!1}),r=this.style==="A";s.onBeforeCompile=x=>{const v=this.region.maps.detailBounds??this.region.bounds,[w,M]=this.frame.project([v[0],v[3]]),[A,T]=this.frame.project([v[2],v[1]]);x.uniforms.detailRect={value:new at(w,M,A-w,T-M)},x.uniforms.detailMap={value:this.detail??this.map},x.uniforms.detailWeight={value:this.detail&&r?.9:0},x.uniforms.tideTime=this.time,x.uniforms.lodWeight=this.weight,x.vertexShader=`attribute float land;varying float dry;varying vec2 site;
`+x.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
 dry=land;site=position.xz;`),x.fragmentShader=`uniform vec4 detailRect;uniform sampler2D detailMap;uniform float detailWeight;varying float dry;varying vec2 site;uniform float tideTime;uniform float lodWeight;
`+x.fragmentShader.replace("#include <map_fragment>",`#include <map_fragment>
 vec2 duv=(site-detailRect.xy)/detailRect.zw; duv.y=1.-duv.y;
 float de=min(min(duv.x,duv.y),min(1.-duv.x,1.-duv.y));
 if(de>0. && detailWeight>0.) diffuseColor.rgb=mix(diffuseColor.rgb,texture2D(detailMap,clamp(duv,0.,1.)).rgb,smoothstep(0.,.09,de)*detailWeight);
 float wobble=sin(site.y*18.+site.x*6.);float wave=sin(site.x*340.+site.y*650.+wobble*4.+tideTime)*.5+.5;
 float field=sin(site.x*443.+site.y*28.)*sin(site.y*980.)*.04;
 diffuseColor.rgb*=1.+mix((wave-.5)*.14,field,max(dry,0.))/(1.+length(fwidth(site))*100.);
 float edge=min(min(vMapUv.x,vMapUv.y),min(1.-vMapUv.x,1.-vMapUv.y));
 diffuseColor.a*=lodWeight*smoothstep(0.,.12,edge)*smoothstep(-1.,0.,dry);`)};const o=s.clone();if(o.onBeforeCompile=s.onBeforeCompile,o.depthWrite=!0,this.surface=new Ne(n,[o,s]),this.surface.renderOrder=-2,this.surface.receiveShadow=!0,t.add(this.surface,this.buildings),!this.data.buildings.length)return;const a=[],l=[];let c=90210;const h=()=>(c=Math.imul(c,1664525)+1013904223>>>0,c/4294967296);function u(x,v,w,M){a.push(...x,...v,...w);for(let A=0;A<3;A++)l.push(M.r,M.g,M.b)}const d=[];for(const x of this.data.buildings){const v=x.map(this.frame.project);let w=0,M=0;v.forEach(([Ie,L],Z)=>{const j=v[(Z+1)%v.length],Y=Math.hypot(j[0]-Ie,j[1]-L);Y>w&&(w=Y,M=Math.atan2(j[1]-L,j[0]-Ie))});const A=Math.cos(M),T=Math.sin(M),S=v.map(([Ie,L])=>Ie*A+L*T),b=v.map(([Ie,L])=>-Ie*T+L*A),D=Math.min(...S),I=Math.max(...S),U=Math.min(...b),B=Math.max(...b),k=(D+I)/2,V=(U+B)/2,te=k*A-V*T,H=k*T+V*A,Q=this.height(te,H),re=.003+h()*.0025,ge=Math.min(.005,(B-U)*.44),xe=(Ie,L,Z)=>[Ie*A-L*T,Q+Z,Ie*T+L*A],Qe=[[D,U],[I,U],[I,B],[D,B]],ot=new Oe(this.style==="B"?h()<.6?"#ede0bc":"#b98e72":h()<.55?"#e2d6b6":"#aa7964"),qe=new Oe(this.style==="B"?h()<.55?"#ad6749":"#6e796e":h()<.54?"#795d47":"#7b4b3e");for(let Ie=0;Ie<4;Ie++){const L=Qe[Ie],Z=Qe[(Ie+1)%4],j=xe(L[0],L[1],-8e-4),Y=xe(Z[0],Z[1],-8e-4),K=xe(L[0],L[1],re),he=xe(Z[0],Z[1],re);u(j,K,Y,ot),u(Y,K,he,ot)}const J=this.style==="B"?85e-5:35e-5,ee=Qe.map(([Ie,L])=>xe(Ie+Math.sign(Ie-k)*J,L+Math.sign(L-V)*J,re)),Se=xe(D+.17*(I-D),V,re+ge),Te=xe(I-.17*(I-D),V,re+ge);if(u(ee[0],Se,ee[3],qe),u(ee[1],ee[2],Te,qe),u(ee[0],ee[1],Te,qe),u(ee[0],Te,Se,qe),u(ee[3],Se,Te,qe),u(ee[3],Te,ee[2],qe),this.style==="B"&&I-D>.012){const Ie=U-.0016,L=U+.0018,Z=.0021,j=re+.0024,Y=xe(k-Z,Ie,re-.001),K=xe(k+Z,Ie,re-.001),he=xe(k,Ie,j),se=xe(k,L,j);u(Y,K,he,ot),u(Y,he,se,qe),u(K,se,he,qe)}const Ee=new Oe("#3b5355"),et=new Oe("#d7c9af");for(const Ie of[U-5e-5,B+5e-5])for(let L=D+.0024;L<I-.0011;L+=.0035){const Z=xe(L,Ie,.0011),j=xe(L+.0012,Ie,.0011),Y=xe(L,Ie,.0026),K=xe(L+.0012,Ie,.0026);u(Z,j,Y,Ee),u(j,K,Y,Ee),u(Z,j,xe(L,Ie,92e-5),et)}for(let Ie=0;Ie<4;Ie++){const L=te+(h()-.5)*.06,Z=H+(h()-.5)*.058;ah(L,Z,this.coast)&&d.push({x:L,z:Z,y:this.height(L,Z),h:.003+h()*.005})}}const f=new it;f.setAttribute("position",new Me(a,3)),f.setAttribute("color",new Me(l,3)),f.computeVertexNormals();const g=new Ne(f,new Ps({vertexColors:!0,side:wt}));g.castShadow=!0,g.receiveShadow=!0,this.buildings.add(g);const _=new Rt,m=new qa(this.style==="A"?new sr(1,1):new Al(1,0),new Ps({flatShading:this.style==="B"}),d.length),p=new qa(new nr(1,1.35,1,6),new Ps({color:7429447}),d.length),y=m.geometry.getAttribute("position");for(let x=0;x<y.count;x++){const v=y.getX(x),w=y.getY(x),M=y.getZ(x),A=1+.12*Math.sin(11*v+9*w+5*M);y.setXYZ(x,v*A,w*A,M*A)}m.geometry.computeVertexNormals(),d.forEach((x,v)=>{_.position.set(x.x,x.y+x.h*.22,x.z),_.scale.set(x.h*.052,x.h*.44,x.h*.052),_.updateMatrix(),p.setMatrixAt(v,_.matrix),_.position.set(x.x,x.y+x.h*.78,x.z),_.scale.set(x.h*.53,x.h*.48,x.h*.47),_.rotation.y=v*2,_.updateMatrix(),m.setMatrixAt(v,_.matrix),m.setColorAt(v,new Oe().setHSL(.21+h()*.06,.17+h()*.13,.25+h()*.12))}),m.castShadow=!0,this.buildings.add(m,p)}update(e,t,n,s){const r=Math.abs(e-this.region.target.lat)<1.4&&Math.abs(t-this.region.target.lon)<2.5;r&&n<this.region.lod.loadKm&&!this.loading&&this.load();const[o,a]=this.region.lod.fadeKm;if(this.weight.value=1-tt((n-o)/(a-o)),this.group.visible=this.ready&&r&&n<a,this.surface){const l=this.surface.material[0];l.transparent=this.weight.value<.9999,l.depthWrite=!l.transparent}this.buildings.visible=n<this.region.lod.buildingsKm,this.time.value=s/1700}}const A_=Ze*.935;function Qi(i){return[Ze,i?A_:Qt[0].inner,...Qt.slice(1).map(e=>e.inner)]}class T_{group=new rt;cut=!0;comparisonMode="reference";get expanded(){return this.comparisonMode==="expanded"}get lithosphere(){return this.comparisonMode==="lithosphere"}setComparison(e){this.comparisonMode=e}visible=[!0,!0,!0,!0];opacity=[1,1,1,1];selected=null;subdued=!1;style="A";map;variants=new Map;builds=0;comparison=new rt;constructor(){const e=new wl({color:14021861,toneMapped:!1});for(const t of[-25,65]){const n=[],s=Qi(!1)[1],r=(l,c)=>Ke(l,t+(t<0?.12:-.12),c-Ze),o=l=>s-120-42*Math.sin(l*.095);for(let l=8;l<59;l++)n.push(r(l,o(l)),r(l+1,o(l+1))),(l-8)%4===0&&n.push(r(l,Ze),r(l+2,o(l+2)));const a=new qh(new it().setFromPoints(n),e);this.comparison.add(a)}this.group.add(this.comparison)}get parts(){return this.variants.get(this.style)?.parts??[]}restore(){this.visible.fill(!0),this.opacity.fill(1),this.selected=null,this.subdued=!1}rebuild(){let e=this.variants.get(this.style);if(!e||e.map!==this.map){if(e)for(const n of e.parts)this.group.remove(n),n.geometry.dispose(),n.material.dispose();e={map:this.map,parts:this.build()},this.variants.set(this.style,e),this.builds++}this.comparison.visible=this.lithosphere&&this.cut&&this.visible[0]&&this.visible[1];const t=Qi(this.expanded);for(const[n,{parts:s}]of this.variants)for(const r of s){const{layer:o,kind:a,inner:l,base:c}=r.userData,h=n==="A"&&!l&&a!=="section"&&o>=2&&this.visible[o-1]&&this.opacity[o-1]===1&&this.opacity[o]===1,u=r.userData.edgeCount??0;if(u&&r.geometry.setDrawRange(h?0:u,h?u:1/0),r.visible=n===this.style&&this.visible[o]&&!(h&&!this.cut)&&(a==="section"?this.cut:a==="closure"?!this.cut:!0)&&(!l||!this.visible[o+1]||this.opacity[o+1]<1),n!==this.style)continue;a!=="section"&&r.scale.setScalar(t[o+(l?1:0)]),r.morphTargetInfluences&&(r.morphTargetInfluences[0]=Number(this.expanded));const d=r.material,f=o===this.selected,g=this.selected!==null&&this.subdued&&!f;if(r.userData.selected===f&&r.userData.dim===g&&d.opacity===this.opacity[o])continue;r.userData.selected=f,r.userData.dim=g,d.color.setHex(c).multiplyScalar(g?.44:1),d.emissive.setHex(f?Qt[o].color:0),d.emissiveIntensity=f?.28:0,d.opacity=this.opacity[o];const _=d.opacity<1;d.transparent!==_&&(d.transparent=_,d.depthWrite=!_,d.needsUpdate=!0)}}build(){const e=[],t=this.style==="A"?96:64,n=t/2,s=Qi(!1),r=Qi(!0);for(const[o,a]of Qt.entries()){const l=this.style==="A"?a.color:[8887688,11102291,14853480,15653813][o],c=(h,u,d=!1)=>{const f=o===0&&!d&&u!=="section",g=f||u==="section"?16777215:l,_=new gn({color:g,map:f?this.map:null,vertexColors:u==="section",roughness:f?.93:[.9,.94,.62,.76][o],flatShading:this.style==="B",side:wt});_.forceSinglePass=!0;const m=new Ne(h,_);m.userData={layer:o,kind:u,inner:d,base:g},m.renderOrder=4-o,this.group.add(m),e.push(m)};for(const h of[!1,!0])if(!(h&&!a.inner))for(const[u,d,f]of[[65,335,"body"],[335,425,"closure"]]){const g=Math.round(t*(d-u)/360),_=[],m=[],p=[],y=[];for(let w=0;w<=n;w++)for(let M=0;M<=g;M++){const A=-90+180*w/n,T=u+(d-u)*M/g,S=Ke(A,T,1-Ze);_.push(S.x,S.y,S.z);const b=h?-1:1;m.push(b*S.x,b*S.y,b*S.z),p.push((T+180)/360,(A+90)/180)}for(let w=0;w<n;w++)for(let M=0;M<g;M++){const A=w*(g+1)+M,T=A+g+1;y.push(A,A+1,T,A+1,T+1,T)}const x=new it;x.setAttribute("position",new Me(_,3)),x.setAttribute("normal",new Me(m,3)),x.setAttribute("uv",new Me(p,2));const v=[];if(this.style==="A"&&!h&&o>=2&&f==="body")for(let w=0;w<n;w++){const M=w*g*6;w===0||w===n-1?v.push(...y.slice(M,M+g*6)):v.push(...y.slice(M,M+18),...y.slice(M+(g-3)*6,M+g*6))}x.setIndex([...v,...y]),c(x,f,h),e[e.length-1].userData.edgeCount=v.length}for(const h of[65,335]){const u=[],d=[],f=[],g=[],_=this.style==="A"?24:12;for(let p=0;p<=n;p++)for(let y=0;y<=_;y++){const x=-90+180*p/n,v=y/_,w=Ke(x,h,1-Ze),M=ut.lerp(s[o+1],s[o],v),A=ut.lerp(r[o+1],r[o],v);u.push(w.x*M,w.y*M,w.z*M),d.push(w.x*A,w.y*A,w.z*A);const T=(h===65?.96:.84)-.14*Math.exp(-20*(1-v))-.08*Math.exp(-24*v)+.052*Math.sin(x*.11+v*8)+.027*Math.cos(x*.23-v*17)+.025*Math.sin(x*.28+v*26+Math.sin(x*.13)),S=new Oe(l).multiplyScalar(T);f.push(S.r,S.g,S.b)}for(let p=0;p<n;p++)for(let y=0;y<_;y++){const x=p*(_+1)+y,v=x+_+1;g.push(x,v,x+1,x+1,v,v+1)}let m=new it;if(m.setAttribute("position",new Me(u,3)),m.setAttribute("color",new Me(f,3)),m.setIndex(g),m.computeVertexNormals(),o<2&&(m.morphAttributes.position=[new Me(d,3)]),this.style==="B"){const p=m;m=m.toNonIndexed(),p.dispose();const y=m.attributes.color;for(let x=0;x<y.count;x+=3){const v=new Oe(l).multiplyScalar(.82+.2*(.5+.5*Math.sin(x*4.91+o)));for(let w=0;w<3;w++)y.setXYZ(x+w,v.r,v.g,v.b)}}c(m,"section")}}return e}}class C_{minimum;maximum;ratio;reductions=0;recoveries=0;low=0;high=0;cooldown=0;constructor(e){this.maximum=Math.min(e,1.5),this.minimum=Math.min(.75,this.maximum),this.ratio=this.maximum}resetWindow(){this.low=this.high=0}sample(e,t){if(this.cooldown>0){this.cooldown-=t,this.resetWindow();return}if(this.low=e<24?this.low+t:0,this.high=e>=45?this.high+t:0,this.low>=2&&this.ratio>this.minimum)this.ratio=Math.max(this.minimum,this.ratio-.15),this.reductions++,this.cooldown=3;else if(this.high>=8&&this.ratio<this.maximum)this.ratio=Math.min(this.maximum,this.ratio+.1),this.recoveries++,this.cooldown=6;else return;return this.resetWindow(),this.ratio}}const lh=`
float nyosCoverage(vec2 uv, float weight) {
  vec2 edge = min(uv, vec2(1.0) - uv);
  return weight * smoothstep(0.0, 0.05, min(edge.x, edge.y));
}
`;class R_{constructor(e,t,n,s){this.sample=t;const r=[];for(let c=0;c<e.length;c++){const h=e[c],u=e[(c+1)%e.length];h.x>0!=u.x>0&&r.push(ut.lerp(h.z,u.z,-h.x/(u.x-h.x)))}r.sort((c,h)=>c-h);const o=r.findIndex((c,h)=>h%2===0&&c<=0&&r[h+1]>0);if(o<0)throw Error("Der Schnitt trifft kein geschlossenes Seebecken.");this.start=r[o],this.end=r[o+1];const a=Math.max(...e.map(c=>c.x))+.86;this.window=new at(0,a,this.start-.29,this.end+.29),this.group.name="Nyos · offener Seeschnitt in der Landschaft";const l=[];for(const[c,h,u]of[[this.window.z,this.start,15],[this.start,this.end,74],[this.end,this.window.w,15]])for(let d=0;d<u;d++)l.push(ut.lerp(c,h,d/u));l.push(this.window.w),this.group.add(this.apron(n,s,l),this.bedrock(l),this.waterFace(),this.source),this.makeSource(),this.group.visible=!1}group=new rt;maxDepth=.208;start;end;window;dissolved={value:0};source=new rt;analysisRequested=!1;stock=null;depthAt(e){const t=ct((e-this.start)/(this.end-this.start),0,1),n=Math.pow(Math.max(0,Math.sin(Math.PI*t)),.73),s=1-.085*Math.exp(-Math.pow((t-.24)/.105,2));return this.maxDepth*n*s}excavation(e,t){const n=(1-tt((e-.46)/(this.window.y-.46)))*tt((t-this.window.z)/.29)*tt((this.window.w-t)/.29),s=this.sample(e,t),r=Math.min(s.height,-.292)+.014*e+.004*Math.sin(4*t);return{...s,y:ut.lerp(s.height,r,n),opening:n}}apron(e,t,n){const s=[],r=[],o=[],a=[];for(let d=0;d<n.length;d++)for(let f=0;f<=54;f++){const g=this.window.y*f/54,_=n[d],m=this.excavation(g,_);if(s.push(g,m.y,_),r.push(m.u,m.v),o.push(Math.max(tt(m.opening/.64),m.water*tt(m.opening/.075))),d&&f){const p=d*55+f,y=p-54-2;a.push(y,p-1,y+1,y+1,p-1,p)}}const c=new it;c.setAttribute("position",new Me(s,3)),c.setAttribute("uv",new Me(r,2)),c.setAttribute("exposure",new Me(o,1)),c.setIndex(a),c.computeVertexNormals();const h=new mn({map:e});h.onBeforeCompile=d=>{d.uniforms.uNyosSun=t,d.vertexShader=`attribute float exposure; uniform vec3 uNyosSun; varying float cutExposure,cutLight; varying vec2 cutXZ;
`+d.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
 cutExposure=exposure; cutLight=.60+.58*max(0.0,dot(normalize(normal),uNyosSun)); cutXZ=position.xz;`),d.fragmentShader=`varying float cutExposure,cutLight; varying vec2 cutXZ;
`+d.fragmentShader.replace("#include <map_fragment>",`#include <map_fragment>
        float grain=.94+.06*sin(38.*cutXZ.x+sin(9.*cutXZ.y))*.65+.035*sin(75.*cutXZ.y+19.*cutXZ.x);
        diffuseColor.rgb = mix(diffuseColor.rgb,vec3(.20,.158,.111)*grain,cutExposure)*cutLight;`)};const u=new Ne(c,h);return u.name="Vorderes Gelände bis unter die Schnittsohle geöffnet",u}bedrock(e){const t=[],n=[],s=[],o=new Oe("#64594b"),a=new Oe("#9b8160");for(let h=0;h<e.length;h++){const u=e[h],d=this.excavation(0,u),f=u>=this.start&&u<=this.end?-this.depthAt(u):d.height;for(let g=0;g<=12;g++){const _=g/12,m=ut.lerp(d.y,f,_);t.push(0,m,u);const p=o.clone().lerp(a,.3+.55*_).multiplyScalar(.96+.045*Math.sin(m*214+1.1*Math.sin(u*8)));if(n.push(p.r,p.g,p.b),h&&g){const y=h*13+g,x=y-12-2;s.push(x,x+1,y-1,y-1,x+1,y)}}}const l=new it;l.setAttribute("position",new Me(t,3)),l.setAttribute("color",new Me(n,3)),l.setIndex(s);const c=new Ne(l,new mn({vertexColors:!0,side:wt}));return c.name="Gestein am schematischen Seegrund",c}waterFace(){const e=[],t=[];for(let a=0;a<=86;a++){const l=ut.lerp(this.start,this.end,a/86);if(e.push(0,0,l,0,-this.depthAt(l),l),a){const c=2*a-2;t.push(c,c+1,c+2,c+2,c+1,c+3)}}const s=new it;s.setAttribute("position",new Me(e,3)),s.setIndex(t);const r=new mn({side:wt});r.onBeforeCompile=a=>{a.uniforms.nyosDissolved=this.dissolved,a.vertexShader=`varying float depthAtFace;
`+a.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
 depthAtFace=max(0.,-position.y);`),a.fragmentShader=`varying float depthAtFace; uniform float nyosDissolved;
`+a.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
         float mid = smoothstep(.016,.075,depthAtFace);
         float deep = smoothstep(.062,.196,depthAtFace);
         vec3 water=mix(vec3(.26,.52,.45),vec3(.072,.25,.25),mid);
         water=mix(water,vec3(.032,.12,.166),deep);
         vec3 dissolved=mix(water,vec3(.34,.14,.25),.86*deep*nyosDissolved);
         diffuseColor.rgb *= dissolved;`)};const o=new Ne(s,r);return o.name="Geschichtetes Wasser auf der geöffneten Schnittfläche",o}makeSource(){const e=new mn({color:"#d6be91",side:wt});for(const t of[.37,.65]){const n=ut.lerp(this.start,this.end,t),s=-this.depthAt(n),r=s-.063,o=s-.01,a=.017,l=[.0015,r,n-a-.0035,.0015,r,n-a+.0035,.0015,o-.015,n+.0035,.0015,r,n-a-.0035,.0015,o-.015,n+.0035,.0015,o-.015,n-.0035,.0015,o-.016,n-.01,.0015,o-.016,n+.01,.0015,o,n+.004],c=new it;c.setAttribute("position",new Me(l,3)),this.source.add(new Ne(c,e))}this.source.name="Geologische Zufuhr von CO₂-haltigem Wasser · schematische Wege"}showDissolved(e){this.analysisRequested=e,this.updateAnalysis()}showInventory(e){this.stock=e,this.updateAnalysis()}updateAnalysis(){this.dissolved.value=this.analysisRequested?this.stock??1:0,this.source.visible=this.stock===null&&this.analysisRequested}get geologicalSupplyVisible(){return this.source.visible}}const tl=[{name:"Talsohle",lat:6.4699727,lon:10.3028889},{name:"Hanglage",lat:6.4699727,lon:10.309}],Ko=new gn({color:"#91a7ab",metalness:.38,roughness:.55,side:wt}),Or=new gn({color:"#425c63",metalness:.28,roughness:.6,side:wt}),Zo=new gn({color:"#d0b077",roughness:.7,metalness:.03}),P_=new mn({color:"#b7e3db",side:wt}),L_=new mn({color:"#407c85"}),ch=new gn({color:"#b3d3ce",roughness:.48,metalness:.04}),hh=new mn({color:"#ebdfb4"});function As(i,e,t,n,s,r,o){const a=new Ne(new nr(e,e,n-t,14),o);return a.position.set(s,(t+n)/2,r),i.add(a),a}function Jo(i,e,t,n,s,r,o){const a=new Ne(new Pl(e,t,7,24),o);a.rotation.x=Math.PI/2,a.position.set(n,s,r),i.add(a)}class D_{constructor(e){this.terrain=e,this.group.name="Risikominderung · spätere Maßnahmen",this.group.add(this.pipeView,this.monitor,this.land),this.pipeView.add(this.flow,this.outlet),this.group.visible=!1,this.makeLand()}group=new rt;pipeView=new rt;monitor=new rt;land=new rt;flow=new rt;outlet=new rt;arrows=[];spray=[];intakeY=0;stock=1;devicesBuilt=!1;measure="pipe";terrainPoints=[];makePipe(e){const t=e.start+.56*(e.end-e.start),n=.016,s=.012;this.intakeY=-e.depthAt(t)+.017;const r=.027,o=new Ne(new nr(s,s,r-this.intakeY,26,1,!0,Math.PI*.74,Math.PI*1.52),Ko);o.position.set(n,(r+this.intakeY)/2,t),this.pipeView.add(o),As(this.pipeView,.007,this.intakeY,r,n,t,L_),Jo(this.pipeView,s,.0022,n,this.intakeY,t,Or),Jo(this.pipeView,s,.002,n,r,t,Ko);for(const d of[-1,1]){const f=new Ne(new El(.006,.034,4,12),Zo);f.rotation.x=Math.PI/2,f.position.set(n+d*.023,.006,t),this.pipeView.add(f)}const a=new Ne(new ms(.055,.003,.02),Or);a.position.set(n,.009,t+.01),this.pipeView.add(a);const l=new ir;l.moveTo(-.0025,-.007),l.lineTo(.0025,-.007),l.lineTo(.0025,.001),l.lineTo(.006,.001),l.lineTo(0,.008),l.lineTo(-.006,.001),l.lineTo(-.0025,.001),l.closePath();const c=new ro(l);c.rotateY(Math.PI/2);for(let d=0;d<4;d++){const f=new Ne(c,P_);f.position.set(n+s*.89,this.intakeY,t),this.flow.add(f),this.arrows.push(f)}const h=new qs([new P(n,r,t),new P(n+5e-4,.041,t-.001),new P(n+.002,.049,t-.005),new P(n+.005,.045,t-.012),new P(n+.009,.025,t-.019)]);this.outlet.add(new Ne(new Zs(h,22,.0026,8,!1),ch));const u=new sr(.0024,1);for(let d=0;d<4;d++){const f=new Ne(u,ch);this.outlet.add(f),this.spray.push(f)}this.outlet.position.set(0,0,0)}makeMonitor(e){const n=ut.lerp(e.start,e.end,.48),s=.014,r=e.depthAt(n),o=new Ne(new Kn(.019,16,9),Zo);o.scale.set(1,.48,1),o.position.set(s,.008,n),this.monitor.add(o),As(this.monitor,.0022,-r+.022,.009,s,n,Or);for(const a of[.22,.54,.81]){const l=-r*a,c=As(this.monitor,.0078,l-.012,l+.012,s,n,Ko);c.name="Messsonde auf dem Tiefenprofil",Jo(this.monitor,.0079,.0016,s,l+.007,n,Zo)}As(this.monitor,.005,-r+.012,-r+.026,s,n,Or),this.monitor.name="Schematisches Messprofil unter einer Boje"}makeLand(){for(const e of tl){const t=this.terrain.ground(e.lat,e.lon);if(t===null)continue;const n=this.terrain.toLocal(e.lon,e.lat,t);this.terrainPoints.push({...e,heightM:Math.round(t*1e3)});const s=[];for(let a=0;a<28;a++){const l=a*2*Math.PI/28,c=this.terrain.fromLocal(n.x+.044*Math.cos(l),n.z+.044*Math.sin(l)),h=this.terrain.ground(c.lat,c.lon)??t,u=this.terrain.toLocal(c.lon,c.lat,h+.003);s.push(u)}const r=new qs(s,!0),o=new Ne(new Zs(r,40,.0025,6,!0),hh);this.land.add(o),As(this.land,.0022,n.y+.002,n.y+.063,n.x,n.z,hh)}this.land.name="Zwei reale Geländepunkte · Talsohle und Hang"}update(e,t,n){this.group.visible=e,this.measure=t,this.pipeView.visible=e&&t==="pipe",this.monitor.visible=e&&t==="monitor",this.land.visible=e&&t==="settlements";const s=this.terrain.section;if(!e){this.flow.visible=!1,this.outlet.visible=!1,this.stock=1;return}s&&!this.devicesBuilt&&(this.makePipe(s),this.makeMonitor(s),this.devicesBuilt=!0);const r=ct(n,0,1);if(this.stock=this.pipeView.visible?1-.62*tt(r):1,this.flow.visible=this.pipeView.visible&&r>.025,this.outlet.visible=this.pipeView.visible&&r>.23,!this.pipeView.visible||!s)return;for(let a=0;a<this.arrows.length;a++){const l=(r*2.7+a/this.arrows.length)%1;this.arrows[a].position.y=ut.lerp(this.intakeY+.012,.016,l)}const o=s.start+.56*(s.end-s.start);for(let a=0;a<this.spray.length;a++){const l=(r*6+a/this.spray.length)%1;this.spray[a].position.set(.025+l*.003,.025-l*l*.026,o-.019-.01*l)}}diagnostics(){const e=this.group.visible&&this.pipeView.visible&&this.devicesBuilt;return{protectionVisible:this.group.visible,measure:this.measure,pipeVisible:e,monitorVisible:this.group.visible&&this.monitor.visible&&this.devicesBuilt,settlementVisible:this.group.visible&&this.land.visible,settlementComparisonVisible:this.group.visible&&this.land.visible,pipeFlowVisible:e&&this.flow.visible,controlledVentVisible:e&&this.outlet.visible,remainingDissolved:e?this.stock:null,reliefMarkers:this.terrainPoints.map(t=>({...t,visible:this.group.visible&&this.land.visible}))}}get dissolvedFraction(){return this.stock}}function I_(i){const e=i.geometry,t=e.getIndex(),{columns:n,rows:s}=e.userData,r=e.getAttribute("position");if(n*s!==r.count||t.count!==6*(n-1)*(s-1))throw Error("Inkonsistentes DEM-Gitternetz");const o=new pf,a=new rt,l=new P,c={frame:-1,drawnChunks:0,triangles:0,totalChunks:0};o.name="Nyos · maßstabsabhängige Geländeabschnitte",o.userData.surfaceStats=c;function h(f,g){f.onBeforeRender=_=>{const m=_.info.render.frame;c.frame!==m&&(c.frame=m,c.drawnChunks=0,c.triangles=0),c.drawnChunks++,c.triangles+=g}}const u=Math.ceil((n-1)/6),d=Math.ceil((s-1)/6);for(let f=0;f<s-1;f+=d)for(let g=0;g<n-1;g+=u){const _=Math.min(n-1,g+u),m=Math.min(s-1,f+d),p=new it,y=[],x=new cn;for(let w=f;w<=m;w++)for(let M=g;M<=_;M++){if(x.expandByPoint(l.fromBufferAttribute(r,w*n+M)),w===m||M===_)continue;const A=(w*(n-1)+M)*6;for(let T=A;T<A+6;T++)y.push(t.getX(T))}for(const[w,M]of Object.entries(e.attributes))p.setAttribute(w,M);p.setIndex(y),p.boundingBox=x,p.boundingSphere=x.getBoundingSphere(new wn);const v=new Ne(p,i.material);v.name=`Nyos · Gelände ${g}/${f}`,v.castShadow=i.castShadow,v.receiveShadow=i.receiveShadow,v.renderOrder=i.renderOrder,h(v,y.length/3),a.add(v)}return c.totalChunks=a.children.length,h(i,t.count/3),o.addLevel(a,0),o.addLevel(i,8,.1),o}const nl=i=>os("data/nyos/"+i),Fr=()=>new P;async function U_(i){const e=await new oo().loadAsync(nl(i));return e.colorSpace=Wt,e.anisotropy=4,e}function uh(i,e,t){const n=[];for(let s=0;s<i-1;){n.push(s);const r=Math.max(e-s,s-t,0);s+=r<12?1:r<45?2:3}return n.push(i-1),n}class N_{constructor(e){this.globalHeight=e,this.group.visible=!1,this.group.name="Landschaft am Nyos-See"}group=new rt;meta=null;ready=!1;error="";regionTexture=null;vicinityTexture=null;waterMesh=null;terrainMesh=null;fullWater;cutWater;shoreChord={value:new ue};pending;heights;shoreCells=null;origin=Fr();east=Fr();up=Fr();south=Fr();reveal={value:0};terrainLod;cut={value:0};cutWindow={value:new at};dissolved=!1;section=null;protection=null;sun={value:new P(-1.2,.91,-1.05).normalize()};get localWeight(){return this.reveal.value}load(){return this.pending??=this.loadData().then(e=>(e||(this.pending=void 0),e))}async loadData(){const e=[];try{const t=await fetch(nl("landscape.json"));if(!t.ok)throw Error("Gebietsbeschreibung");const n=await t.json();if(!(n.width>=2&&n.height>=2&&n.bounds?.length===4&&n.shoreline?.length>=4&&Number.isFinite(n.waterLevelM)&&Number.isFinite(n.anchor?.lon)))throw Error("Gebietsgeometrie");const s=fetch(nl(n.heightFile)).then(async p=>{if(!p.ok)throw Error("Höhenraster");const y=new Int16Array(await p.arrayBuffer());if(y.length!==n.width*n.height)throw Error("Größe des Höhenrasters");return y}),r=async p=>{const y=await U_(p);return e.push(y),y},[o,a,l,c]=await Promise.allSettled([s,r(n.surfaceFile),n.regional?r(n.regional.file).catch(()=>null):null,n.vicinity?r(n.vicinity.file).catch(()=>null):null]);if(o.status==="rejected")throw o.reason;if(a.status==="rejected")throw a.reason;this.meta=n,this.heights=o.value,this.regionTexture=l.status==="fulfilled"?l.value:null,this.vicinityTexture=c.status==="fulfilled"?c.value:null;const{lat:h,lon:u}=n.anchor,{east:d,up:f,north:g}=$n(h,u);this.east.copy(d),this.up.copy(f),this.south.copy(g).negate(),this.origin.copy(Ke(h,u,n.waterLevelM/1e3)),this.group.position.copy(this.origin),this.group.quaternion.setFromRotationMatrix(new st().makeBasis(this.east,this.up,this.south)),this.waterMask();const _=this.makeSurface(a.value),m=this.makeWater();return this.terrainMesh=_,this.waterMesh=m,this.terrainLod=I_(_),this.group.add(this.terrainLod,m),this.error="",this.ready=!0,this.cut.value&&this.setSection(!0),!0}catch(t){this.error=t instanceof Error?t.message:"Landschaftsdaten";for(const n of e)n.dispose();return this.regionTexture=null,this.vicinityTexture=null,this.meta=null,this.heights=void 0,!1}}toLocal(e,t,n){const s=Ke(t,e,n).sub(this.origin);return new P(s.dot(this.east),s.dot(this.up),s.dot(this.south))}waterMask(){const e=this.meta,[t,n,s,r]=e.bounds,o=document.createElement("canvas"),a=3;o.width=Math.min(e.width*a,2048),o.height=Math.min(e.height*a,2048);const l=o.getContext("2d");l.fillStyle="#000",l.fillRect(0,0,o.width,o.height),l.beginPath(),e.shoreline.forEach(([u,d],f)=>{const g=(u-t)/(s-t)*o.width,_=(r-d)/(r-n)*o.height;f?l.lineTo(g,_):l.moveTo(g,_)}),l.closePath(),l.fillStyle="#fff",l.fill();const c=document.createElement("canvas");c.width=e.width,c.height=e.height;const h=c.getContext("2d");h.drawImage(o,.5,.5,e.width-1,e.height-1),this.shoreCells=h.getImageData(0,0,e.width,e.height).data}heightAt(e,t){const n=this.meta,s=t*n.width+e,r=this.heights[s]*.001,o=this.shoreCells[4*s]/255;return ut.lerp(r,n.waterLevelM*.001,o)}ground(e,t){if(!this.meta||!this.heights||!this.shoreCells)return null;const n=this.meta,[s,r,o,a]=n.bounds,l=1e-9;if(t<s-l||t>o+l||e<r-l||e>a+l)return null;const c=ct((t-s)/(o-s),0,1)*(n.width-1),h=ct((a-e)/(a-r),0,1)*(n.height-1),u=Math.min(n.width-2,Math.floor(c)),d=Math.min(n.height-2,Math.floor(h)),f=c-u,g=h-d,_=ut.lerp(ut.lerp(this.heightAt(u,d),this.heightAt(u+1,d),f),ut.lerp(this.heightAt(u,d+1),this.heightAt(u+1,d+1),f),g),m=Math.min(c/(n.width-1),h/(n.height-1),1-c/(n.width-1),1-h/(n.height-1));return m>=.05?_:ut.lerp(this.globalHeight(e,t)+.002,_,tt(m/.05))}occlusion(e,t){const n=this.meta,s=this.heights,r=s[t*n.width+e],o=(n.bounds[3]-n.bounds[1])*ke*6371e3/(n.height-1);let a=0;for(const[l,c]of[[1,0],[-1,0],[0,1],[0,-1]]){let h=0;for(const u of[3,8,16]){const d=ct(e+u*l,0,n.width-1),f=ct(t+u*c,0,n.height-1);h=Math.max(h,(s[f*n.width+d]-r)/(o*u))}a+=Math.min(.8,h)}return 1-.05*a}lightDirection(e){this.group.visible&&this.sun.value.set(e.dot(this.east),e.dot(this.up),e.dot(this.south))}makeSurface(e){const t=this.meta,[n,s,r,o]=t.bounds,a=t.shoreline.map(y=>(y[0]-n)/(r-n)*(t.width-1)),l=t.shoreline.map(y=>(o-y[1])/(o-s)*(t.height-1)),c=uh(t.width,Math.min(...a),Math.max(...a)),h=uh(t.height,Math.min(...l),Math.max(...l)),u=[],d=[],f=[],g=[];for(const[y,x]of h.entries()){const v=x/(t.height-1),w=o-v*(o-s);for(const[M,A]of c.entries()){const T=A/(t.width-1),S=n+T*(r-n),b=this.ground(w,S),D=.008*this.shoreCells[4*(x*t.width+A)]/255,I=this.toLocal(S,w,b-D);u.push(I.x,I.y,I.z),d.push(T,1-v);const U=this.occlusion(A,x);if(f.push(U,U,U),y&&M){const B=y*c.length+M,k=B-c.length-1,V=k+1,te=B-1;g.push(k,te,V,V,te,B)}}}const _=new it;_.setAttribute("position",new Me(u,3)),_.setAttribute("uv",new Me(d,2)),_.setAttribute("color",new Me(f,3)),_.userData={columns:c.length,rows:h.length},_.setIndex(g),_.computeVertexNormals();const m=new mn({map:e,transparent:!0,depthWrite:!0,vertexColors:!0});m.onBeforeCompile=y=>{y.uniforms.uNyosWeight=this.reveal,y.uniforms.uNyosSun=this.sun,y.uniforms.nyosCut=this.cut,y.uniforms.nyosCutWindow=this.cutWindow,y.uniforms.nyosShoreChord=this.shoreChord,y.vertexShader=`uniform vec3 uNyosSun; varying vec3 nyosLandPoint;
`+y.vertexShader.replace("#include <color_vertex>",`#include <color_vertex>
         nyosLandPoint=position.xzy;
         float sunlight=max(dot(normalize(normal),uNyosSun),0.0);
         vColor.rgb *= vec3(.57,.61,.59) + vec3(.68,.62,.53)*sunlight;`),y.fragmentShader=`uniform float uNyosWeight, nyosCut; uniform vec4 nyosCutWindow; uniform vec2 nyosShoreChord; varying vec3 nyosLandPoint;
        ${lh}
`+y.fragmentShader.replace("#include <map_fragment>",`
          // Set the submerged DEM backing back from the optical cut edge. Drawing a
          // second shallow surface on that viewing line produces a stippled seam.
          float startX = nyosLandPoint.z<-.001 && nyosLandPoint.y>nyosShoreChord.x &&
                         nyosLandPoint.y<nyosShoreChord.y ? -.026 : nyosCutWindow.x;
          if(nyosCut>.5 && nyosLandPoint.x>=startX && nyosLandPoint.x<nyosCutWindow.y &&
              nyosLandPoint.y>nyosCutWindow.z && nyosLandPoint.y<nyosCutWindow.w) discard;
          float coverage=nyosCoverage(vMapUv,uNyosWeight);
          if (coverage<.002) discard;
          diffuseColor.a *= coverage;
          #include <map_fragment>
        `)};const p=new Ne(_,m);return p.name="Nyos · Satellitenbild auf Copernicus-Höhenraster",p}makeWater(){const e=this.meta,t=e.shoreline.map(([c,h])=>this.toLocal(c,h,e.waterLevelM/1e3)),n=c=>{const h=new ir;c.forEach((d,f)=>{f?h.lineTo(d.x,-d.z):h.moveTo(d.x,-d.z)}),h.closePath();const u=new ro(h);return u.rotateX(-Math.PI/2),u},s=[];for(let c=0;c<t.length;c++){const h=t[c],u=t[(c+1)%t.length];h.x>0!=u.x>0&&s.push(new P(0,0,ut.lerp(h.z,u.z,-h.x/(u.x-h.x)))),u.x<=0&&s.push(u)}this.fullWater=n(t),this.cutWater=n(s);const r=this.fullWater,o=new gn({color:"#31593e",transparent:!0,depthWrite:!0,metalness:.02,roughness:.34,polygonOffset:!0,polygonOffsetFactor:-1,polygonOffsetUnits:-1}),a=this.reveal;o.onBeforeCompile=c=>{c.uniforms.uNyosWeight=a,c.uniforms.nyosCut=this.cut,c.vertexShader=`varying vec2 nyosSurface;
`+c.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
 nyosSurface = position.xz;`),c.fragmentShader=`varying vec2 nyosSurface; uniform float uNyosWeight,nyosCut;
${lh}
`+c.fragmentShader.replace("#include <alphatest_fragment>",`#include <alphatest_fragment>
 diffuseColor.a *= uNyosWeight;`).replace("#include <opaque_fragment>",`
          // A calm surface picks up the sky at grazing angles. Stable, metre-scale ripples leave the shoreline fixed.
          float shoreSky = pow(1.0-clamp(dot(normalize(vViewPosition),normal),0.0,1.0),3.0);
          vec2 p = nyosSurface*1000.0;
          float grain = sin(p.y*.27 + .8*sin(p.x*.062+p.y*.013)) *
                        sin(p.y*.082 + p.x*.031 + .7*sin(p.x*.02));
          float resolved = 1.0-smoothstep(2.2,8.0,max(fwidth(p.y),fwidth(p.x)));
          outgoingLight=mix(outgoingLight,vec3(.17,.26,.25),.08+.49*shoreSky);
          outgoingLight += vec3(.008,.012,.009)*grain*resolved;
          #include <opaque_fragment>
        `)};const l=new Ne(r,o);return l.renderOrder=1,l.name="Nyos · beobachtete Wasserfläche",l}fromLocal(e,t){const n=this.origin.clone().addScaledVector(this.east,e).addScaledVector(this.south,t);return{lon:Math.atan2(n.x,n.z)/ke,lat:Math.asin(n.y/n.length())/ke}}setSection(e){this.cut.value=Number(e);const t=this.meta,n=this.terrainMesh?.material.map;if(e&&this.ready&&t&&n&&!this.section){const[s,r,o,a]=t.bounds,l=t.shoreline.map(([c,h])=>this.toLocal(c,h,t.waterLevelM/1e3));this.section=new R_(l,(c,h)=>{const{lon:u,lat:d}=this.fromLocal(c,h),f=this.ground(d,u)??t.waterLevelM/1e3,g=(u-s)/(o-s),_=(d-r)/(a-r),m=ct(Math.round(g*(t.width-1)),0,t.width-1),p=ct(Math.round((1-_)*(t.height-1)),0,t.height-1);return{height:this.toLocal(u,d,f).y,u:g,v:_,water:this.shoreCells[4*(m+p*t.width)]/255}},n,this.sun),this.cutWindow.value.copy(this.section.window),this.shoreChord.value.set(this.section.start,this.section.end),this.group.add(this.section.group)}this.waterMesh&&this.fullWater&&this.cutWater&&(this.waterMesh.geometry=e?this.cutWater:this.fullWater),this.section&&(this.section.group.visible=e,this.section.showDissolved(this.dissolved))}setDissolved(e){this.dissolved=e,this.section?.showDissolved(e)}setProtection(e,t,n){e&&this.ready&&!this.protection&&(this.protection=new D_(this),this.group.add(this.protection.group)),this.protection?.update(e,t,n),this.section?.showInventory(e&&t==="pipe"&&this.protection?this.protection.dissolvedFraction:null)}update(e,t){this.reveal.value=t&&this.ready?1-tt((e-16)/26):0,this.group.visible=this.reveal.value>0}diagnostics(){return{...this.protection?.diagnostics()??{protectionVisible:!1,pipeVisible:!1,monitorVisible:!1,settlementVisible:!1,settlementComparisonVisible:!1,pipeFlowVisible:!1,controlledVentVisible:!1,remainingDissolved:null,reliefMarkers:[]},ready:this.ready,error:this.error,localWeight:this.localWeight,surfaceVisible:this.group.visible&&!!this.terrainMesh,surfaceLod:this.terrainLod?.userData.surfaceStats,sectionVisible:this.group.visible&&!!this.section?.group.visible,dissolvedVisible:this.group.visible&&!!this.section?.group.visible&&this.dissolved,supplyVisible:this.group.visible&&!!this.section?.group.visible&&this.section.geologicalSupplyVisible,depthM:this.section?this.section.maxDepth*1e3:null,profileSpanKm:this.section?this.section.end-this.section.start:null,waterVisible:this.group.visible&&!!this.waterMesh?.visible,triangles:(this.terrainMesh?.geometry.index?.count??0)/3,shorelineVertices:this.meta?.shoreline.length??0,waterLevelM:this.meta?.waterLevelM??null,bounds:this.meta?.bounds??null,regionTextureReady:!!this.regionTexture,vicinityTextureReady:!!this.vicinityTexture}}}class O_{frame;origin;floor;limits;hit=new P;constructor(e,t){const{lat:n,lon:s}=e.anchor;this.frame=$n(n,s),this.origin=Ke(n,s),this.floor=t-.08;const[r,o,a,l]=e.bounds,c=(a-r)*.08,h=(l-o)*.08;this.limits=[Ke(n,r+c).sub(this.origin).dot(this.frame.east),Ke(o+h,s).sub(this.origin).dot(this.frame.north),Ke(n,a-c).sub(this.origin).dot(this.frame.east),Ke(l-h,s).sub(this.origin).dot(this.frame.north)]}inside(e){const t=e.dot(this.frame.east),n=e.dot(this.frame.north);return t>this.limits[0]&&n>this.limits[1]&&t<this.limits[2]&&n<this.limits[3]}containsView(e){const t=e.position;if(!this.inside(t))return!1;const n=t.dot(this.frame.up)-Ze;if(n<=this.floor)return!1;for(const s of[-1,1])for(const r of[-1,1]){const o=this.hit.set(s,r,.5).unproject(e).sub(t).normalize(),a=o.dot(this.frame.up);if(a>=-.001||(o.multiplyScalar((this.floor-n)/a).add(t),!this.inside(o)))return!1}return!0}}const Ul=`
  varying vec2 vEventUv;
  void main() {
    vEventUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.);
  }
`;function F_(i,e){const t=new nn({uniforms:{eventTime:{value:0}},vertexShader:Ul,fragmentShader:`
      varying vec2 vEventUv; uniform float eventTime;
      void main() {
        float y = vEventUv.y;
        float head = mix(.12,.94,smoothstep(.17,.46,eventTime));
        float axis = .49 + .09 * sin(y * 6. - .6);
        float dx = vEventUv.x - axis;
        float band = exp(-pow(dx / (.20 + .14*y), 2.));
        float flow = .5 + .5 * cos(40. * dx + 1.5 * sin(7.*y - eventTime*13.));
        float trail = band * (.27 + .46 * flow) * smoothstep(.00,.12,y)
                    * (1. - smoothstep(head-.16,head+.02,y));
        float shoulder = 1. - smoothstep(.012,.045,abs(y - head + .54 * abs(dx)));
        float crest = shoulder * (1. - smoothstep(.15,.30,abs(dx)));
        float opacity = max(trail, .86 * crest) * (1.-smoothstep(.60,.68,eventTime));
        if (opacity < .018) discard;
        gl_FragColor = vec4(mix(vec3(.20,.63,.58),vec3(.77,.94,.80),max(crest,.45*flow)),opacity);
        #include <colorspace_fragment>
      }
    `,transparent:!0,depthWrite:!1,side:wt,toneMapped:!1}),n=new Ne(new gs(.205,i),t);return n.rotation.y=Math.PI/2,n.position.set(.0028,-i/2,e),n.renderOrder=4,n}function B_(i){const e=new gs(.55,.55).rotateX(-Math.PI/2),t=new nn({uniforms:{eventTime:{value:0}},vertexShader:Ul,fragmentShader:`
      varying vec2 vEventUv; uniform float eventTime;
      void main() {
        vec2 p = (vEventUv - .5) * 2.;
        if(eventTime < .68 && p.x * .275 > .028) discard;
        float azimuth = atan(p.y,p.x + .00001);
        float base = length(p * vec2(1.03,.94));
        float d = base * (1. + .040*sin(3.*azimuth + base*4.) + .028*sin(5.*azimuth-base*2.));
        float advance = clamp((eventTime-.53)/.14,0.,1.);
        float limit = .20 + .76 * advance;
        float wave = .5+.5*cos(50.*d - 31.*advance + .55*sin(8.*p.y));
        float glints = .30+.70*smoothstep(-.5,.8,sin(2.*azimuth+5.*d)+.7*cos(4.*azimuth-6.*d));
        float ring = pow(wave, 3.) * glints;
        float outer = 1.-smoothstep(limit-.15,limit,d);
        float center = exp(-14.*d*d);
        float opacity = outer * (.72*ring + .17*center) * (1.-smoothstep(.68,.79,eventTime));
        if(opacity < .025) discard;
        gl_FragColor=vec4(mix(vec3(.26,.63,.55),vec3(.86,.91,.70),ring),opacity);
        #include <colorspace_fragment>
      }
    `,transparent:!0,depthWrite:!1,side:wt,toneMapped:!1}),n=new Ne(e,t);return n.position.set(-.028,.0026,i),n.renderOrder=5,n}function z_(i){const e=i.meta.anchor,t=new qs([new P(-.0036,.0066,0),new P(-.0056,.0077,0),new P(-.0065,.0091,0),new P(-.0079,.0105,0),new P(-.0098,.0121,0)]),n=[],s=[],r=[],o=48,a=20;for(let u=0;u<=o;u++){const d=u/o,f=t.getPoint(d),g=t.getTangent(d),_=.0013+.0012*d;for(let m=0;m<=a;m++){const p=m/a,y=(2*p-1)*_,x=e.lon+f.x+g.y*y,v=e.lat+f.y-g.x*y,w=i.ground(v,x),M=i.toLocal(x,v,w+.012);if(n.push(M.x,M.y,M.z),s.push(p,d),u&&m){const A=u*(a+1)+m;r.push(A-a-2,A-a-1,A,A-a-2,A,A-1)}}}const l=new it;l.setAttribute("position",new Me(n,3)),l.setAttribute("uv",new Me(s,2)),l.setIndex(r);const c=new nn({uniforms:{eventTime:{value:0}},vertexShader:Ul,fragmentShader:`
      varying vec2 vEventUv; uniform float eventTime;
      void main() {
        float t = vEventUv.y;
        float head = .16 + .95 * smoothstep(.68,.92,eventTime);
        float along = smoothstep(0.,.10,t) * (1. - smoothstep(head-.18,head,t))
                      * (1.-smoothstep(.66,1.,t));
        float x = vEventUv.x*2.-1.;
        float soft = exp(-4.*x*x);
        float strands = .5+.5*cos(13.*x + sin(8.*t - 4.*eventTime));
        float opacity = along * soft * (.35 + .37*strands) * (1.-.32*t);
        if (opacity < .025) discard;
        gl_FragColor = vec4(mix(vec3(.48,.29,.61),vec3(.76,.60,.85),strands),opacity);
        #include <colorspace_fragment>
      }
    `,transparent:!0,depthWrite:!1,side:wt,toneMapped:!1,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2}),h=new Ne(l,c);return h.renderOrder=5,h}class k_{group=new rt;flow;waves;relief;bubbles;bubblePose=new Rt;z;depth;lastTime=-1;lastAnalysis=!1;constructor(e,t){this.z=ut.lerp(t.start,t.end,.52),this.depth=t.depthAt(this.z)*.88,this.flow=F_(this.depth,this.z),this.waves=B_(this.z),this.relief=z_(e),this.bubbles=new qa(new Kn(1,12,8),new nn({vertexShader:`
          varying vec3 bubbleNormal; varying vec3 toEye;
          void main(){
            vec4 p=modelViewMatrix*instanceMatrix*vec4(position,1.);
            bubbleNormal=normalize(normalMatrix*mat3(instanceMatrix)*normal);
            toEye=-p.xyz;
            gl_Position=projectionMatrix*p;
          }`,fragmentShader:`
          varying vec3 bubbleNormal; varying vec3 toEye;
          void main(){
            vec3 n=normalize(bubbleNormal);
            float rim=1.-smoothstep(.10,.72,abs(dot(n,normalize(toEye))));
            float lit=smoothstep(-.36,.30,dot(n,normalize(vec3(-.55,.85,.12))));
            float glint=pow(max(0.,dot(n,normalize(vec3(-.43,.58,.69)))),19.);
            vec3 edge=mix(vec3(.015,.08,.085),vec3(.90,.98,.84),lit);
            vec3 color=mix(vec3(.12,.43,.43),edge,rim);
            gl_FragColor=vec4(mix(color,vec3(.96,1.,.90),glint),clamp(.27+.73*rim+.70*glint,0.,1.));
            #include <colorspace_fragment>
          }`,transparent:!0,depthWrite:!1,toneMapped:!1}),16),this.bubbles.instanceMatrix.setUsage(bd),this.bubbles.frustumCulled=!1,this.bubbles.renderOrder=5,this.group.name="Nyos · historisch orientiertes Erklärungsmodell",this.group.add(this.flow,this.bubbles,this.waves,this.relief),this.update(0,!1,!1)}update(e,t,n){this.group.visible=n;const s=n?ct(e,0,1):0;if(s===this.lastTime&&t===this.lastAnalysis)return;this.lastTime=s,this.lastAnalysis=t,this.flow.visible=s>=.17&&s<.68,this.bubbles.visible=s>=.33&&s<.68,this.waves.visible=s>=.53&&s<.79,this.relief.visible=t&&s>=.68,this.flow.material.uniforms.eventTime.value=s,this.waves.material.uniforms.eventTime.value=s,this.relief.material.uniforms.eventTime.value=s,this.bubbles.count=this.bubbles.visible?Math.min(16,1+Math.floor((s-.33)*90)):0;const r=s-.33;for(let o=0;o<this.bubbles.count;o++){const a=(r*(3.8+.13*(o%4))+o*.381966)%1,l=o*2.39996,c=.0064+.005*a,h=(.042+.07*a)*Math.sin(l+a),u=.28+.72*tt(ct(r/.2,0,1)),d=ut.lerp(-this.depth*.41,-.007,a*u);this.bubblePose.position.set(.0028,d,this.z+h),this.bubblePose.scale.setScalar(c),this.bubblePose.updateMatrix(),this.bubbles.setMatrixAt(o,this.bubblePose.matrix)}this.bubbles.count&&(this.bubbles.instanceMatrix.needsUpdate=!0)}diagnostics(){return{risingWater:this.group.visible&&this.flow.visible,freeBubbles:this.group.visible?this.bubbles.count:0,surfaceRelease:this.group.visible&&this.waves.visible,reliefAnalysis:this.group.visible&&this.relief.visible}}}class V_{view="lake";measure="pipe";progress=0;playing=!1;slow=!1;dissolved=!1;air=!1;select(e){this.view=e,this.measure="pipe",this.dissolved=!1,this.air=!1,this.reset()}reset(){this.progress=0,this.playing=!1,this.slow=!1}togglePlayback(){this.view!=="event"&&!(this.view==="protection"&&this.measure==="pipe")||(this.progress>=1&&(this.progress=0),this.playing=!this.playing)}advance(e){if(!this.playing||!Number.isFinite(e)||e<=0)return;const t=this.view==="event"?24:12;this.progress=Math.min(1,this.progress+e/t*(this.slow?.35:1)),this.progress===1&&(this.playing=!1)}}const dh=new cn,Br=new P;class Yr extends lp{constructor(){super(),this.isLineSegmentsGeometry=!0,this.type="LineSegmentsGeometry";const e=[-1,2,0,1,2,0,-1,1,0,1,1,0,-1,0,0,1,0,0,-1,-1,0,1,-1,0],t=[-1,2,1,2,-1,1,1,1,-1,-1,1,-1,-1,-2,1,-2],n=[0,2,1,2,3,1,2,4,3,4,5,3,4,6,5,6,7,5];this.setIndex(n),this.setAttribute("position",new Me(e,3)),this.setAttribute("uv",new Me(t,2))}applyMatrix4(e){const t=this.attributes.instanceStart,n=this.attributes.instanceEnd;return t!==void 0&&(t.applyMatrix4(e),n.applyMatrix4(e),t.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}setPositions(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));const n=new Ka(t,6,1);return this.setAttribute("instanceStart",new ai(n,3,0)),this.setAttribute("instanceEnd",new ai(n,3,3)),this.instanceCount=this.attributes.instanceStart.count,this.computeBoundingBox(),this.computeBoundingSphere(),this}setColors(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));const n=new Ka(t,6,1);return this.setAttribute("instanceColorStart",new ai(n,3,0)),this.setAttribute("instanceColorEnd",new ai(n,3,3)),this}fromWireframeGeometry(e){return this.setPositions(e.attributes.position.array),this}fromEdgesGeometry(e){return this.setPositions(e.attributes.position.array),this}fromMesh(e){return this.fromWireframeGeometry(new Jf(e.geometry)),this}fromLineSegments(e){const t=e.geometry;return this.setPositions(t.attributes.position.array),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new cn);const e=this.attributes.instanceStart,t=this.attributes.instanceEnd;e!==void 0&&t!==void 0&&(this.boundingBox.setFromBufferAttribute(e),dh.setFromBufferAttribute(t),this.boundingBox.union(dh))}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new wn),this.boundingBox===null&&this.computeBoundingBox();const e=this.attributes.instanceStart,t=this.attributes.instanceEnd;if(e!==void 0&&t!==void 0){const n=this.boundingSphere.center;this.boundingBox.getCenter(n);let s=0;for(let r=0,o=e.count;r<o;r++)Br.fromBufferAttribute(e,r),s=Math.max(s,n.distanceToSquared(Br)),Br.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(Br));this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error("THREE.LineSegmentsGeometry.computeBoundingSphere(): Computed radius is NaN. The instanced position data is likely to have NaN values.",this)}}toJSON(){}}me.line={worldUnits:{value:1},linewidth:{value:1},resolution:{value:new ue(1,1)},dashOffset:{value:0},dashScale:{value:1},dashSize:{value:1},gapSize:{value:1}};Jt.line={uniforms:Ml.merge([me.common,me.fog,me.line]),vertexShader:`
		#include <common>
		#include <color_pars_vertex>
		#include <fog_pars_vertex>
		#include <logdepthbuf_pars_vertex>
		#include <clipping_planes_pars_vertex>

		uniform float linewidth;
		uniform vec2 resolution;

		attribute vec3 instanceStart;
		attribute vec3 instanceEnd;

		attribute vec3 instanceColorStart;
		attribute vec3 instanceColorEnd;

		#ifdef WORLD_UNITS

			varying vec4 worldPos;
			varying vec3 worldStart;
			varying vec3 worldEnd;

			#ifdef USE_DASH

				varying vec2 vUv;

			#endif

		#else

			varying vec2 vUv;

		#endif

		#ifdef USE_DASH

			uniform float dashScale;
			attribute float instanceDistanceStart;
			attribute float instanceDistanceEnd;
			varying float vLineDistance;

		#endif

		void trimSegment( const in vec4 start, inout vec4 end ) {

			// trim end segment so it terminates between the camera plane and the near plane

			// conservative estimate of the near plane
			float a = projectionMatrix[ 2 ][ 2 ]; // 3nd entry in 3th column
			float b = projectionMatrix[ 3 ][ 2 ]; // 3nd entry in 4th column
			float nearEstimate = - 0.5 * b / a;

			float alpha = ( nearEstimate - start.z ) / ( end.z - start.z );

			end.xyz = mix( start.xyz, end.xyz, alpha );

		}

		void main() {

			#ifdef USE_COLOR

				vColor.xyz = ( position.y < 0.5 ) ? instanceColorStart : instanceColorEnd;

			#endif

			#ifdef USE_DASH

				vLineDistance = ( position.y < 0.5 ) ? dashScale * instanceDistanceStart : dashScale * instanceDistanceEnd;
				vUv = uv;

			#endif

			float aspect = resolution.x / resolution.y;

			// camera space
			vec4 start = modelViewMatrix * vec4( instanceStart, 1.0 );
			vec4 end = modelViewMatrix * vec4( instanceEnd, 1.0 );

			#ifdef WORLD_UNITS

				worldStart = start.xyz;
				worldEnd = end.xyz;

			#else

				vUv = uv;

			#endif

			// special case for perspective projection, and segments that terminate either in, or behind, the camera plane
			// clearly the gpu firmware has a way of addressing this issue when projecting into ndc space
			// but we need to perform ndc-space calculations in the shader, so we must address this issue directly
			// perhaps there is a more elegant solution -- WestLangley

			bool perspective = ( projectionMatrix[ 2 ][ 3 ] == - 1.0 ); // 4th entry in the 3rd column

			if ( perspective ) {

				if ( start.z < 0.0 && end.z >= 0.0 ) {

					trimSegment( start, end );

				} else if ( end.z < 0.0 && start.z >= 0.0 ) {

					trimSegment( end, start );

				}

			}

			// clip space
			vec4 clipStart = projectionMatrix * start;
			vec4 clipEnd = projectionMatrix * end;

			// ndc space
			vec3 ndcStart = clipStart.xyz / clipStart.w;
			vec3 ndcEnd = clipEnd.xyz / clipEnd.w;

			// direction
			vec2 dir = ndcEnd.xy - ndcStart.xy;

			// account for clip-space aspect ratio
			dir.x *= aspect;
			dir = normalize( dir );

			#ifdef WORLD_UNITS

				vec3 worldDir = normalize( end.xyz - start.xyz );
				vec3 tmpFwd = normalize( mix( start.xyz, end.xyz, 0.5 ) );
				vec3 worldUp = normalize( cross( worldDir, tmpFwd ) );
				vec3 worldFwd = cross( worldDir, worldUp );
				worldPos = position.y < 0.5 ? start: end;

				// height offset
				float hw = linewidth * 0.5;
				worldPos.xyz += position.x < 0.0 ? hw * worldUp : - hw * worldUp;

				// don't extend the line if we're rendering dashes because we
				// won't be rendering the endcaps
				#ifndef USE_DASH

					// cap extension
					worldPos.xyz += position.y < 0.5 ? - hw * worldDir : hw * worldDir;

					// add width to the box
					worldPos.xyz += worldFwd * hw;

					// endcaps
					if ( position.y > 1.0 || position.y < 0.0 ) {

						worldPos.xyz -= worldFwd * 2.0 * hw;

					}

				#endif

				// project the worldpos
				vec4 clip = projectionMatrix * worldPos;

				// shift the depth of the projected points so the line
				// segments overlap neatly
				vec3 clipPose = ( position.y < 0.5 ) ? ndcStart : ndcEnd;
				clip.z = clipPose.z * clip.w;

			#else

				vec2 offset = vec2( dir.y, - dir.x );
				// undo aspect ratio adjustment
				dir.x /= aspect;
				offset.x /= aspect;

				// sign flip
				if ( position.x < 0.0 ) offset *= - 1.0;

				// endcaps
				if ( position.y < 0.0 ) {

					offset += - dir;

				} else if ( position.y > 1.0 ) {

					offset += dir;

				}

				// adjust for linewidth
				offset *= linewidth;

				// adjust for clip-space to screen-space conversion // maybe resolution should be based on viewport ...
				offset /= resolution.y;

				// select end
				vec4 clip = ( position.y < 0.5 ) ? clipStart : clipEnd;

				// back to clip space
				offset *= clip.w;

				clip.xy += offset;

			#endif

			gl_Position = clip;

			vec4 mvPosition = ( position.y < 0.5 ) ? start : end; // this is an approximation

			#include <logdepthbuf_vertex>
			#include <clipping_planes_vertex>
			#include <fog_vertex>

		}
		`,fragmentShader:`
		uniform vec3 diffuse;
		uniform float opacity;
		uniform float linewidth;

		#ifdef USE_DASH

			uniform float dashOffset;
			uniform float dashSize;
			uniform float gapSize;

		#endif

		varying float vLineDistance;

		#ifdef WORLD_UNITS

			varying vec4 worldPos;
			varying vec3 worldStart;
			varying vec3 worldEnd;

			#ifdef USE_DASH

				varying vec2 vUv;

			#endif

		#else

			varying vec2 vUv;

		#endif

		#include <common>
		#include <color_pars_fragment>
		#include <fog_pars_fragment>
		#include <logdepthbuf_pars_fragment>
		#include <clipping_planes_pars_fragment>

		vec2 closestLineToLine(vec3 p1, vec3 p2, vec3 p3, vec3 p4) {

			float mua;
			float mub;

			vec3 p13 = p1 - p3;
			vec3 p43 = p4 - p3;

			vec3 p21 = p2 - p1;

			float d1343 = dot( p13, p43 );
			float d4321 = dot( p43, p21 );
			float d1321 = dot( p13, p21 );
			float d4343 = dot( p43, p43 );
			float d2121 = dot( p21, p21 );

			float denom = d2121 * d4343 - d4321 * d4321;

			float numer = d1343 * d4321 - d1321 * d4343;

			mua = numer / denom;
			mua = clamp( mua, 0.0, 1.0 );
			mub = ( d1343 + d4321 * ( mua ) ) / d4343;
			mub = clamp( mub, 0.0, 1.0 );

			return vec2( mua, mub );

		}

		void main() {

			float alpha = opacity;
			vec4 diffuseColor = vec4( diffuse, alpha );

			#include <clipping_planes_fragment>

			#ifdef USE_DASH

				if ( vUv.y < - 1.0 || vUv.y > 1.0 ) discard; // discard endcaps

				if ( mod( vLineDistance + dashOffset, dashSize + gapSize ) > dashSize ) discard; // todo - FIX

			#endif

			#ifdef WORLD_UNITS

				// Find the closest points on the view ray and the line segment
				vec3 rayEnd = normalize( worldPos.xyz ) * 1e5;
				vec3 lineDir = worldEnd - worldStart;
				vec2 params = closestLineToLine( worldStart, worldEnd, vec3( 0.0, 0.0, 0.0 ), rayEnd );

				vec3 p1 = worldStart + lineDir * params.x;
				vec3 p2 = rayEnd * params.y;
				vec3 delta = p1 - p2;
				float len = length( delta );
				float norm = len / linewidth;

				#ifndef USE_DASH

					#ifdef USE_ALPHA_TO_COVERAGE

						float dnorm = fwidth( norm );
						alpha = 1.0 - smoothstep( 0.5 - dnorm, 0.5 + dnorm, norm );

					#else

						if ( norm > 0.5 ) {

							discard;

						}

					#endif

				#endif

			#else

				#ifdef USE_ALPHA_TO_COVERAGE

					// artifacts appear on some hardware if a derivative is taken within a conditional
					float a = vUv.x;
					float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
					float len2 = a * a + b * b;
					float dlen = fwidth( len2 );

					if ( abs( vUv.y ) > 1.0 ) {

						alpha = 1.0 - smoothstep( 1.0 - dlen, 1.0 + dlen, len2 );

					}

				#else

					if ( abs( vUv.y ) > 1.0 ) {

						float a = vUv.x;
						float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
						float len2 = a * a + b * b;

						if ( len2 > 1.0 ) discard;

					}

				#endif

			#endif

			#include <logdepthbuf_fragment>
			#include <color_fragment>

			gl_FragColor = vec4( diffuseColor.rgb, alpha );

			#include <tonemapping_fragment>
			#include <colorspace_fragment>
			#include <fog_fragment>
			#include <premultiplied_alpha_fragment>

		}
		`};class fu extends nn{constructor(e){super({type:"LineMaterial",uniforms:Ml.clone(Jt.line.uniforms),vertexShader:Jt.line.vertexShader,fragmentShader:Jt.line.fragmentShader,clipping:!0}),this.isLineMaterial=!0,this.setValues(e)}get color(){return this.uniforms.diffuse.value}set color(e){this.uniforms.diffuse.value=e}get worldUnits(){return"WORLD_UNITS"in this.defines}set worldUnits(e){e===!0?this.defines.WORLD_UNITS="":delete this.defines.WORLD_UNITS}get linewidth(){return this.uniforms.linewidth.value}set linewidth(e){this.uniforms.linewidth&&(this.uniforms.linewidth.value=e)}get dashed(){return"USE_DASH"in this.defines}set dashed(e){e===!0!==this.dashed&&(this.needsUpdate=!0),e===!0?this.defines.USE_DASH="":delete this.defines.USE_DASH}get dashScale(){return this.uniforms.dashScale.value}set dashScale(e){this.uniforms.dashScale.value=e}get dashSize(){return this.uniforms.dashSize.value}set dashSize(e){this.uniforms.dashSize.value=e}get dashOffset(){return this.uniforms.dashOffset.value}set dashOffset(e){this.uniforms.dashOffset.value=e}get gapSize(){return this.uniforms.gapSize.value}set gapSize(e){this.uniforms.gapSize.value=e}get opacity(){return this.uniforms.opacity.value}set opacity(e){this.uniforms&&(this.uniforms.opacity.value=e)}get resolution(){return this.uniforms.resolution.value}set resolution(e){this.uniforms.resolution.value.copy(e)}get alphaToCoverage(){return"USE_ALPHA_TO_COVERAGE"in this.defines}set alphaToCoverage(e){this.defines&&(e===!0!==this.alphaToCoverage&&(this.needsUpdate=!0),e===!0?this.defines.USE_ALPHA_TO_COVERAGE="":delete this.defines.USE_ALPHA_TO_COVERAGE)}}const Qo=new at,fh=new P,ph=new P,Nt=new at,Ot=new at,Tn=new at,ea=new P,ta=new st,Ft=new dp,mh=new P,zr=new cn,kr=new wn,Cn=new at;let Rn,wi;function gh(i,e,t){return Cn.set(0,0,-e,1).applyMatrix4(i.projectionMatrix),Cn.multiplyScalar(1/Cn.w),Cn.x=wi/t.width,Cn.y=wi/t.height,Cn.applyMatrix4(i.projectionMatrixInverse),Cn.multiplyScalar(1/Cn.w),Math.abs(Math.max(Cn.x,Cn.y))}function H_(i,e){const t=i.matrixWorld,n=i.geometry,s=n.attributes.instanceStart,r=n.attributes.instanceEnd,o=Math.min(n.instanceCount,s.count);for(let a=0,l=o;a<l;a++){Ft.start.fromBufferAttribute(s,a),Ft.end.fromBufferAttribute(r,a),Ft.applyMatrix4(t);const c=new P,h=new P;Rn.distanceSqToSegment(Ft.start,Ft.end,h,c),h.distanceTo(c)<wi*.5&&e.push({point:h,pointOnLine:c,distance:Rn.origin.distanceTo(h),object:i,face:null,faceIndex:a,uv:null,uv1:null})}}function G_(i,e,t){const n=e.projectionMatrix,r=i.material.resolution,o=i.matrixWorld,a=i.geometry,l=a.attributes.instanceStart,c=a.attributes.instanceEnd,h=Math.min(a.instanceCount,l.count),u=-e.near;Rn.at(1,Tn),Tn.w=1,Tn.applyMatrix4(e.matrixWorldInverse),Tn.applyMatrix4(n),Tn.multiplyScalar(1/Tn.w),Tn.x*=r.x/2,Tn.y*=r.y/2,Tn.z=0,ea.copy(Tn),ta.multiplyMatrices(e.matrixWorldInverse,o);for(let d=0,f=h;d<f;d++){if(Nt.fromBufferAttribute(l,d),Ot.fromBufferAttribute(c,d),Nt.w=1,Ot.w=1,Nt.applyMatrix4(ta),Ot.applyMatrix4(ta),Nt.z>u&&Ot.z>u)continue;if(Nt.z>u){const x=Nt.z-Ot.z,v=(Nt.z-u)/x;Nt.lerp(Ot,v)}else if(Ot.z>u){const x=Ot.z-Nt.z,v=(Ot.z-u)/x;Ot.lerp(Nt,v)}Nt.applyMatrix4(n),Ot.applyMatrix4(n),Nt.multiplyScalar(1/Nt.w),Ot.multiplyScalar(1/Ot.w),Nt.x*=r.x/2,Nt.y*=r.y/2,Ot.x*=r.x/2,Ot.y*=r.y/2,Ft.start.copy(Nt),Ft.start.z=0,Ft.end.copy(Ot),Ft.end.z=0;const _=Ft.closestPointToPointParameter(ea,!0);Ft.at(_,mh);const m=ut.lerp(Nt.z,Ot.z,_),p=m>=-1&&m<=1,y=ea.distanceTo(mh)<wi*.5;if(p&&y){Ft.start.fromBufferAttribute(l,d),Ft.end.fromBufferAttribute(c,d),Ft.start.applyMatrix4(o),Ft.end.applyMatrix4(o);const x=new P,v=new P;Rn.distanceSqToSegment(Ft.start,Ft.end,v,x),t.push({point:v,pointOnLine:x,distance:Rn.origin.distanceTo(v),object:i,face:null,faceIndex:d,uv:null,uv1:null})}}}class W_ extends Ne{constructor(e=new Yr,t=new fu({color:Math.random()*16777215})){super(e,t),this.isLineSegments2=!0,this.type="LineSegments2"}computeLineDistances(){const e=this.geometry,t=e.attributes.instanceStart,n=e.attributes.instanceEnd,s=new Float32Array(2*t.count);for(let o=0,a=0,l=t.count;o<l;o++,a+=2)fh.fromBufferAttribute(t,o),ph.fromBufferAttribute(n,o),s[a]=a===0?0:s[a-1],s[a+1]=s[a]+fh.distanceTo(ph);const r=new Ka(s,2,1);return e.setAttribute("instanceDistanceStart",new ai(r,1,0)),e.setAttribute("instanceDistanceEnd",new ai(r,1,1)),this}raycast(e,t){const n=this.material.worldUnits,s=e.camera;s===null&&!n&&console.error('LineSegments2: "Raycaster.camera" needs to be set in order to raycast against LineSegments2 while worldUnits is set to false.');const r=e.params.Line2!==void 0&&e.params.Line2.threshold||0;Rn=e.ray;const o=this.matrixWorld,a=this.geometry,l=this.material;wi=l.linewidth+r,a.boundingSphere===null&&a.computeBoundingSphere(),kr.copy(a.boundingSphere).applyMatrix4(o);let c;if(n)c=wi*.5;else{const u=Math.max(s.near,kr.distanceToPoint(Rn.origin));c=gh(s,u,l.resolution)}if(kr.radius+=c,Rn.intersectsSphere(kr)===!1)return;a.boundingBox===null&&a.computeBoundingBox(),zr.copy(a.boundingBox).applyMatrix4(o);let h;if(n)h=wi*.5;else{const u=Math.max(s.near,zr.distanceToPoint(Rn.origin));h=gh(s,u,l.resolution)}zr.expandByScalar(h),Rn.intersectsBox(zr)!==!1&&(n?H_(this,t):G_(this,s,t))}onBeforeRender(e){const t=this.material.uniforms;t&&t.resolution&&(e.getViewport(Qo),this.material.uniforms.resolution.value.set(Qo.z,Qo.w))}}const X_=""+new URL("steps-UiZGQdAy.json",import.meta.url).href,$_=""+new URL("plates-BJQY9lJx.png",import.meta.url).href,q_=[16,12],Y_=[123.574,51.064],j_=[10,-77],K_=[-68.73,-17.49],Z_=[45,24],J_=[24.17,37.881],Q_=[33.398,39.463],ex=[133,-24],tx=[132.715,-.791],nx=[176.66,-15.732],ix=[127.09,-4.834],sx=[94.395,14.15],rx=[-74,15],ox=[140.801,.615],ax=[-93,7],lx=[174.727,-18.545],cx=[-114.17,-25.049],hx=[66,49],ux=[-178.472,-14.806],dx=[-101.602,1.494],fx=[76,16],px=[-127.969,44.561],mx=[-110.654,-32.959],gx=[177.451,-39.111],vx=[145.371,20.479],_x=[150.557,-3.779],xx=[137.812,-4.131],yx=[123.926,-1.494],Mx=[-98,47],Sx=[148.096,-2.9],bx=[-72.158,10.635],wx=[169.893,-16.084],Ex=[-176.133,-16.26],Ax=[-99,-22],Tx=[147,52],Cx=[124.541,24.697],Rx=[-153,-5],Px=[-81.387,9.404],Lx=[136,20],Dx=[-107.842,19.951],Ix=[-57,-16],Ux=[149.062,-5.186],Nx=[-51.592,-55.811],Ox=[-59.678,-62.139],Fx=[51,-15],Bx=[152.051,-7.471],zx=[110.566,8.701],kx=[-26.895,-58.447],Vx=[126.035,-8.174],Hx=[-174.727,-20.303],Gx=[152.402,-9.404],Wx=[116.895,28.389],lo={AF:q_,AM:Y_,AN:j_,AP:K_,AR:Z_,AS:J_,AT:Q_,AU:ex,BH:tx,BR:nx,BS:ix,BU:sx,CA:rx,CL:ox,CO:ax,CR:lx,EA:cx,EU:hx,FT:ux,GP:dx,IN:fx,JF:px,JZ:mx,KE:gx,MA:vx,MN:_x,MO:xx,MS:yx,NA:Mx,NB:Sx,ND:bx,NH:wx,NI:Ex,NZ:Ax,OK:Tx,ON:Cx,PA:Rx,PM:Px,PS:Lx,RI:Dx,SA:Ix,SB:Ux,SC:Nx,SL:Ox,SO:Fx,SS:Bx,SU:zx,SW:kx,TI:Vx,TO:Hx,WL:Gx,YA:Wx};function pu(i,e,t){const n=i.getAttribute("position"),s=new P;for(let r=0;r<n.count;r++){s.fromBufferAttribute(n,r).normalize();const o=Math.asin(s.y)/ke,a=Math.atan2(s.x,s.z)/ke;s.multiplyScalar(Ze+e(o,a)+t),n.setXYZ(r,s.x,s.y,s.z)}return i.computeBoundingSphere(),i}const qn={AF:"Afrikanische Platte",AN:"Antarktische Platte",SO:"Somalische Platte",IN:"Indische Platte",AU:"Australische Platte",EU:"Eurasische Platte",NA:"Nordamerikanische Platte",SA:"Südamerikanische Platte",NZ:"Nazca-Platte",PA:"Pazifische Platte",AR:"Arabische Platte",SU:"Sundaplatte",TI:"Timorplatte",KE:"Kermadecplatte",TO:"Tongaplatte",NI:"Niuafo’ou-Platte",WL:"Woodlarkplatte",MO:"Maokeplatte",SB:"Süd-Bismarck-Platte",SS:"Salomonenseeplatte",NB:"Nord-Bismarck-Platte",NH:"Neue-Hebriden-Platte",CA:"Karibische Platte",CO:"Cocosplatte",OK:"Ochotskplatte",JF:"Juan-de-Fuca-Platte",AP:"Altiplanoplatte",ND:"Nordandenplatte",ON:"Okinawaplatte",PS:"Philippinische Seeplatte",AM:"Amurplatte",CL:"Karolinenplatte",MA:"Marianenplatte",FT:"Futunaplatte",SC:"Scotiaplatte",SL:"Shetlandplatte",AS:"Ägäische Platte",AT:"Anatolische Platte",YA:"Yangtze-Platte",BU:"Burmaplatte",RI:"Riveraplatte",BH:"Vogelkopfplatte",MS:"Molukkenseeplatte",BS:"Banda-Platte",MN:"Manusplatte",CR:"Conway-Riff-Platte",BR:"Balmoral-Riff-Platte",EA:"Osterplatte",JZ:"Juan-Fernández-Platte",GP:"Galápagosplatte",SW:"Süd-Sandwich-Platte",PM:"Panamaplatte"},Xx={divergent:7984843,convergent:15769967,transform:12758510},$x={OSR:"divergent",CRB:"divergent",SUB:"convergent",CCB:"convergent",OCB:"convergent",CTF:"transform",OTF:"transform"};function is(i){const e=$x[i];if(!e)throw Error("Unbekannter PB2002-Grenztyp.");return e}function mu(i){const e=Ke(i[4],i[3]).add(Ke(i[6],i[5])).normalize();return{lat:Math.asin(e.y)/ke,lon:Math.atan2(e.x,e.z)/ke}}const il=["PA","EU","NA","SA","AF","AN","AU","IN"],sl=Object.keys(lo).sort(),qx={island:{EU:Ke(63.88,-18.65,2),NA:Ke(64.55,-24.7,2)},japan:{PA:Ke(38.18,146.15,2),OK:Ke(38.7,141.55,2)},san:{NA:Ke(36.5,-118.75,2),PA:Ke(35.3,-122,2)}},na=[...il,...sl.filter(i=>!il.includes(i))].map(i=>{const[e,t]=lo[i];return{code:i,name:qn[i],point:Ke(t,e,2)}});function Yx(i,e,t,n,s,r="",o,a=!1,l=!1){const c=[],h=s&&n<4e3?qx[s]:void 0,u=r?[...na.filter(d=>d.code===r),...na.filter(d=>d.code!==r)]:na;for(const{code:d,name:f,point:g}of u){if(a&&d!==r||!l&&d!==r&&n>=5e3&&!il.includes(d))continue;const _=d===r&&o?o:h?.[d]??g;if(_.dot(i.position)<=_.lengthSq())continue;const m=Bs(_,i,e,t);m&&c.push({code:d,name:f,...m})}return c}function vh(i,e){const t=[],n=Math.max(1,Math.ceil(i.radians/(.5*ke))),s=new P;for(let r=0;r<=n;r++){s.lerpVectors(i.a,i.b,r/n).normalize();const o=Math.asin(s.y)/ke,a=Math.atan2(s.x,s.z)/ke;s.multiplyScalar(Ze+e(o,a)+2.3),r>0&&t.push(s.x,s.y,s.z),r<n&&t.push(s.x,s.y,s.z)}return t}function _h(i,e,t,n){const s=new fu({color:e,linewidth:t,toneMapped:!1,transparent:!0,depthWrite:!1}),r=new W_(i,s);return r.renderOrder=n,r}async function jx(i=()=>0){const[e,t]=await Promise.all([fetch(X_),new oo().loadAsync($_)]);if(!e.ok)throw t.dispose(),Error("Die lokalen Plattengrenzen fehlen.");const n=await e.json(),s=new rt;s.name="PB2002",s.visible=!1;const r={divergent:[],convergent:[],transform:[]},o=n.map(M=>{const A=Ke(M[4],M[3]).normalize(),T=Ke(M[6],M[5]).normalize(),S={step:M,a:A,b:T,normal:new P().crossVectors(A,T).normalize(),radians:A.angleTo(T)};return r[is(M[2])].push(...vh(S,i)),S}),a=Object.keys(r).map(M=>{const A=new Yr().setPositions(r[M]),T=_h(A,14805717,3.6,3);return T.material.onBeforeCompile=S=>{S.fragmentShader=S.fragmentShader.replace("#include <color_fragment>",`#include <color_fragment>
        float edge = length(vec2(vUv.x, max(abs(vUv.y) - 1., 0.)));
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(.02, .031, .03), smoothstep(.5, .8, edge));`)},s.add(T),{kind:M,line:T}});t.minFilter=t.magFilter=tn,t.generateMipmaps=!1,t.colorSpace=Gn;const l={value:-1},c=new mn({map:t,color:12708245,opacity:.32,transparent:!0,depthWrite:!1,toneMapped:!1});c.onBeforeCompile=M=>{M.uniforms.plateId=l,M.fragmentShader=`uniform float plateId;
`+M.fragmentShader.replace("#include <map_fragment>","if (abs(texture2D(map, vMapUv).r * 255.0 - plateId) > 0.5) discard;")};const h=new Ne(pu(new Kn(Ze,360,180).rotateY(-Math.PI/2),i,1.8),c);h.renderOrder=1,h.visible=!1,s.add(h);const u=_h(new Yr().setPositions([0,0,0,0,0,0]),16774854,6,4);u.visible=!1,s.add(u);let d=null,f=null,g=!1,_=1;function m(M){M&&M!==d&&(u.geometry.dispose(),u.geometry=new Yr().setPositions(vh(o[M[0]-1],i))),d=M,u.visible=!!d&&(!f||is(d[2])===f)}function p(M,A,T,S){g=M,s.visible=g&&_>0,f=T;for(const{kind:b,line:D}of a)D.visible=!T||T===b,D.material.color.setHex(A||T?Xx[b]:14805717);l.value=S?sl.indexOf(S)+1:0,h.visible=l.value>0,m(d)}let y=null;function x(M){if(!y){const U=document.createElement("canvas");if(U.width=t.image.width,U.height=t.image.height,y=U.getContext("2d",{willReadFrequently:!0}),!y)return"";y.drawImage(t.image,0,0)}const{width:A,height:T}=y.canvas,S=(Math.atan2(M.x,M.z)/ke+180)/360,b=(90-Math.asin(M.y)/ke)/180,D=Math.floor(S*A)%A,I=Math.min(T-1,Math.max(0,Math.floor(b*T)));return sl[y.getImageData(D,I,1,1).data[0]-1]??""}function v(M){const A=Math.max(0,Math.min(1,M));if(_!==A){_=A,s.visible=g&&_>0;for(const{line:T}of a)T.material.opacity=_;u.material.opacity=_,c.opacity=.32*_}}function w(M,A){if(!s.visible)return null;const T=M.clone().normalize(),S=new P,b=new P;let D=Math.cos(A),I=null;for(const U of o){if(f&&is(U.step[2])!==f)continue;let B=Math.max(T.dot(U.a),T.dot(U.b));S.copy(T).addScaledVector(U.normal,-T.dot(U.normal)).normalize(),U.radians>1e-9&&b.crossVectors(U.a,S).dot(U.normal)>=0&&b.crossVectors(S,U.b).dot(U.normal)>=0&&(B=Math.max(B,T.dot(S))),B>D&&(D=B,I=U.step)}return I}return{group:s,steps:n,setLayers:p,setOpacity:v,selectStep:m,pick:w,plateAt:x,labels:Yx}}const Kx=""+new URL("mosaic-h8KuBDsq.json",import.meta.url).href,ln=(i,e)=>Math.exp(-i*i/(e*e)),Ct=(i,e)=>.43*Math.sin(i*.53+Math.sin(e*.46))+.29*Math.sin(e*.71-i*.23)+.18*Math.cos(i*1.13+e*.37)+.1*Math.cos(i*2.18-e*1.51);function _i(i,e,t){return i.clone().lerp(e,ut.clamp(t,0,1))}function Zt(i,e,t,n,s,r,o,a,l,c=48){const h=[],u=[],d=[],f=[],g=(v,w)=>ut.lerp(typeof n=="number"?n:n(w),typeof s=="number"?s:s(w),v),_=(v,w,M,A)=>{h.push(v,w,M);const T=A==="top"&&l?l(v,M,w):a.clone(),S=A==="top"?.055*Ct(v*1.6,M*1.6):.085*Math.sin(w*3.9+.38*Math.sin(v*.46+M*.19))+.055*Ct(v+M,w);T.multiplyScalar((1+S)*(A==="top"?1:.88+.12*Math.min(1,Math.max(0,w)/10))),u.push(T.r,T.g,T.b),d.push((A==="end"?M:v)*.17,(A==="top"||A==="bottom"?M:w)*.17)};function m(v,w,M,A){const T=h.length/3;for(let S=0;S<=w;S++)for(let b=0;b<=v;b++)A(b/v,S/w);for(let S=0;S<w;S++)for(let b=0;b<v;b++){const D=T+S*(v+1)+b,I=D+1,U=D+v+1,B=U+1;M?f.push(D,U,I,I,U,B):f.push(D,I,U,I,B,U)}}const p=v=>-9+18*v;for(const[v,w]of[[r,!0],[o,!1]])m(c,24,w,(M,A)=>{const T=p(A),S=g(M,T);_(S,v(S,T),T,w?"top":"bottom")});for(const v of[-9,9])m(c,6,v<0,(w,M)=>{const A=g(w,v);_(A,ut.lerp(o(A,v),r(A,v),M),v,"front")});for(const v of[0,1])m(24,6,v===1,(w,M)=>{const A=p(w),T=g(v,A);_(T,ut.lerp(o(T,A),r(T,A),M),A,"end")});const y=new it;y.setAttribute("position",new Me(h,3)),y.setAttribute("color",new Me(u,3)),y.setAttribute("uv",new Me(d,2)),y.setIndex(f),y.computeVertexNormals();const x=new Ne(y,t);return x.name=e,i.add(x),x}function gu(){const e=new Uint8Array(36864);let t=51;for(let s=0;s<e.length;s+=4){t=Math.imul(1664525,t)+1013904223>>>0;const r=226+(t>>>27)*.85;e.set([r,r,r,255],s)}const n=new $h(e,96,96);return n.wrapS=n.wrapT=zs,n.generateMipmaps=!0,n.magFilter=Sn,n.minFilter=oi,n.colorSpace=Wt,n.needsUpdate=!0,n}function Zx(i,e,t,n,s,r,o=6.5){const a=new rt,l=new ir;l.moveTo(-o/2,-.4),l.lineTo(o/2-2.25,-.4),l.lineTo(o/2-2.25,-1.28),l.lineTo(o/2,0),l.lineTo(o/2-2.25,1.28),l.lineTo(o/2-2.25,.4),l.lineTo(-o/2,.4),l.closePath();const c=new Rl(l,{depth:.12,bevelEnabled:!0,bevelThickness:.06,bevelSize:.07,bevelSegments:1});c.rotateX(-Math.PI/2);const h=new Ne(c,e);h.scale.set(1.06,1.1,1.22);const u=new Ne(c,i);return u.position.y=.08,a.add(h,u),a.rotation.y=-r,a.position.set(t,n,s),a}function Ts(i,e,t,n,s){const r=new Zs(new qs(n),28,s,6,!1),o=new Ne(r,t);return o.name=e,i.add(o),o}function xh(i){return Ke(i[0],i[1]).normalize().multiplyScalar(i[2]*ke)}class Jx{constructor(e,t,n){this.step=e,this.site=mu(e);const{up:s,east:r,north:o}=$n(this.site.lat,this.site.lon),a=Ke(e[6],e[5]).sub(Ke(e[4],e[3])).normalize();this.right=a.clone().cross(s).normalize();const l=s.clone().cross(this.right);this.heading=-Math.atan2(l.dot(r),l.dot(o))/ke+12;const c=xh(t[0]).sub(xh(t[1]));this.axis=c.clone().normalize();const h=c.clone().cross(s).normalize(),u=this.axis.clone().cross(s).length()*Ze,d=ct(u/450,.7,9);this.span=d*22,this.angle=Math.min(.12,d*12/u);const f=this.angle*u/d,g=2.5+Math.max(0,h.dot(this.right))*f,_=[e[1].slice(0,2),e[1].slice(-2)],m=(w,M,A)=>s.clone().multiplyScalar(Ze).addScaledVector(this.right,w*d).addScaledVector(l,-A*d).setLength(Ze+d*M),p=[],y=[],x=[];for(let w=0;w<=12;w++)for(let M=0;M<=96;M++){const A=2*Math.PI*M/96,T=w/12;p.push(...m(29*T*Math.cos(A),.4,23*T*Math.sin(A)).toArray());const S=new Oe(5591111);if(S.multiplyScalar(1+.08*Ct(18*T*Math.cos(A),15*T*Math.sin(A))),x.push(S.r,S.g,S.b,1-ut.smoothstep(T,.66,1)),w&&M){const b=w*97+M;y.push(b-98,b-1,b,b-98,b,b-97)}}const v=new it;v.setAttribute("position",new Me(p,3)),v.setAttribute("color",new Me(x,4)),v.setIndex(y),v.computeVertexNormals(),this.group.add(new Ne(v,new gn({vertexColors:!0,transparent:!0,depthWrite:!1,roughness:1,side:wt}))),this.bodies=_.map((w,M)=>{const A=(M===0?-1:1)*(g/2+5.7),T=new gn({map:this.texture,vertexColors:!0,roughness:.94}),S=n[M],b=(Q,re)=>re-(3+.12*Q+.32*Math.sin(.65*Q)),D=(Q,re)=>3.7+.42*Ct(Q*.7,re*.9)+.2*Math.exp(-(b(Q,re)**2)),I=new Oe(16048829),U=new Oe(5326910),B=(Q,re)=>{const ge=b(Q,re);return S.clone().multiplyScalar(.7+.22*Ct(Q*.8,re*.6)).lerp(U,.62*Math.exp(-((ge+.95)**2)/.36)).lerp(I,.89*Math.exp(-(ge**2)/.72))},k=Q=>Math.max(0,Math.abs(Q)-7.2)*.38,V=Q=>.37*Math.sin(Q*.47)+.16*Math.sin(Q*1.23),te=Zt(this.group,w,T,Q=>A-5.7+k(Q)+V(Q),Q=>A+5.7-k(Q)+V(Q),D,()=>.32,S.clone().lerp(U,.68),B,26),H=te.geometry.getAttribute("position");for(let Q=0;Q<H.count;Q++){const re=m(H.getX(Q),H.getY(Q),H.getZ(Q));H.setXYZ(Q,re.x,re.y,re.z)}return te.geometry.computeVertexNormals(),te.geometry.computeBoundingSphere(),this.centres.push(m(A+(M===0?-1:1)*2.8,4,-6.7)),this.samples.push([0,18,237,456,475].map(Q=>new P().fromBufferAttribute(H,Q))),te})}group=new rt;site;heading;span;bodies;axis;angle;right;centres=[];samples=[];texture=gu();progress=0;setTime(e){this.progress=e,this.bodies.forEach((t,n)=>t.quaternion.setFromAxisAngle(this.axis,(n===0?.5:-.5)*e*this.angle)),this.group.updateMatrixWorld(!0)}labels(e,t,n){return this.bodies.flatMap((s,r)=>{const o=s.localToWorld(this.centres[r].clone()),a=Bs(o,e,t,n);return a&&o.dot(e.position.clone().sub(o))>0?[{code:s.name,name:qn[s.name],...a}]:[]})}diagnostics(e,t,n){return{step:this.step[0],progress:this.progress,site:this.site,angle:this.angle,right:this.right.toArray(),axis:this.axis.toArray(),labels:this.labels(e,t,n),bodies:this.bodies.map((s,r)=>({code:s.name,quaternion:s.quaternion.toArray(),points:this.samples[r].map(o=>s.localToWorld(o.clone()).toArray())}))}}fadeOut(e){for(const t of this.group.children)t instanceof Ne&&(t.material.transparent=!0,t.material.opacity=e,t.material.depthWrite=!1)}dispose(){this.group.removeFromParent(),this.group.traverse(e=>{e instanceof Ne&&(e.geometry.dispose(),e.material.dispose())}),this.texture.dispose()}}const Vr=[11057562,12952453,8694960,12299651,9018803,12031389,10333829,9876392,11903414,12759438];class Qx{group=new rt;surfaces=[];extents=new Map;colors={};poles=new Map;toneKey;pair;leaving;fade=0;cover;reveal={value:0};axis={value:new P};opening=0;progress=0;playing=!1;slow=!1;selected="";constructor(e,t,n){const s=this.colors;for(const a of Object.keys(e).sort((l,c)=>(n.get(c)?.size??0)-(n.get(l)?.size??0))){const l=new Set([...n.get(a)??[]].map(h=>s[h])),c=a.charCodeAt(0)*11+a.charCodeAt(1);s[a]=Vr.map((h,u)=>Vr[(u+c)%Vr.length]).find(h=>!l.has(h))??Vr[0]}for(const[a,l]of Object.entries(e)){this.poles.set(a,l.pole);const[c,h]=lo[a],u=Ke(h,c).normalize();let d=0;const f=[],g=[],_=[],m=[],p=[...l.triangles],y=new Oe(s[a]),x=new Oe,v=new P;for(let T=0;T<l.vertices.length;T+=3){const S=l.vertices[T]/1e5,b=l.vertices[T+1]/1e5,D=l.vertices[T+2]/1e4;v.copy(Ke(b,S)).normalize(),g.push(v.x,v.y,v.z),d=Math.max(d,u.angleTo(v));const I=Ze-4;f.push(v.x*I,v.y*I,v.z*I),_.push((S+180)/360,(b+90)/180),x.copy(y).multiplyScalar(.78+.22*Math.min(1,D/.45)),m.push(x.r,x.g,x.b)}for(let T=0;T<l.rim.length;T+=2){const S=l.rim[T],b=l.rim[T+1],D=f.length/3,I=new P().fromArray(f,3*b).sub(new P().fromArray(f,3*S)).cross(v.fromArray(g,3*S)).normalize();for(const[U,B]of[[0,.72],[.0035,.7],[.004,.48],[.026,.4]])for(const k of[S,b])v.fromArray(f,3*k).multiplyScalar(1-U),f.push(v.x,v.y,v.z),g.push(I.x,I.y,I.z),_.push(_[2*k],_[2*k+1]),x.copy(y).multiplyScalar(B),m.push(x.r,x.g,x.b);for(let U=0;U<3;U++){const B=D+2*U;p.push(B,B+1,B+2,B+1,B+3,B+2)}}const w=new it;for(const[T,S,b]of[["position",f,3],["normal",g,3],["uv",_,2],["color",m,3]])w.setAttribute(T,new Me(S,b));w.setIndex(p);const M=new gn({map:t,vertexColors:!0,roughness:.92,side:wt});M.onBeforeCompile=T=>{T.fragmentShader=T.fragmentShader.replace("#include <map_fragment>",`
        vec3 relief = texture2D(map, vMapUv).rgb;
        float tone = dot(relief, vec3(0.21,0.72,0.07));
        diffuseColor.rgb *= (0.53 + 1.08 * sqrt(tone));
      `)};const A=new Ne(w,M);A.name=a,this.surfaces.push(A),this.group.add(A),this.extents.set(a,d)}const r=new Ne(new Kn(Ze*.969,100,64),new gn({color:7497561,roughness:1}));this.group.add(r);const o=new gn({map:t,roughness:.94});o.onBeforeCompile=a=>{a.uniforms.reveal=this.reveal,a.uniforms.sweepAxis=this.axis,a.vertexShader=`uniform float reveal; uniform vec3 sweepAxis; varying float edge;
`+a.vertexShader.replace("#include <begin_vertex>",`
        vec3 dir=normalize(position); edge=dot(dir,sweepAxis) - (1.01-2.02*reveal);
        float lift=1.-smoothstep(0.,.17,abs(edge));
        vec3 transformed=position+dir*(4.+140.*lift*sin(3.14159*reveal));
      `),a.fragmentShader=`varying float edge;
`+a.fragmentShader.replace("#include <clipping_planes_fragment>",`#include <clipping_planes_fragment>
if(edge>0.) discard;`)},this.cover=new Ne(new Kn(Ze+4,144,96).rotateY(-Math.PI/2),o),this.group.add(this.cover),this.group.visible=!1}open(e,t){this.axis.value.copy(e).normalize(),this.opening=this.reveal.value=t?1:0,this.cover.visible=!t,this.group.visible=!0}close(){this.clearAnchor(),this.endPair(),this.leaving?.dispose(),this.leaving=void 0,this.group.visible=!1,this.slow=!1,this.selected=""}beginPair(e){this.endPair();const t=[e[1].slice(0,2),e[1].slice(-2)];return this.pair=new Jx(e,t.map(n=>this.poles.get(n)),t.map(n=>new Oe(this.colors[n]))),this.group.add(this.pair.group),this.reset(),this.pair}endPair(e=!1){this.pair&&(this.leaving?.dispose(),this.leaving=void 0,e?(this.leaving=this.pair,this.fade=1):this.pair.dispose()),this.pair=void 0,this.progress=0,this.playing=!1}reset(){this.progress=0,this.playing=!1,this.pair?.setTime(0)}play(){this.pair&&(this.progress>=1&&this.reset(),this.playing=!this.playing)}tick(e,t,n){if(!this.group.visible)return;this.leaving&&(this.fade=t?0:Math.max(0,this.fade-e/.35),this.leaving.fadeOut(this.fade),this.fade||(this.leaving.dispose(),this.leaving=void 0)),this.opening<1&&(this.opening=t?1:Math.min(1,this.opening+e/1.65),this.reveal.value=tt(this.opening),this.cover.visible=this.opening<1),this.playing&&!n&&(this.progress=ct(this.progress+e/(this.slow?26:9),0,1),this.progress===1&&(this.playing=!1),this.pair?.setTime(this.progress));const s=this.selected+"/"+(this.pair?.step[0]??"");if(this.toneKey!==s){this.toneKey=s;for(const r of this.surfaces){const o=this.pair?this.pair.bodies.some(a=>a.name===r.name):r.name===this.selected;r.material.color.setScalar(!this.selected&&!this.pair?1:o?1.15:.67)}}}pick(e){return e.intersectObjects(this.surfaces,!1)[0]}tracked;clearAnchor(){this.tracked=void 0}track(e){if(!e.face)return;const t=this.surfaces.find(a=>a===e.object);if(!t)return;const{a:n,b:s,c:r}=e.face,o=new P;pn.getBarycoord(t.worldToLocal(e.point.clone()),t.getVertexPosition(n,new P),t.getVertexPosition(s,new P),t.getVertexPosition(r,new P),o),this.tracked={mesh:t,face:e.face,weights:o}}get annotationPose(){return this.progress}anchor(){if(!this.tracked||this.tracked.mesh.name!==this.selected)return;const{mesh:e,face:t,weights:n}=this.tracked,s=e.getVertexPosition(t.a,new P).multiplyScalar(n.x);return s.addScaledVector(e.getVertexPosition(t.b,new P),n.y),s.addScaledVector(e.getVertexPosition(t.c,new P),n.z),e.localToWorld(s)}diagnostics(e,t,n){return{opening:this.opening,progress:this.progress,playing:this.playing,visible:this.group.visible,pair:this.pair?.diagnostics(e,t,n)??null}}}const ey={step:5502,where:"Im Ostafrikanischen Graben"},ty={step:3621,where:"Am Baikalsee"},ny={step:951,where:"Am Meeresrücken südlich von Australien"},iy={step:3841,where:"In den zentralen Anden"},sy={step:1367,where:"Im Zagrosgebirge"},ry={step:5447,where:"Südlich von Kreta"},oy={step:3480,where:"An der Nordanatolischen Verwerfung"},ay={step:1439,where:"Auf Neuseelands Südinsel"},ly={step:4121,where:"Im Westen von Neuguinea"},cy={step:4835,where:"Am Meeresrücken westlich von Fidschi"},hy={step:4078,where:"Im Gebiet der Bandasee"},uy={step:4155,where:"Im Meer westlich der Andamanen"},dy={step:1872,where:"Im Norden der Karibik"},fy={step:4478,where:"Am Rand der Karolinen"},py={step:1956,where:"Vor Mexikos Pazifikküste"},my={step:4887,where:"Südwestlich von Fidschi"},gy={step:5011,where:"Am Meeresrücken bei der Osterinsel"},vy={step:4209,where:"Auf Island"},_y={step:3253,where:"Im Meer bei Futuna"},xy={step:5098,where:"Westlich der Galápagosinseln"},yy={step:2092,where:"Im Himalaya"},My={step:2724,where:"Vor der Westküste Nordamerikas"},Sy={step:5033,where:"Am Meeresrücken weit vor Chile"},by={step:1482,where:"Bei den Kermadecinseln"},wy={step:3210,where:"Am Marianengraben"},Ey={step:4619,where:"Im Bismarckmeer"},Ay={step:4111,where:"Auf Neuguinea"},Ty={step:3993,where:"In der Molukkensee"},Cy={step:2877,where:"Bei Kalifornien"},Ry={step:4576,where:"Im Bismarckmeer"},Py={step:3129,where:"Vor der Küste Ecuadors"},Ly={step:1765,where:"Bei Vanuatu"},Dy={step:3299,where:"Westlich von Tonga"},Iy={step:3080,where:"Vor der Küste Chiles"},Uy={step:2629,where:"Vor Japan"},Ny={step:3141,where:"Bei den Ryūkyū-Inseln"},Oy={step:2877,where:"Bei Kalifornien"},Fy={step:5668,where:"Vor der Pazifikküste Mittelamerikas"},By={step:3233,where:"Am Tiefseegraben südlich von Japan"},zy={step:3928,where:"Vor der Westküste Mexikos"},ky={step:3080,where:"Vor der Küste Chiles"},Vy={step:4576,where:"Im Bismarckmeer"},Hy={step:5223,where:"Westlich der Südlichen Sandwichinseln"},Gy={step:3385,where:"Bei den Südlichen Shetlandinseln"},Wy={step:5502,where:"Im Ostafrikanischen Graben"},Xy={step:1601,where:"Vor Neubritannien"},$y={step:1386,where:"Vor Java"},qy={step:5261,where:"Östlich der Südlichen Sandwichinseln"},Yy={step:1416,where:"Im Gebiet von Timor"},jy={step:1509,where:"Am Tongagraben"},Ky={step:4680,where:"Im Woodlark-Becken östlich von Neuguinea"},Zy={step:4407,where:"Im Meer nordwestlich der Ryūkyū-Inseln"},Jy={AF:ey,AM:ty,AN:ny,AP:iy,AR:sy,AS:ry,AT:oy,AU:ay,BH:ly,BR:cy,BS:hy,BU:uy,CA:dy,CL:fy,CO:py,CR:my,EA:gy,EU:vy,FT:_y,GP:xy,IN:yy,JF:My,JZ:Sy,KE:by,MA:wy,MN:Ey,MO:Ay,MS:Ty,NA:Cy,NB:Ry,ND:Py,NH:Ly,NI:Dy,NZ:Iy,OK:Uy,ON:Ny,PA:Oy,PM:Fy,PS:By,RI:zy,SA:ky,SB:Vy,SC:Hy,SL:Gy,SO:Wy,SS:Xy,SU:$y,SW:qy,TI:Yy,TO:jy,WL:Ky,YA:Zy},Qy={AF:"Sie trägt große Teile Afrikas und angrenzenden Meeresboden.",AM:"Sie liegt im Osten Asiens, unter anderem unter Teilen Nordostchinas.",AN:"Sie trägt die Antarktis und den Meeresboden rings um den Kontinent.",AP:"Sie liegt unter einem Teil des Hochlands der zentralen Anden.",AR:"Sie trägt die Arabische Halbinsel und Teile des angrenzenden Meeresbodens.",AS:"Sie liegt im Raum der Ägäis zwischen Griechenland und der Türkei.",AT:"Sie liegt unter einem großen Teil der Türkei.",AU:"Sie trägt Australien und weite Teile des umliegenden Meeresbodens.",BH:"Sie liegt am westlichen Ende Neuguineas, bei der Vogelkop-Halbinsel.",BR:"Sie liegt im südwestlichen Pazifik westlich von Fidschi.",BS:"Sie liegt im Osten Indonesiens im Bereich der Bandasee.",BU:"Sie liegt an der Ostseite des Golfs von Bengalen, vor Myanmar und Sumatra.",CA:"Sie liegt unter einem großen Teil des Karibischen Meeres.",CL:"Sie liegt im westlichen Pazifik im Gebiet der Karolinen.",CO:"Sie liegt im Pazifik vor der Westküste Mittelamerikas.",CR:"Sie liegt im südwestlichen Pazifik beim Conway-Riff.",EA:"Sie liegt am Ostpazifischen Rücken im Gebiet der Osterinsel.",EU:"Sie trägt große Teile Europas und Asiens sowie angrenzenden Meeresboden.",FT:"Sie liegt im südwestlichen Pazifik im Gebiet von Futuna.",GP:"Sie liegt an einem Rücken im östlichen Pazifik westlich der Galápagosinseln.",IN:"Sie trägt Indien und einen Teil des nördlichen Indischen Ozeans.",JF:"Sie liegt vor der Westküste Nordamerikas bei Oregon und Washington.",JZ:"Sie liegt an einem Rücken im südöstlichen Pazifik weit vor Chile.",KE:"Sie liegt im südwestlichen Pazifik bei den Kermadecinseln.",MA:"Sie liegt im westlichen Pazifik bei den Marianen.",MN:"Sie liegt im Bismarckmeer nordöstlich von Neuguinea.",MO:"Sie liegt im Inneren des westlichen Neuguinea.",MS:"Sie liegt in der Molukkensee im Osten Indonesiens.",NA:"Sie trägt große Teile Nordamerikas und reicht bis in den Atlantik.",NB:"Sie liegt nördlich von Neubritannien im Bismarckmeer.",ND:"Sie liegt am nordwestlichen Rand Südamerikas im Bereich der Anden.",NH:"Sie liegt im südwestlichen Pazifik bei Vanuatu.",NI:"Sie liegt im südwestlichen Pazifik bei der Insel Niuafo’ou.",NZ:"Sie liegt im östlichen Pazifik vor der Westküste Südamerikas.",OK:"Sie liegt im Gebiet des Ochotskischen Meeres und reicht bis nach Japan.",ON:"Sie liegt im Gebiet der Ryūkyū-Inseln südwestlich der japanischen Hauptinseln.",PA:"Sie liegt unter einem großen Teil des Pazifischen Ozeans.",PM:"Sie liegt bei Panama zwischen Mittel- und Südamerika.",PS:"Sie liegt unter der Philippinensee östlich der Philippinen.",RI:"Sie liegt vor der Westküste Mexikos.",SA:"Sie trägt große Teile Südamerikas und reicht bis in den Atlantik.",SB:"Sie liegt zwischen der Nordküste Neuguineas und Neubritannien.",SC:"Sie liegt zwischen der Südspitze Südamerikas und der Antarktis.",SL:"Sie liegt bei den Südlichen Shetlandinseln vor der Antarktischen Halbinsel.",SO:"Sie trägt Teile Ostafrikas und angrenzenden Meeresboden im Indischen Ozean.",SS:"Sie liegt in der Salomonensee östlich von Neuguinea.",SU:"Sie liegt in Südostasien und trägt Teile des Festlands und der Inselwelt.",SW:"Sie liegt im Südatlantik bei den Südlichen Sandwichinseln.",TI:"Sie liegt im Gebiet von Timor am Rand Indonesiens.",TO:"Sie liegt im südwestlichen Pazifik bei Tonga.",WL:"Sie liegt im Gebiet des Woodlark-Beckens östlich von Neuguinea.",YA:"Sie liegt unter Teilen des östlichen und südlichen Chinas."},eM=["Norden","Nordosten","Osten","Südosten","Süden","Südwesten","Westen","Nordwesten"],tM={OSR:"Hier weichen beide Seiten auseinander. Aus aufsteigender Schmelze entsteht neuer Ozeanboden.",CRB:"Hier wird die Erdkruste gedehnt. Dabei können Gräben entstehen.",SUB:"Hier taucht eine Platte unter die andere ab. Dabei können starke Erdbeben entstehen.",OCB:"Hier kommen die Platten unter dem Meer aufeinander zu. Dabei wird Gestein zusammengeschoben.",CCB:"Hier wird Gestein auf dem Kontinent zusammengeschoben. Dadurch kann sich das Land heben.",OTF:"Hier gleiten die Platten am Meeresboden seitlich aneinander vorbei. Dabei können Erdbeben entstehen.",CTF:"Hier gleiten die Platten an Land seitlich aneinander vorbei. Dabei können Erdbeben entstehen."},nM={2092:"Hier stoßen zwei Kontinente zusammen. Dabei hebt sich der Himalaya.",3080:"Hier taucht die Nazca-Platte unter Südamerika ab. Dabei können starke Erdbeben entstehen.",2629:"Hier taucht die Pazifische Platte unter die Ochotskplatte ab. Dabei können starke Erdbeben entstehen.",4209:"Hier rücken die Platten auseinander. Aufsteigende Schmelze kühlt ab und bildet neue Kruste.",2877:"An der San-Andreas-Verwerfung gleiten die Seiten aneinander vorbei. Wenn sie sich ruckartig lösen, bebt die Erde.",1439:"An der Alpenverwerfung gleiten die Seiten schräg aneinander vorbei. Dabei werden die Südalpen angehoben.",5502:"Hier wird die Erdkruste gedehnt. Entlang von Brüchen sinken Teile des Bodens ab."};function iM(i,e){return Object.fromEntries(Object.entries(Jy).map(([t,n])=>{const s=i[n.step-1],r=s[1].slice(0,2),o=s[1].slice(-2);if(t!==r&&t!==o)throw Error("Ungültige Zuordnung für "+t);const a=r===t?o:r,l=e[a].replace(/e (Platte|Seeplatte)$/,"en $1"),c=eM[Math.round((s[8]+(r===t?0:180))/45)%8];return[t,{...n,neighbour:a,place:Qy[t],motion:`${n.where} bewegt sie sich gegenüber der ${l} nach ${c}.`,boundary:nM[n.step]??tM[s[2]]}]}))}const ss={side:32,back:21,front:36};class sM{frame={value:new st};reveal={value:0};attached=new WeakSet;active;attach(e){if(this.attached.has(e))return;this.attached.add(e);const t=e.onBeforeCompile.bind(e),n=e.customProgramCacheKey();e.customProgramCacheKey=()=>n+"-section-window",e.onBeforeCompile=(s,r)=>{t(s,r),Object.assign(s.uniforms,{sectionFrame:this.frame,sectionReveal:this.reveal}),s.vertexShader=`uniform mat4 sectionFrame; uniform float sectionReveal; varying vec3 vSection;
`+s.vertexShader.replace("#include <project_vertex>",`#include <project_vertex>
 vSection = sectionReveal > 0. ? (sectionFrame * modelMatrix * vec4(transformed,1.)).xyz : vec3(0.);`),s.fragmentShader=`uniform float sectionReveal; varying vec3 vSection;
`+s.fragmentShader.replace("#include <clipping_planes_fragment>",`#include <clipping_planes_fragment>
        if (sectionReveal > 0. && abs(vSection.y) < 35. && abs(vSection.x) < ${ss.side-3}. &&
            vSection.z > -${ss.back-3}. && vSection.z < ${ss.front-5}.) {
          float noise = fract(52.9829189 * fract(dot(floor(gl_FragCoord.xy),vec2(.06711056,.00583715))));
          if (noise < sectionReveal) discard;
        }`)},e.needsUpdate=!0}show(e,t){this.reveal.value=e?t:0,e&&e!==this.active&&(e.updateWorldMatrix(!0,!1),this.frame.value.copy(e.matrixWorld).invert()),this.active=e}}const rM=""+new URL("island-Cq9i3D8N.webp",import.meta.url).href,oM=""+new URL("japan-CPQM02HR.webp",import.meta.url).href,aM=""+new URL("san-CyR3_p9s.webp",import.meta.url).href,yh=[{id:"island",url:rM,west:-40.5,north:76.5,width:36,height:22.5},{id:"japan",url:oM,west:126,north:49.5,width:31.5,height:22.5},{id:"san",url:aM,west:-135,north:45,width:31.5,height:22.5}];async function lM(i=()=>0){const e=await Promise.allSettled(yh.map(async s=>{const r=await new oo().loadAsync(s.url);r.colorSpace=Wt,r.anisotropy=4;const o=new Kn(Ze,Math.ceil(s.width*3),Math.ceil(s.height*3),(s.west+180)*ke,s.width*ke,(90-s.north)*ke,s.height*ke).rotateY(-Math.PI/2),a=new Ps({map:r,transparent:!0,depthWrite:!1});a.onBeforeCompile=c=>{c.fragmentShader=c.fragmentShader.replace("#include <map_fragment>",`#include <map_fragment>
        float luma = dot(diffuseColor.rgb, vec3(.2126, .7152, .0722));
        float blue = diffuseColor.b - max(diffuseColor.r, diffuseColor.g);
        float water = smoothstep(0., .003, blue) * (1. - smoothstep(.015, .07, luma));
        diffuseColor.rgb += water * (.28 * sqrt(diffuseColor.rgb) + vec3(.002, .006, .014));`)};const l=new Ne(pu(o,i,.75),a);return l.name=s.id,l.userData.image={bounds:s,map:r},l.renderOrder=.5,l})),t=new rt,n=[];for(const[s,r]of e.entries())r.status==="fulfilled"?t.add(r.value):n.push(yh[s].id);if(!t.children.length)throw Error("Die regionalen Bildmosaike fehlen.");return t.userData.missing=n,t}class cM{constructor(e){this.mesh=e;const t=e.geometry,n=t.getAttribute("position"),s=t.morphAttributes.position?.[0];t.computeBoundingBox();const r=t.boundingBox,o=r.getSize(new P),a=10,l=5,c=new Map,h=(f,g,_,m)=>ut.clamp(Math.floor(m*(f-g)/(_||1)),0,m-1),u=t.getIndex(),d=new cn;for(let f=0;f<(u?.count??n.count);f+=3){d.makeEmpty();for(let p=0;p<3;p++){const y=u?u.getX(f+p):f+p;this.a.fromBufferAttribute(n,y),d.expandByPoint(this.a),s&&(this.b.fromBufferAttribute(s,y),t.morphTargetsRelative||this.b.sub(this.a),d.expandByPoint(this.c.copy(this.a).add(this.b)),d.expandByPoint(this.c.copy(this.a).sub(this.b)))}const g=d.getCenter(this.a),_=h(g.x,r.min.x,o.x,a)+a*h(g.z,r.min.z,o.z,l);let m=c.get(_);m||(m={bounds:new cn,triangles:[]},c.set(_,m)),m.bounds.union(d),m.triangles.push(f)}this.cells=[...c.values()]}cells=[];work={rays:0,triangles:0,reused:0,inversions:0,morphChanges:0};revision=0;matrix=new st;eye=new P(1/0,1/0,1/0);morph=NaN;memo=new Map;inverse=new st;ray=new io;end=new P;hit=new P;a=new P;b=new P;c=new P;prepare(e){const t=!this.revision||!this.matrix.equals(this.mesh.matrixWorld),n=this.mesh.morphTargetInfluences?.[0]??0;!t&&n===this.morph&&this.eye.equals(e)||(t&&(this.inverse.copy(this.matrix.copy(this.mesh.matrixWorld)).invert(),this.work.inversions++),n!==this.morph&&this.work.morphChanges++,this.morph=n,this.ray.origin.copy(this.eye.copy(e)).applyMatrix4(this.inverse),this.revision++)}blocks(e,t){if(!t)return this.trace(e);let n=this.memo.get(t);return n?.revision===this.revision&&n.end.equals(e)?(this.work.reused++,n.blocked):(n||(n={revision:0,end:new P,blocked:!1},this.memo.set(t,n)),n.end.copy(e),n.revision=this.revision,n.blocked=this.trace(e))}trace(e){this.work.rays++,this.end.copy(e).applyMatrix4(this.inverse),this.ray.direction.subVectors(this.end,this.ray.origin);const t=this.ray.direction.lengthSq();this.ray.direction.normalize();const n=this.mesh.geometry.index;for(const s of this.cells)if(!(!s.bounds.containsPoint(this.ray.origin)&&(!this.ray.intersectBox(s.bounds,this.hit)||this.ray.origin.distanceToSquared(this.hit)>t))){for(const r of s.triangles)if(this.work.triangles++,this.mesh.getVertexPosition(n?n.getX(r):r,this.a),this.mesh.getVertexPosition(n?n.getX(r+1):r+1,this.b),this.mesh.getVertexPosition(n?n.getX(r+2):r+2,this.c),this.ray.intersectTriangle(this.a,this.b,this.c,this.mesh.material.side===jn,this.hit)&&this.ray.origin.distanceToSquared(this.hit)<t)return!0}return!1}}function hM(i,e,t,n){const s=[],r=[],o=[],a=[],l=[],u=new P(0,1,0).transformDirection(i.matrixWorld),d=new Za;for(let g=0;g<=80;g++){const _=g/80*2*Math.PI,m=Math.cos(_),p=Math.sin(_),y=1/Math.max(Math.abs(m),Math.abs(p)),x=21*y*m,v=9*y*p,w=i.localToWorld(new P(x*.992,25,v*.992));d.set(w,u.clone().negate());const M=d.intersectObjects(e,!1),A=M.length?25-M[0].distance:7,T=tt((v/9-.38)/.62),S=Math.max(.04,A*(1-T)-.13),b=(ss.side+1)*y*m,D=(p>0?ss.front+1:ss.back+1)*y*p;for(let I=0;I<=6;I++){const U=I/6,B=ut.lerp(x,b,U),k=ut.lerp(v,D,U),V=i.localToWorld(new P(B,0,k)),te=Math.asin(V.y/V.length())/ke,H=Math.atan2(V.x,V.z)/ke;V.setLength(Ze+t(te,H)+.81+.48*tt((U-.63)/.19));const Q=i.worldToLocal(V).y,re=ut.lerp(S,Q,tt(U/.72))+.22*Math.sin(_*15)*Math.sin(U*Math.PI);s.push(B,re,k);const ge=.82+.15*U+.03*Math.cos(_*17)*Math.sin(U*Math.PI);if(r.push(ge,ge,ge,1-tt((U-.83)/.17)),n){const xe=n.bounds;o.push((H-xe.west)/xe.width,1-(xe.north-te)/xe.height)}if(l.push(n?T*.72+(1-T*.72)*tt(U/.68):0),g&&I){const xe=g*7+I;a.push(xe,xe-1,xe-6-2,xe,xe-6-2,xe-6-1)}}}const f=new it;return f.setAttribute("position",new Me(s,3)),f.setAttribute("color",new Me(r,4)),f.setAttribute("edgeBlend",new Me(l,1)),n&&f.setAttribute("uv",new Me(o,2)),f.setIndex(a),f.computeVertexNormals(),f}const uM=2.5,vu={island:103,japan:115,san:54};function ia(i){return{d:78,tilt:63,bearing:105-vu[i]}}const Gt=i=>new Oe(i),Tt={mantle:Gt("#a47f5f"),mantleShade:Gt("#92694e"),root:Gt("#56665c"),ocean:Gt("#415d66"),basalt:Gt("#596064"),exposedLava:Gt("#424949"),moss:Gt("#85916b"),land:Gt("#aa8b6e"),sediment:Gt("#baaa85"),dry:Gt("#a59b6f"),vegetation:Gt("#5e7356"),rock:Gt("#686962"),deepSea:Gt("#4b747c")},sa=i=>()=>i,xt=(i,e,t)=>new P(i,e,t);function Mh(i,e){const t=i.geometry,n=t.getAttribute("position"),s=new Float32Array(n.count*3);for(let r=0;r<n.count;r++){const o=n.getX(r),a=n.getY(r),l=n.getZ(r),c=e(o,a,l);s.set([o+c.x,a+c.y,l+c.z],r*3)}return t.morphAttributes.position=[new zt(s,3)],i.updateMorphTargets(),r=>{i.morphTargetInfluences[0]=r}}class dM{constructor(e,t,n,s){this.id=e,this.tangent=$n(t.lat,t.lon);const{up:r,east:o,north:a}=this.tangent,l=vu[e]*ke,c=a.clone().multiplyScalar(Math.cos(l)).addScaledVector(o,Math.sin(l)).normalize();this.group.quaternion.setFromRotationMatrix(new st().makeBasis(c,r,c.clone().cross(r))),this.group.position.copy(Ke(t.lat,t.lon,n(t.lat,t.lon)-6.8)),this.group.name="Tektonisches Erklärmodell · "+e,e==="island"&&this.ridge(),e==="japan"&&this.subduction(),e==="san"&&this.transform();const h=[];this.group.traverse(p=>{p instanceof Ne&&p.material===this.rock&&h.push(p)}),this.group.updateMatrixWorld(!0);const u=hM(this.group,h,n,s),d={island:"#657356",japan:"#466567",san:"#a09869"},f=this.material({map:s?.map??null,transparent:!0,depthWrite:!1,vertexColors:!0,side:wt});f.forceSinglePass=!0;const g=f.onBeforeCompile.bind(f),_=new Oe(d[e]);f.onBeforeCompile=(p,y)=>{g(p,y),p.uniforms.edgeTone={value:_},p.vertexShader=`attribute float edgeBlend; varying float vEdgeBlend;
`+p.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
vEdgeBlend = edgeBlend;`),p.fragmentShader=`varying float vEdgeBlend; uniform vec3 edgeTone;
`+p.fragmentShader.replace("#include <map_fragment>",`#include <map_fragment>
diffuseColor.rgb = mix(edgeTone, diffuseColor.rgb, vEdgeBlend);`)};const m=new Ne(u,f);m.renderOrder=2,this.group.add(m),h.push(m),this.occluders=h.map(p=>new cM(p)),this.setProgress(0)}group=new rt;tangent;arrows=[];progress=0;anchors=[];projection=new st;viewSize=new ue;screen=new Map;view=new st;labelWork={updates:0,projections:0,reusedProjections:0};occluders=[];mark(e,t,n,s,r=this.group){this.anchors.push({id:e,name:t,text:n,point:s,parent:r})}objects(){return this.anchors.map(({id:e,name:t})=>({id:e,name:t}))}labels(e,t,n,s){const r={island:["ridge","mantle","melt","plate-NA"],japan:["trench","slab","wedge","plate-PA"],san:["fault","stream","locked","plate-PA"]}[this.id],o=s?[s,...r.filter(c=>c!==s)]:r,a=[];(!this.projection.equals(e.projectionMatrix)||!this.view.equals(e.matrixWorldInverse)||this.viewSize.x!==t||this.viewSize.y!==n)&&(this.screen.clear(),this.projection.copy(e.projectionMatrix),this.view.copy(e.matrixWorldInverse),this.viewSize.set(t,n)),this.labelWork.updates++;for(const c of this.occluders)c.prepare(e.position);for(const c of o){const h=this.anchors.find(g=>g.id===c);if(!h)continue;const u=h.point.clone().applyMatrix4(h.parent.matrixWorld);let d=this.screen.get(c);if(!d||!d.point.equals(u)?(d={point:u,xy:Bs(u,e,t,n)},this.screen.set(c,d),this.labelWork.projections++):this.labelWork.reusedProjections++,!d.xy)continue;const f=u.clone().addScaledVector(u.clone().sub(e.position).normalize(),-.16);this.occluders.some(g=>g.blocks(f,c))||a.push({id:c,name:h.name,text:h.text,...d.xy})}return a}rockMap=gu();reveal={value:1};materials=[];advance=[];rock=this.material({color:16777215,vertexColors:!0,map:this.rockMap,roughness:.92});ivory=this.material({color:"#ffebae",roughness:.64,emissive:"#30220b"});charcoal=this.material({color:"#343a34",roughness:.82});melt=this.material({color:"#e49b5c",emissive:"#8b4023",emissiveIntensity:.36});bedding=this.material({color:"#c39b75",roughness:.97});material(e){const t=new gn({roughness:.86,...e}),n=this.reveal;return t.onBeforeCompile=s=>{s.uniforms.rockReveal=n,s.fragmentShader=`uniform float rockReveal;
`+s.fragmentShader.replace("#include <alphatest_fragment>",`#include <alphatest_fragment>
        if (rockReveal < 1.0) {
          vec2 pixel = floor(gl_FragCoord.xy);
          float dither = fract(52.9829189 * fract(dot(pixel, vec2(0.06711056, 0.00583715))));
          if (dither >= rockReveal) discard;
        }`)},this.materials.push(t),t}almond(e,t,n,s,r,o,a,l=0){const c=new Ne(new sr(1,1),t);return c.position.set(n,s,r),c.scale.set(o,a,.13),c.rotation.z=l,e.add(c),c}addArrow(e,t,n,s,r,o,a){const l=Zx(this.ivory,this.charcoal,n,s,r,o,a);e.add(l),this.arrows.push({plate:t,arrow:l});const c={NA:"Nordamerikanische Platte",EU:"Eurasische Platte",PA:"Pazifische Platte",OK:"Ochotskplatte"}[t];return c&&this.mark("plate-"+t,c,"Der Pfeil zeigt, in welche Richtung sich diese Platte gegenüber der anderen bewegt.",xt(0,.2,0),l),l}ridge(){const e=(c,h)=>6.3+4.9*ln(c,7.5)+.13*Ct(c,h),t=(c,h)=>10.4+3.8*ln(c,8.4)-1.5*ln(c-.25*Math.sin(h*.65),1.1)+.53*Ct(c*.85,h*.7)+.23*Ct(c*2.3,h*1.7)+.38*Math.cos(2*c+.22*h)*ln(c,7),n=(c,h)=>Math.max(e(c,h)+.12,t(c,h)-1.8-.13*Ct(c*.6,h));this.mark("ridge","Rücken","Hier bewegen sich die Platten auseinander. Gestein aus abgekühlter Schmelze bildet neuen Boden.",xt(0,t(0,-2)+.1,-2)),this.mark("mantle","Festes Mantelgestein","Unter dem Rücken steigt festes Gestein langsam auf.",xt(-8,4.4,9.15));const s=new rt;this.group.add(s),Zt(s,"Fester, verformbarer Mantel",this.rock,-21,21,e,sa(0),Tt.mantle);for(const c of[1.7,3.5,5.05]){const h=Array.from({length:19},(u,d)=>{const f=-20.5+d*41/18;return xt(f,c+c*.54*ln(f,7.4)+.17*Math.cos(f*.45),9.035)});Ts(s,"Verformung im festen Mantel",this.bedding,h,.056)}const r=this.material({color:"#dec398",roughness:.84});for(const[c,h,u]of[[-1.1,6.8,.42],[1.1,7.3,.28],[-.31,8.7,.35],[.62,9.15,.24]]){const d=this.almond(s,this.melt,c,h,9.08,u,u*1.8,c*.46);c===.62&&this.mark("melt","Magma","Beim Aufsteigen sinkt der Druck. Ein kleiner Teil des Gesteins schmilzt.",xt(0,0,1),d),this.advance.push(f=>{d.scale.y=u*(1.15+f*.9),d.position.y=h+f*.52})}for(const c of[-3,3]){const h=new rt;Ts(h,"Aufsteigendes festes Mantelmaterial",r,[xt(c,3.7,9.12),xt(c*.77,4.45,9.12),xt(c*.64,5.35,9.12)],.094),Ts(h,"Fließrichtung",r,[xt(c*.64-.37,4.9,9.12),xt(c*.64,5.4,9.12),xt(c*.64+.37,4.9,9.12)],.094),s.add(h),this.advance.push(u=>{h.position.y=u*.9})}for(const c of[-1,1]){const h=new rt;this.group.add(h);const u=c<0?-21:0,d=c<0?0:21;Zt(h,"Starrer oberster Mantel",this.rock,u,d,n,e,Tt.root);const f=(g,_,m)=>_i(Tt.exposedLava,Tt.moss,.36+.58*Ct(g*.78,_*.9)+.18*Ct(g*2.2,_*1.6)+(12-m)*.1);Zt(h,"Basaltische Kruste · Reykjanes",this.rock,u,d,t,n,Tt.basalt,f),this.addArrow(h,c>0?"EU":"NA",c*10.5,13.5,-1.9,c>0?0:Math.PI),this.advance.push(g=>{h.position.x=c*2.55*g})}const o=c=>10.8-.45*Math.abs(c),a=(c,h)=>t(0,h)+.19*Math.abs(c),l=new rt;this.group.add(l),Zt(l,"Neu gebildete ozeanische Kruste",this.rock,-1,1,a,o,Gt("#55524e"),(c,h)=>_i(Gt("#514543"),Tt.basalt,.3+.32*Math.abs(c)+.18*Ct(c,h)),10),this.advance.push(c=>{l.visible=c>.003,l.scale.x=Math.max(.001,c*2.56),s.scale.x=1+c*2.55/21})}subduction(){const t=(y,x)=>{const v=Math.max(4-y,0);return 8.4+2.7*(1-Math.exp(-Math.max(y-4,0)/4))-.13*v-.013*v*v+.1*Math.sin(x*.43+y*.13)},n=(y,x)=>t(y,x)-2.02,o=(y,x)=>n(Math.max(-13.6,y),x);Zt(this.group,"Mantel unter der pazifischen Platte",this.rock,-21,21,o,sa(-.5),Tt.mantleShade);const a=(y,x)=>{const v=tt((4-y)/12),w=4*ln(y+10.9,2.6)*ln(x+1.3,3.5),M=(.49*Ct(y*.75,x*.63)+.49*Math.cos(x*.61+y*.8))*v;return t(4,x)+4.38*v+w+M},l=(y,x)=>Math.max(t(Math.max(-13.6,y),x),5.75+.17*Ct(y*.65,x)),c=(y,x)=>Math.max(l(y,x),a(y,x)-2.35*tt((4-y)/5)),h=(y,x)=>y<-13.6?n(-13.6,x):t(y,x);Zt(this.group,"Fester Mantelkeil über der abtauchenden Platte",this.rock,-21,4,l,h,Tt.mantle),Zt(this.group,"Mantellithosphäre der Oberplatte",this.rock,-21,4,c,l,Tt.root),Zt(this.group,"Oberplatte mit Küste und Vulkanbogen",this.rock,-21,4,a,c,Tt.land,(y,x,v)=>{const w=_i(Tt.vegetation,Tt.rock,.23+.34*Ct(y,x)+(v-13)*.18);return _i(Tt.deepSea,w,tt((-y-.9)/4.1))});const u=(y,x)=>t(y,x)-.65,d=[Zt(this.group,"Pazifische Mantellithosphäre",this.rock,-13.6,21,u,n,Tt.ocean),Zt(this.group,"Ozeanische Kruste taucht in den Mantel",this.rock,-13.6,21,t,u,Gt("#728488"),(y,x)=>_i(Tt.deepSea,Tt.ocean,.3+.3*Ct(y*.45,x)))];for(const y of d)this.advance.push(Mh(y,(x,v,w)=>{const M=-2.2*Math.sin(Math.PI*(x- -13.6)/34.6);return xt(M,t(x+M,w)-t(x,w),0)}));const f=this.material({color:"#a6b2a4"});for(const y of[-9.6,-4,2,8.6,15]){const x=this.almond(this.group,f,y,0,9.065,.67,.13);y===-4&&this.mark("slab","Abtauchende Platte","Die ozeanische Platte biegt sich am Graben und taucht unter die andere Platte ab.",xt(0,0,1),x),this.advance.push(v=>{const w=y-2.3*v;x.position.set(w,t(w,9)-1.12,9.065),x.rotation.z=Math.atan((t(w+.1,9)-t(w-.1,9))/.2)})}const g=this.material({color:"#a3c8c0"});for(const[y,x]of[[-9.5,3.15],[-10.15,3.75],[-10.6,4.1]]){const v=this.almond(this.group,g,y,x,9.09,.14,.3,-.25);this.advance.push(w=>{v.position.y=x+w*.39})}for(const[y,x,v]of[[-11.7,4.25,.47],[-10.9,4.65,.4],[-11.4,5.06,.28]]){const w=this.almond(this.group,this.melt,y,x,9.1,v,.23,.34);this.advance.push(M=>{w.scale.y=.16+.15*M})}Ts(this.group,"Schematischer Aufstiegsweg zum Vulkanbogen",this.melt,[xt(-11.25,5,9.06),xt(-11.6,7.2,9.06),xt(-10.8,9.1,9.06),xt(-11,11.8,9.06)],.095);const _=this.material({color:"#f3dba5",emissive:"#553714"});for(const y of[-6,-2,1.4]){const x=this.almond(this.group,_,y,t(y,9)+.04,9.12,.23,.12,.44);this.advance.push(v=>{const w=ln(v-.59+(y+2)*.01,.075);x.scale.set(.2+.27*w,.11+.18*w,.12)})}this.mark("trench","Tiefseegraben","Wo die ozeanische Platte abbiegt, entsteht eine tiefe Rinne am Meeresboden.",xt(4,t(4,3)+.12,3)),this.mark("volcano","Vulkan","Unter dem Vulkan kann Magma aufsteigen. An der Oberfläche kann es als Lava austreten.",xt(-11,a(-11,1)+.3,1)),this.mark("wedge","Magma","Wasser aus der abtauchenden Platte begünstigt das Schmelzen im Mantel darüber.",xt(-11.7,4.25,9.28)),this.mark("quake","Erdbeben","An der Kontaktfläche kann sich Spannung aufbauen. Beim plötzlichen Gleiten bebt die Erde.",xt(-2,t(-2,9),9.3));const m=this.addArrow(this.group,"OK",-15.5,14.05,4.9,0,5.8),p=this.addArrow(this.group,"PA",13.6,11.85,-1.8,Math.PI,7.2);this.advance.push(y=>{m.position.x=-15.5+.62*y,p.position.x=13.6-1.7*y})}transform(){const e=a=>.31*Math.sin(a*.34)+.12*Math.sin(a*.75),t=(a,l)=>4.9+.23*Ct(a*.52,l*.45),n=a=>-.9+.17*a+.65*Math.sin(a*.3),s=(a,l)=>{const c=a-e(l);return 10.95+(1.15*Math.sin(.37*a-.16*l)*Math.cos(.21*l+.13*a)+.53*Ct(a*.8,l*.6))-1.25*ln(c,.92)-.4*ln(l-n(a),.68)},r=(a,l)=>8.05+.31*Ct(a*.68,l*.57);Zt(this.group,"Verformbarer Mantel unter Kalifornien",this.rock,-21,21,t,sa(0),Tt.mantle),this.mark("fault","Störung","Hier gleiten die Platten seitlich aneinander vorbei.",xt(e(5),s(e(5),5)+.2,5)),this.mark("locked","Verhakter Abschnitt","Die Seiten können sich verhaken. Löst sich die Spannung plötzlich, entsteht ein Erdbeben.",xt(e(9),8.9,9.16));const o=this.material({color:"#b5aa8e",roughness:1});for(const a of[-1,1]){const l=new rt;this.group.add(l);const c=a<0?-21:_=>e(_)+.07,h=a<0?_=>e(_)-.07:21,u=[Zt(l,"Lithosphärischer Mantel",this.rock,c,h,r,t,Tt.root),Zt(l,"Kruste an der San-Andreas-Verwerfung",this.rock,c,h,s,r,Tt.sediment,(_,m)=>{const p=_i(Tt.dry,Tt.vegetation,.32+.58*Ct(_*.8,m*.65)+.17*Ct(_*1.9,m*2.2));return _i(p,Tt.sediment,.68*ln(m-n(_),.75))})],d=Array.from({length:22},(_,m)=>{const p=a*(.24+20.1*m/21),y=n(p);return xt(p,s(p,y)+.065,y)});u.push(Ts(l,"Schematischer versetzter Bachlauf",o,d,.12));const f=xt(6,s(6,n(6))+.21,n(6));a>0&&this.mark("stream","Versetzter Bachlauf","Die beiden Abschnitte des Bachlaufs verschieben sich seitlich gegeneinander.",f,l);const g=u.map(_=>Mh(_,(m,p,y)=>xt(0,0,a*3.2*ln(m-e(y),4.9))));this.addArrow(l,a<0?"PA":"NA",a*10,13,0,a*Math.PI/2,7.8),this.advance.push(_=>{const m=.69*tt((_-.54)/.15)+Math.max(0,_-.69);l.position.z=a*3.2*_,a>0&&(f.z=n(6)+3.2*ln(6-e(n(6)),4.9)*(m-_));for(const p of g)p(m-_)})}}setProgress(e){const t=ut.clamp(e,0,1);this.progress=t;for(const n of this.advance)n(t)}diagnostics(e,t,n){const s=this.arrows.map(({plate:a,arrow:l})=>{l.updateWorldMatrix(!0,!1);const c=new P(1,0,0).transformDirection(l.matrixWorld),h=Math.atan2(c.dot(this.tangent.east),c.dot(this.tangent.north))/ke;return{plate:a,azimuth:(h+360)%360}}),r={...this.labelWork,rays:0,triangles:0,reused:0,inversions:0,morphChanges:0};for(const a of this.occluders)for(const l of Object.keys(a.work))r[l]+=a.work[l];const o=Object.fromEntries(this.anchors.map(a=>[a.id,Bs(a.point.clone().applyMatrix4(a.parent.matrixWorld),e,t,n)]));return{arrows:s,progress:this.progress,work:r,anchors:o}}setReveal(e){this.reveal.value=ut.clamp(e,0,1)}dispose(){this.group.removeFromParent();const e=new Set;this.group.traverse(t=>{t instanceof Ne&&e.add(t.geometry)});for(const t of e)t.dispose();for(const t of this.materials)t.dispose();this.rockMap.dispose()}}class fM{constructor(e,t){this.canvas=e,this.warn=t,this.gl=new jv({canvas:e,antialias:!0,alpha:!0,powerPreference:"high-performance"}),this.gl.setPixelRatio(this.resolution.ratio),this.gl.shadowMap.enabled=!0,this.gl.shadowMap.autoUpdate=!1,this.gl.shadowMap.type=Th,this.gl.toneMapping=Ch,this.gl.toneMappingExposure=1.06,this.gl.setClearColor(0,0),this.nav=new b_(e),this.planet=new w_(t),this.nyos=new N_((r,o)=>this.planet.elevation(r,o)),this.scene.add(this.nyos.group);for(const r of Js.values()){const o=new E_(r);this.terrains.set(r.id,o),this.scene.add(o.group)}this.scene.add(this.planet.group,this.shell.group,this.hemi,this.sun,this.sun.target,this.grid),this.shell.group.visible=!1;const n=[];for(let r=-60;r<=60;r+=30)for(let o=-180;o<180;o+=2)n.push(...Ke(r,o,10).toArray(),...Ke(r,o+2,10).toArray());for(let r=-180;r<180;r+=30)for(let o=-90;o<90;o+=2)n.push(...Ke(o,r,10).toArray(),...Ke(o+2,r,10).toArray());const s=new it;s.setAttribute("position",new Me(n,3)),this.grid.add(new qh(s,new wl({color:14216688,transparent:!0,opacity:.105,depthWrite:!1}))),this.air=new Ne(new Kn(Ze*1.021,120,64),new nn({transparent:!0,side:jt,depthWrite:!1,uniforms:{color:{value:new Oe("#74b8d5")}},vertexShader:"varying vec3 n;varying vec3 eye;void main(){vec4 p=modelViewMatrix*vec4(position,1.);n=normalize(normalMatrix*normal);eye=-p.xyz;gl_Position=projectionMatrix*p;}",fragmentShader:"varying vec3 n;varying vec3 eye;uniform vec3 color;void main(){float rim=pow(1.-abs(dot(normalize(n),normalize(eye))),11.);gl_FragColor=vec4(color,rim*.46);}"})),this.scene.add(this.air),this.scene.fog=new Sl(11980752,0),this.nav.onPick=(r,o)=>{if(this.mode!=="inside"&&!(this.mode==="plates"&&!this.processDetail&&this.atlas))return;const a=e.getBoundingClientRect(),l=new Za;if(l.setFromCamera(new ue((r-a.x)/a.width*2-1,1-(o-a.y)/a.height*2),this.nav.camera),this.mode==="plates"){if(this.mosaic?.pair){const u=l.intersectObjects(this.mosaic.pair.bodies,!1)[0];u&&(this.inspectPlate(u.object.name),this.locatePlate(),this.onBoundary?.());return}const h=l.ray.intersectSphere(new wn(new P,Ze),new P);if(h){const u=this.nav.pose.d*2*Math.tan(ut.degToRad(this.nav.camera.fov/2))*16/(a.height*Ze),d=h.normalize(),f=this.plateOptions.boundaries&&(this.processSite||this.plateOptions.types)?this.atlas.pick(d,u):null;if(this.selectBoundary(f),!f&&!this.processSite){const g=this.mosaic?.pick(l);g&&(this.inspectPlate(g.object.name,g.point),this.mosaic.track(g))}this.onBoundary?.()}return}const c=l.intersectObjects(this.shell.parts,!1).find(h=>h.object.visible);c&&this.onLayer?.(c.object.userData.layer)},new ResizeObserver(()=>this.resize()).observe(e),document.addEventListener("visibilitychange",()=>{this.last=0,this.nav.flight?.paced&&(this.nav.flight.last=performance.now())}),this.resize(),e.addEventListener("webglcontextlost",r=>{r.preventDefault(),this.running=!1,this.planet.uploadedTiles.clear(),this.warn("Grafikkontext unterbrochen. Seite neu laden, um das Modell wieder zu öffnen.")}),e.addEventListener("webglcontextrestored",()=>{this.running=!0,this.last=0,requestAnimationFrame(this.render)})}scene=new df;gl;nav;planet;nyos;nyosDetail=!0;nyosLesson=new V_;nyosFocusOffset=0;nyosEvent;nyosInputRevision=0;nyosAutoStarted=!1;nyosAutoFlight;nyosVisitToken=0;nyosStage="Globus";nyosFarWeight=0;nyosMidWeight=0;nyosGround=0;nyosCoverage;globeOccluded=!1;terrains=new Map;region=Ds;get local(){return this.terrains.get(this.region.id)}renderMs=0;terrainMs=0;shell=new T_;mode="globe";style="A";ready=!1;fps=0;frames=0;running=!0;waitingForAscent=!1;last=0;resolution=new C_(devicePixelRatio);frameMs=0;shadowStamp="";fpsStart=0;frameCount=0;hemi=new sp(16580607,10529962,1.48);sun=new ap(16773594,2.05);grid=new rt;air;marker=Ke(Ds.target.lat,Ds.target.lon,10);onFrame;onLayer;onBoundary;plateOptions={boundaries:!1,names:!1,types:!1,category:"all",plate:""};mosaic;profiles={};profileCode="";singlePlateName=!1;smallPlateNames=!1;processChoice="";pickedPlatePoint;processSite=null;processDetail=!1;processProgress=0;processPlaying=!1;processLoop=!1;processSlow=!1;atlas;atlasLoading;images;imagesLoading;sectionWindow=new sM;models=new Map;selectedStep=null;atlasReturn={...ri};atlasFilters;anchor=null;departure=null;patchOpacity=0;processReveal=0;focusOffset=0;focusReveal=0;sizeDirty=!0;resize(){this.sizeDirty=!0}applySize(){this.sizeDirty=!1;const e=this.canvas.clientWidth,t=this.canvas.clientHeight;!e||!t||(this.gl.setSize(e,t,!1),this.nav.camera.aspect=e/t,this.nav.camera.fov=e<t?2*Math.atan(Math.tan(39*Math.PI/360)*t/e)*180/Math.PI:39,this.nav.camera.updateProjectionMatrix())}planetInitialized;async init(){try{this.planetInitialized=this.planet.init(),await this.planetInitialized}catch{this.warn("Basiskarte fehlt · Reliefkugel ohne Bilddaten")}this.setStyle("A"),this.ready=!0,requestAnimationFrame(this.render)}setStyle(e){this.style=e,this.planet.setStyle(e);for(const t of this.terrains.values())t.setStyle(e);this.shell.style=e,this.shell.map=this.planet.maps[e]??this.planet.baseline,this.shell.map&&(this.shell.map.wrapS=zs,this.shell.map.version===0&&(this.shell.map.needsUpdate=!0)),this.mode==="inside"&&this.shell.rebuild(),this.hemi.intensity=eo[e].sky,this.sun.intensity=eo[e].sun}loadPlates(){return this.atlasLoading||(this.atlasLoading=Promise.all([jx((e,t)=>this.planet.elevation(e,t)),fetch(Kx).then(async e=>{if(!e.ok)throw new Error("Plattenflächen fehlen");return await e.json()}),this.planetInitialized]).then(([e,t])=>{const n=new Map(Object.keys(t).map(s=>[s,new Set]));for(const s of e.steps){const r=s[1].slice(0,2),o=s[1].slice(-2);n.get(r)?.add(o),n.get(o)?.add(r)}this.profiles=iM(e.steps,qn),this.mosaic=new Qx(t,this.planet.maps.A??this.planet.baseline,n),this.scene.add(this.mosaic.group),this.atlas=e,this.scene.add(e.group),this.updatePlateLayers(),this.onBoundary?.()}).catch(()=>{this.atlasLoading=void 0,this.warn("Plattendaten konnten nicht geladen werden. Plattenansicht erneut öffnen.")})),this.atlasLoading}loadRegionalImages(){return this.imagesLoading?this.imagesLoading:(this.imagesLoading=lM((e,t)=>this.planet.elevation(e,t)).then(e=>{this.images=e,e.visible=!1,this.scene.add(e)}).catch(()=>{this.imagesLoading=void 0,this.warn("Regionales Satellitenbild fehlt · globale Erdkarte aktiv")}),this.imagesLoading)}selectBoundary(e){this.selectedStep=e,this.atlas?.selectStep(e)}get selectedBoundary(){if(!this.selectedStep)return null;const e=this.selectedStep[1];return{kind:is(this.selectedStep[2]),plates:[qn[e.slice(0,2)],qn[e.slice(-2)]]}}updatePlateLayers(){if(!this.atlas)return;const{boundaries:e,types:t,category:n,plate:s}=this.plateOptions,r=this.mode==="plates"&&!this.processSite;this.mosaic&&(r&&this.nav.pose.d>=340&&!this.mosaic.group.visible&&this.mosaic.open(this.nav.camera.position,this.nav.reducedMotion.matches),!r&&this.mosaic.group.visible&&(this.mosaic.close(),this.profileCode=""),this.mosaic.selected=r?s:""),this.nav.minimumDistance=r?this.mosaic?.pair?160:340:.06,r&&!this.nav.flight&&this.nav.goal.d<this.nav.minimumDistance&&this.nav.fly({...this.nav.goal,d:500}),this.atlas.setLayers(this.mode==="plates"&&!this.mosaic?.pair&&e,t,t&&n!=="all"?n:null,r?null:s||null)}setPlateOptions(e){(e.plate!==void 0||e.names!==void 0||e.boundaries===!1)&&(this.singlePlateName=!1),e.plate!==void 0&&(this.pickedPlatePoint=void 0),e.names===!1&&(this.processChoice=""),Object.assign(this.plateOptions,e);const{types:t,category:n,boundaries:s}=this.plateOptions;this.selectedStep&&(!s||t&&n!=="all"&&is(this.selectedStep[2])!==n)&&this.selectBoundary(null),this.updatePlateLayers()}inspectPlate(e,t){e&&!this.profiles[e]||(this.mosaic?.endPair(!this.nav.reducedMotion.matches),this.setPlateOptions({plate:e}),this.mosaic?.clearAnchor(),this.singlePlateName=!!e,this.profileCode=e,this.pickedPlatePoint=t?.clone(),this.selectBoundary(null))}atlasWorld(){this.inspectPlate(""),this.atlasReturn={...ri},this.nav.fly(ri)}fitSlope(){const e=this.canvas.getBoundingClientRect(),t=document.getElementById("sidebar").getBoundingClientRect(),n=t.bottom>e.top+10&&t.top<e.bottom-10&&t.left<e.left+40,s=Math.max(e.width*.22,e.width/2-(n?t.right-e.left+14:20)),r=Math.max(60,e.height/2-62);return 2*Math.min(s,r)*Math.tan(this.nav.camera.fov*ke/2)/e.height}get pairKind(){return this.mosaic?.pair&&is(this.mosaic.pair.step[2])}comparePlates(e){if(!(!this.atlas||!this.mosaic)){if(!this.mosaic.pair){const t=this.profileCode||"EU",n=this.profiles[t];this.inspectPlate(t);const s=this.mosaic.beginPair(this.atlas.steps[n.step-1]);this.updatePlateLayers();const r=Math.max(180,s.span/(.86*this.fitSlope()));this.nav.fly({...s.site,d:r,tilt:32,bearing:s.heading},!0)}e&&this.mosaic.play()}}locatePlate(){const e=lo[this.profileCode];if(!e)return;const[t,n]=e;this.pickedPlatePoint=Ke(n,t,2);const s=Math.min(62*ke,this.mosaic.extents.get(this.profileCode)),r=Ze*(Math.sin(s)/(.72*this.fitSlope())-(1-Math.cos(s)));this.nav.fly({lon:t,lat:n,d:ct(r,340,19500),tilt:0,bearing:0},!0)}get atlasReady(){return!!this.atlas}get annotationTransition(){return this.processSite?this.processReveal:this.mosaic?.annotationPose??0}plateLabels(){return this.mosaic?.pair&&this.mode==="plates"?this.mosaic.pair.labels(this.nav.camera,this.canvas.clientWidth,this.canvas.clientHeight):!this.atlas||this.mode!=="plates"||!(this.plateOptions.names||this.singlePlateName)||this.processReveal>.5?[]:this.atlas.labels(this.nav.camera,this.canvas.clientWidth,this.canvas.clientHeight,this.nav.pose.d,this.processSite??void 0,this.plateOptions.plate,this.mosaic?.anchor()??this.pickedPlatePoint,this.singlePlateName&&!this.plateOptions.names,this.smallPlateNames)}plates(){if(this.nyosLesson.playing=!1,this.mode==="plates"&&this.processSite){this.plateOverview();return}(this.mode==="place"||this.mode==="inside"||this.mode==="nyos")&&this.nav.fly(this.atlasReturn,this.mode==="nyos"),this.mode="plates",this.updatePlateLayers(),this.loadPlates()}leaveProcess(e=!1){this.nyosLesson.playing=!1,this.atlasFilters&&!e&&(this.setPlateOptions(this.atlasFilters),this.atlasFilters=void 0);const t=this.processSite;if(t&&this.anchor&&(this.processReveal>0||this.patchOpacity>0)){if(this.departure&&this.departure.id!==t){const n=this.models.get(this.departure.id);n&&(n.group.visible=!1)}this.departure={id:t,...this.anchor,showModel:this.processReveal>0}}this.processChoice="",this.processSite=null,this.processDetail=!1,this.anchor=null,this.processReveal=0,this.nav.orbit=!1,this.resetProcess(),this.patchOpacity=0,this.selectBoundary(null)}plateOverview(){this.leaveProcess(),this.mode="plates",this.nav.fly(this.atlasReturn,!0),this.updatePlateLayers(),this.loadPlates()}visitBoundary(e,t){this.processSite||(this.mode==="globe"||this.mode==="plates"?this.atlasReturn={...this.nav.pose}:this.atlasReturn={...ri},this.atlasFilters={category:this.plateOptions.category,plate:this.plateOptions.plate}),this.leaveProcess(!0),this.mode="plates",this.processSite=e,this.processDetail=!t,this.setPlateOptions({boundaries:!0,category:"all",plate:""});const n=()=>{if(!this.atlas||this.mode!=="plates"||this.processSite!==e||this.processDetail===t)return;const s=el[e],r=this.atlas.steps[s.stepId-1];if(this.anchor=mu(r),this.selectBoundary(r),!t){let a=this.models.get(e);if(!a){a=new dM(e,this.anchor,(c,h)=>this.planet.elevation(c,h),this.images?.getObjectByName(e)?.userData.image),a.group.visible=!1,this.models.set(e,a),this.sectionWindow.attach(this.planet.material);const l=this.images?.getObjectByName(e);l&&this.sectionWindow.attach(l.material),this.scene.add(a.group)}a.setProgress(0)}const o=ia(e);this.nav.fly({...this.anchor,...t?{d:s.regionalDistance,tilt:8,bearing:0}:o},!0),this.images?.userData.missing.includes(e)&&this.warn("Regionales Satellitenbild fehlt · globale Erdkarte aktiv"),this.onBoundary?.()};this.atlas&&this.images?n():Promise.all([this.loadPlates(),this.loadRegionalImages()]).then(n)}toggleProcess(){!this.processDetail||!this.processSite||(this.processProgress>=1&&this.resetProcess(),this.processPlaying=!this.processPlaying)}resetProcess(){this.processPlaying=!1,this.processProgress=0,this.processSite&&this.models.get(this.processSite)?.setProgress(0)}updateTectonics(e){const t=this.processSite;if(!t&&!this.departure){this.sectionWindow.show(void 0,0);return}const{d:n,lat:s,lon:r}=this.nav.pose,o=(g,_,m)=>{const p=ns(g.lon,r),y=Math.hypot(s-g.lat,p*Math.cos(s*Math.PI/180));return 1-tt((y-_)/m)},a=1-tt((n-1800)/1800),l=1-tt((n-155)/320);this.patchOpacity=t&&this.anchor&&this.images&&!this.images.userData.missing.includes(t)?a*o(this.anchor,8,10):0,this.processReveal=this.processDetail&&this.anchor?l*o(this.anchor,.8,1.5):0;let c=0,h=0;const u=this.departure;if(u){c=a*o(u,8,10),h=u.showModel?l*o(u,.8,1.5):0;const g=this.models.get(u.id);g&&!(t===u.id&&this.processDetail)&&(g.group.visible=h>0,g.group.visible&&g.setReveal(h)),(c<=0&&h<=0||t===u.id&&(this.processDetail||h<=0))&&(this.departure=null)}this.focusReveal=Math.max(this.processReveal,h);const d=this.processReveal>=h?t:u?.id;if(this.sectionWindow.show(d?this.models.get(d)?.group:void 0,this.focusReveal),this.atlas?.setOpacity(1-this.focusReveal),this.images){this.images.visible=this.patchOpacity>0||c>0;for(const g of this.images.children){const _=Math.max(g.name===t?this.patchOpacity:0,g.name===u?.id?c:0);g.visible=_>0,g.visible&&(g.material.opacity=_)}}if(this.nav.orbit=this.processReveal>.5,!t||!this.processDetail)return;const f=this.models.get(t);f&&(f.group.visible=this.processReveal>0,f.group.visible&&(f.setReveal(this.processReveal),this.processPlaying&&!this.nav.flight&&(this.processProgress+=e/(this.processSlow?26:13),this.processProgress>=1&&(this.processLoop?this.processProgress%=1:(this.processProgress=1,this.processPlaying=!1)),f.setProgress(this.processProgress))))}get nyosWarning(){return this.mode==="nyos"&&this.nyos.error&&!this.nyos.ready?"Nyos-Geländedaten fehlen · regionale Ersatzansicht":""}showNyos(e){this.visitNyos(!1,e)}showNyosMeasure(e){this.visitNyos(!1,"protection",e)}visitNyos(e,t="lake",n="pipe"){this.nyosLesson.select(t),this.nyosLesson.measure=n,this.nyosInputRevision=this.nav.inputRevision,this.nyosAutoStarted=!1,this.nyosAutoFlight=void 0,this.leaveProcess(),this.mode="nyos",this.updatePlateLayers(),this.nyosDetail=!e;const s=++this.nyosVisitToken,r=()=>{if(this.mode!=="nyos"||this.nyosVisitToken!==s)return;const o=this.nyos.meta,a={...si.target,...o?.anchor??{}};if(o&&this.nyos.ready)if(!this.nyosCoverage&&o.heightRangeM&&(this.nyosCoverage=new O_(o,o.heightRangeM[0]/1e3)),this.planet.setNyosMaps(o.bounds,o.regional?.bounds,this.nyos.regionTexture,o.vicinity?.bounds,this.nyos.vicinityTexture),t==="protection"&&n==="settlements"){const[l,c]=tl;this.nav.fly({lat:(l.lat+c.lat)/2,lon:(l.lon+c.lon)/2,d:this.nav.camera.aspect<1.3?2.75:2.4,tilt:55,bearing:3},!0)}else this.nyosSectionActive()?this.nav.fly({...a,d:this.nav.camera.aspect<1.3?2.75:2.2,bearing:80,tilt:66},!0):this.nav.fly(e?{...a,...si.overview}:a,!0);else this.nyosDetail=!1,this.nyosLesson.select("lake"),this.nav.fly({...a,d:1950,tilt:3,bearing:0},!0)};this.nyos.ready?r():this.nyos.load().then(r)}nyosPin(){if(this.mode!=="nyos"||this.nav.pose.d<22)return null;const{lat:e,lon:t}=this.nyos.meta?.anchor??si.target,n=Ke(e,t,this.nyos.meta?this.nyos.meta.waterLevelM/1e3:this.planet.elevation(e,t)),s=this.nav.camera;return n.dot(s.position)<=n.lengthSq()||(n.project(s),Math.abs(n.x)>.96||Math.abs(n.y)>.91||Math.abs(n.z)>1)?null:{x:(n.x+1)*this.canvas.clientWidth/2,y:(1-n.y)*this.canvas.clientHeight/2}}nyosReliefLabels(){if(this.mode!=="nyos"||this.nyosLesson.view!=="protection"||this.nyosLesson.measure!=="settlements"||this.nyos.localWeight<.98||this.nav.pose.d>8)return[];const e=this.nav.camera,t=new P;return tl.flatMap(n=>{const s=this.nyos.ground(n.lat,n.lon);if(s===null)return[];const r=Ke(n.lat,n.lon,s+.065),o=r.clone().project(e);if(Math.abs(o.x)>.97||Math.abs(o.y)>.92||Math.abs(o.z)>1)return[];for(let a=1;a<24;a++){t.copy(e.position).lerp(r,a/24);const l=t.length(),c=this.nyos.ground(Math.asin(t.y/l)/ke,Math.atan2(t.x,t.z)/ke);if(c!==null&&l<Ze+c)return[]}return[{label:n.name==="Talsohle"?"Talboden":"Hang",x:(o.x+1)*this.canvas.clientWidth/2,y:(1-o.y)*this.canvas.clientHeight/2}]})}advanceNyosTime(){const e=this.nyosLesson;if(this.mode!=="nyos"||!this.nyos.ready||!e.playing||this.nav.flight&&this.nav.flight!==this.nyosAutoFlight||this.nyos.localWeight<=0)return;const t=!!this.nav.flight&&this.nav.flight===this.nyosAutoFlight;e.advance(Math.min(t?.125:.5,this.frameMs/1e3)),!(e.view!=="event"||e.progress<.64||this.nyosAutoStarted)&&(this.nyosAutoStarted=!0,this.nav.inputRevision===this.nyosInputRevision&&(this.nav.fly({lat:6.447,lon:10.297,d:4.25,tilt:41,bearing:16},!0,2900),this.nyosAutoFlight=this.nav.flight))}nyosSectionActive(){const{view:e,measure:t,progress:n}=this.nyosLesson;return this.mode==="nyos"&&(e==="section"||e==="event"&&n<.68||e==="protection"&&t!=="settlements")}updateNyos(e,t,n,s){if(!this.nyos.ready)return;const r=this.nyos.meta.anchor,o=Math.hypot(e-r.lat,ns(r.lon,t)*Math.cos(e*ke)),a=!s&&o<28,l=a&&o<.5;this.nyosFarWeight=a&&this.nyos.regionTexture?1-tt((n-490)/1500):0,this.nyosMidWeight=a&&this.nyos.vicinityTexture?1-tt((n-48)/125):0,this.nyos.update(n,l);const c=this.nyos.localWeight>0,h=this.mode==="nyos"&&this.nyosLesson.view==="event";this.nyos.setSection(this.nyosSectionActive()),h&&this.nyos.section&&!this.nyosEvent&&(this.nyosEvent=new k_(this.nyos,this.nyos.section),this.nyos.group.add(this.nyosEvent.group)),this.nyosEvent?.update(this.nyosLesson.progress,this.nyosLesson.air,h&&c);const u=this.mode==="nyos"&&this.nyosLesson.view==="protection";this.nyos.setDissolved(this.nyosLesson.dissolved&&this.mode==="nyos"),this.nyos.setProtection(u&&c,this.nyosLesson.measure,this.nyosLesson.progress),this.planet.setNyosWeights(this.nyosFarWeight,this.nyosMidWeight,this.nyos.localWeight),this.nyosStage=n>6200?"Afrika":n>1500?"Kamerun":n>260?"Kamerun-Vulkanlinie":n>45?"Vulkanisches Hochland":n>6?"Umgebung des Nyos-Sees":"Nyos-See",this.mode==="nyos"?(this.nav.orbit=l&&n<20,this.nav.orbitMinimum=.58):this.nav.orbitMinimum=38}nyosDiagnostics(){const e=this.nav.camera.position,t=e.length(),n=t&&this.nyos.ready?this.nyos.ground(Math.asin(e.y/t)/ke,Math.atan2(e.x,e.z)/ke):null;return{...this.nyos.diagnostics(),...this.nyosLesson,eventVisual:this.nyosEvent?.diagnostics()??{risingWater:!1,freeBubbles:0,surfaceRelease:!1,reliefAnalysis:!1},ready:this.nyos.ready,error:this.nyos.error,detail:this.mode==="nyos"&&this.nyosDetail,stage:this.nyosStage,distance:this.nav.pose.d,regionalWeight:this.nyosFarWeight,vicinityWeight:this.nyosMidWeight,localWeight:this.nyos.localWeight,globeOccluded:this.globeOccluded,focusHeightKm:this.nyosFocusOffset,terrainVisible:this.nyos.ready&&this.nyos.localWeight>0,groundKm:this.nyosGround,cameraClearanceKm:n===null?null:t-Ze-n,nearKm:this.nav.camera.near,farKm:this.nav.camera.far,anchor:this.nyos.meta?.anchor??{lat:si.target.lat,lon:si.target.lon}}}visit(e=Ds.id,t=!1){if(e===si.id){this.visitNyos(t);return}if(Object.hasOwn(el,e)){this.visitBoundary(e,t);return}const n=Js.get(e);if(!n)return;const s=!!this.processSite;this.leaveProcess(),this.region=n,this.local.setStyle(this.style),this.mode="place",this.updatePlateLayers();const r=t?{...n.target,...n.overview}:n.target;this.nav.fly(r,s);const o=this.nav.flight;this.local.load().then(()=>{!this.local.ready&&this.region===n&&this.mode==="place"&&(this.nav.flight===o||this.nav.pose.d<=r.d+.001)&&this.nav.fly({...r,d:n.lod.fallbackKm,tilt:0,bearing:0})})}globe(e=!1){const t=this.mode==="nyos",n=this.mode==="plates",s=this.processSite!==null;this.leaveProcess(),this.mode="globe",this.updatePlateLayers(),e&&(this.inspectPlate(""),this.processSlow=!1,this.processLoop=!1),e||!n?this.nav.fly(ri,s||t):s&&this.nav.fly(this.atlasReturn,!0)}inside(){this.waitingForAscent=this.mode!=="inside"&&this.nav.pose.d<3500,this.leaveProcess(),this.mode="inside",this.updatePlateLayers(),this.shell.rebuild(),this.nav.fly({...ri,lon:3,lat:17},!!this.departure)}layerMarkers(e,t){const n=this.nav.camera,s=Math.atan2(n.position.x,n.position.z)*180/Math.PI;if(!this.shell.cut||!this.shell.group.visible||s<=-25||s>=65)return[];const r=s<20?65:-25,o=Qi(this.shell.expanded),a=[],l=(c,h,u,d,f)=>{const g=Bs(Ke(d,r,f-Ze),n,this.canvas.clientWidth,this.canvas.clientHeight);g&&a.push({id:c,name:h,text:u,...g})};return Qt.forEach((c,h)=>{(t||e.has(h))&&this.shell.visible[h]&&l("shell-"+h,c.name,c.text,[49,15,-9,-46][h],(o[h]+o[h+1])/2)}),t&&this.shell.lithosphere&&this.shell.visible[0]&&this.shell.visible[1]&&l("lithosphere","Lithosphäre","Die Erdkruste und der starre oberste Erdmantel bilden zusammen die Lithosphäre. Ihre Dicke ist örtlich verschieden.",29,o[1]-60),a}processObjects(){return this.processSite?this.models.get(this.processSite)?.objects()??[]:[]}processLabels(){return!this.processSite||!this.processDetail||this.processReveal<.95?[]:this.models.get(this.processSite)?.labels(this.nav.camera,this.canvas.clientWidth,this.canvas.clientHeight,this.processChoice)??[]}markerPosition(){const e=this.nav.camera,t=this.marker.clone().project(e);return{x:(t.x+1)*50,y:(1-t.y)*50,visible:this.marker.dot(e.position.clone().sub(this.marker))>0&&this.mode!=="inside"&&this.nav.pose.d>1600&&t.z<1}}atlasCoverage(){if(!this.atlas||!this.mosaic?.group.visible)return[];const e=this.canvas.getBoundingClientRect(),t=new Za,n=new wn(new P,Ze),s=[];for(let r=0;r<15;r++)for(let o=0;o<23;o++){const a=(o+.5)/23,l=(r+.5)/15;if(document.elementFromPoint(e.x+a*e.width,e.y+l*e.height)!==this.canvas)continue;t.setFromCamera(new ue(2*a-1,1-2*l),this.nav.camera);const c=t.ray.intersectSphere(n,new P);c&&s.push({x:a,y:l,code:this.atlas.plateAt(c.normalize())})}return s}diagnostics(){const{lat:e,lon:t,d:n,tilt:s,bearing:r}=this.nav.pose;return{ready:this.ready,mode:this.mode,style:this.style,lat:e,lon:t,d:n,tilt:s,bearing:r,flying:!!this.nav.flight,fps:this.fps,frames:this.frames,pixelRatio:this.gl.getPixelRatio(),frameMs:this.frameMs,resolution:{initial:this.resolution.maximum,minimum:this.resolution.minimum,maximum:this.resolution.maximum,width:this.canvas.width,height:this.canvas.height,reductions:this.resolution.reductions,recoveries:this.resolution.recoveries},tiles:this.planet.tileCount,uploadedTiles:this.planet.uploadedTiles.size,cachedTiles:this.planet.cachedTileCount,region:this.mode==="nyos"?si.id:this.processSite??this.region.id,nyos:this.nyosDiagnostics(),renderMs:this.renderMs,terrainMs:this.terrainMs,programs:this.gl.info.programs?.length,tectonics:{...this.plateOptions,mosaic:this.mosaic?.diagnostics(this.nav.camera,this.canvas.clientWidth,this.canvas.clientHeight),ready:!!this.atlas,count:this.atlas?.steps.length??0,selected:this.selectedStep?.[0]??null,site:this.processSite,anchor:this.anchor,patchOpacity:this.patchOpacity,processVisible:this.processReveal>0&&!!this.processSite&&this.models.has(this.processSite),reveal:this.processReveal,detail:this.processDetail,progress:this.processProgress,playing:this.processPlaying,loop:this.processLoop,slow:this.processSlow,models:this.models.size,focusHeight:this.focusOffset,model:this.processSite?this.models.get(this.processSite)?.diagnostics(this.nav.camera,this.canvas.clientWidth,this.canvas.clientHeight)??null:null,processBearing:this.processSite?ia(this.processSite).bearing:null,processDistance:this.processSite?ia(this.processSite).d:null},shell:{radii:Qi(this.shell.expanded),cut:this.shell.cut,expanded:this.shell.expanded,lithosphere:this.shell.lithosphere,selected:this.shell.selected,visible:[...this.shell.visible],opacity:[...this.shell.opacity],subdued:this.shell.subdued,builds:this.shell.builds,shadowPass:this.sun.castShadow,transparentParts:this.shell.group.children.filter(o=>o.visible&&o instanceof Ne&&o.material.transparent).length},localReady:this.local.ready,localVisible:this.local.group.visible,draws:this.gl.info.render.calls,triangles:this.gl.info.render.triangles,...this.gl.info.memory}}render=e=>{if(!this.running)return;if(requestAnimationFrame(this.render),document.hidden){this.last=0;return}(!this.last||e-this.last>2e3)&&(this.fpsStart=e,this.frameCount=0,this.resolution.resetWindow()),this.frameMs=this.last?e-this.last:0;const t=ct((e-this.last)/1e3,.001,.12);if(this.last=e,this.sizeDirty&&this.applySize(),this.frames++,this.frameCount++,e-this.fpsStart>=900){this.fps=this.frameCount*1e3/(e-this.fpsStart);const y=this.resolution.sample(this.fps,(e-this.fpsStart)/1e3);y!==void 0&&this.gl.setPixelRatio(y),this.frameCount=0,this.fpsStart=e}this.advanceNyosTime();const n=!!this.nyosAutoFlight&&this.nav.flight===this.nyosAutoFlight&&!this.nyosLesson.playing&&this.nyosLesson.progress<1;this.nav.update(e,t,({lat:y,lon:x,d:v})=>{const w=this.mode==="inside"&&(!this.waitingForAscent||v>=3500);this.updateNyos(y,x,v,w);let M=w?0:Math.max(...Array.from(this.terrains.values(),T=>T.ground(y,x)),this.planet.elevation(y,x));if(this.nyos.localWeight>0){const T=this.nyos.ground(y,x);T!==null&&(M+=(T-M)*this.nyos.localWeight)}this.nyosGround=M,this.updateTectonics(Math.min(this.frameMs/1e3,.45)),this.focusOffset=this.focusReveal*uM;const A=this.nyosSectionActive()?-.07*this.nyos.localWeight:0;return this.nav.reducedMotion.matches?this.nyosFocusOffset=A:n||(this.nyosFocusOffset+=(A-this.nyosFocusOffset)*(1-Math.exp(-6*t))),M+this.focusOffset+this.nyosFocusOffset},this.mode==="nyos"&&this.nyos.ready?(y,x)=>this.nyos.ground(y,x):void 0,n);const{lat:s,lon:r,d:o}=this.nav.pose;(o>=3500||!this.nav.flight)&&(this.waitingForAscent=!1);const a=this.mode==="inside"&&!this.waitingForAscent,l=1-tt((o-2)/58),c=this.nyosLesson.view==="lake"||this.nyosLesson.view==="protection"&&this.nyosLesson.measure==="settlements";this.globeOccluded=c&&this.nyos.localWeight===1&&!!this.nyosCoverage?.containsView(this.nav.camera),this.mosaic&&!this.mosaic.group.visible&&this.mode==="plates"&&!this.processSite&&o>=340&&this.mosaic.open(this.nav.camera.position,this.nav.reducedMotion.matches),this.mosaic?.tick(Math.min(.3,this.frameMs/1e3),this.nav.reducedMotion.matches,!!this.nav.flight);const h=!!this.mosaic?.group.visible;this.planet.group.visible=!a&&!h&&!this.globeOccluded,this.shell.group.visible=a,this.air.visible=!a&&o>2200,this.grid.visible=!h&&!a&&o>2400;const u=performance.now();this.planet.group.visible&&this.planet.update(s,r,o),this.terrainMs=performance.now()-u;for(const y of this.terrains.values())(y===this.local||y.ready)&&y.update(s,r,o,e),(a||h)&&(y.group.visible=!1);const d=$n(s,r),f=Ke(s,r),g=d.up.clone().multiplyScalar(.91).addScaledVector(d.north,1.05).addScaledVector(d.east,-1.2).normalize();this.planet.lightDirection(g),this.nyos.lightDirection(g);const _=this.local.group.visible&&o<2.3;if(this.sun.castShadow=_,this.sun.target.position.copy(f),this.sun.position.copy(f).addScaledVector(g,_?4:2e4),_){const y=this.sun.shadow.camera,x=o>1?2.5:.9,v=Ke(Math.round(s*150)/150,Math.round(r*100)/100);this.sun.target.position.copy(v),this.sun.position.copy(v).addScaledVector(g,4),Object.assign(y,{left:-x,right:x,top:x,bottom:-x,near:.1,far:9}),y.updateProjectionMatrix(),this.sun.shadow.bias=-12e-5,this.sun.shadow.normalBias=3e-4;const w=[Math.round(s*150),Math.round(r*100),x.toFixed(3),this.style,this.local.ready].join("/");w!==this.shadowStamp&&(this.gl.shadowMap.needsUpdate=!0,this.shadowStamp=w)}const m=this.scene.fog;m.density=Math.min(.085,.28/Math.max(1,o))*l,m.density>1e-4&&(this.nav.camera.far=Math.min(this.nav.camera.far,Math.max(o*2.5,3.6/m.density)),this.nav.camera.updateProjectionMatrix()),this.gl.setClearColor(11324368,l);const p=performance.now();this.gl.render(this.scene,this.nav.camera),this.renderMs=performance.now()-p,this.onFrame?.()}}function pM(i){return`<h2 id="dialogTitle">P- und S-Wellen</h2>
  <figure class="waveFigure">
    <svg viewBox="0 0 640 216" role="img" aria-labelledby="waveTitle waveDesc">
      <title id="waveTitle">Vereinfachtes Modell einer Materialgrenze</title>
      <desc id="waveDesc">Die P-Welle läuft vom festen Material in die Flüssigkeit weiter. Die direkte S-Welle reicht nur bis zur Grenze.</desc>
      <rect x="0" y="0" width="320" height="216" fill="#35413c"/><rect x="320" width="320" height="216" fill="#193845"/>
      <path d="M320 0v216" stroke="#dae6dd" stroke-dasharray="5 6"/>
      <g fill="#f0f3e9" font-size="24"><text x="24" y="38">Festes Material</text><text x="345" y="38">Flüssigkeit</text></g>
      <g fill="#efc485" font-size="27" font-weight="600"><text x="24" y="95">P</text></g>
      <g fill="#a1ddd5" font-size="27" font-weight="600"><text x="24" y="165">S</text></g>
      <g fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="6">
        <path d="M78 86H567m-14 -12 14 12-14 12" stroke="#efc485"/>
        <path d="M78 156H315m0 -12v24" stroke="#a1ddd5"/>
      </g>
    </svg><figcaption>Vereinfachtes Modell der Ausbreitung</figcaption>
  </figure>
  <p><strong>P-Wellen</strong> drücken Material zusammen und dehnen es wieder aus. Sie laufen durch feste Stoffe und Flüssigkeiten.</p>
  <p><strong>S-Wellen</strong> bewegen Material quer zur Ausbreitungsrichtung. Sie laufen durch feste Stoffe. In Flüssigkeiten breiten sie sich nicht aus.</p>
  ${i?"<p class='inference'>Dass der äußere Erdkern flüssig ist, erschließen Forschende aus dem Muster der P- und S-Wellen vieler Erdbeben.</p>":""}`}const mM=""+new URL("nyos-geowissenschaften-CMkF37u1.md",import.meta.url).href,gM=`<h2 id="dialogTitle">Zum Nyos-See</h2>
<p>Der See füllt einen Maar-Krater. Neuere Untersuchungen sprechen dafür, dass er durch das Zusammentreffen von Magma und Wasser entstand. Sein genaues Alter ist umstritten. Er liegt an der Kamerun-Vulkanlinie, einer Reihe vulkanischer Gebiete innerhalb der Afrikanischen Platte.</p>
<p>Das CO₂ stammt überwiegend aus tief liegendem Magma und gelangt mit Grundwasser in den See. Dort kann es sich gelöst im Tiefenwasser anreichern. Die gezeichnete Beckenform und die Schichten sind schematisch.</p>
<p>Am 21. August 1986 entwich gespeichertes CO₂ plötzlich aus dem See. Das war eine limnische Gasfreisetzung, keine erneute magmatische Eruption. Der genaue Auslöser ist unklar. <a href="${mM}" target="_blank" rel="noopener">Fachquellen und Modellgrenzen (Textdatei, neuer Tab)</a></p>`,vM=`<details id="nyos-historic-places">
  <summary style="min-height:var(--hit);padding:10px 0;cursor:pointer;align-content:center">Orte von 1986</summary>
  <p class="nyosCaption">Nyos, Cha und Subum sind als betroffene Orte des Ereignisses von 1986 dokumentiert.</p>
  <figure style="margin:10px 0">
    <svg viewBox="0 0 240 148" width="240" height="148" style="display:block;width:100%;height:auto" aria-hidden="true" focusable="false">
      <g fill="none" stroke="#a9bcb0" stroke-width="3" stroke-linecap="round">
        <path d="M42 58 Q75 88 118 81 Q162 68 194 38"/>
        <path d="M118 81 Q108 99 121 119"/>
      </g>
      <ellipse cx="122" cy="125" rx="25" ry="12" fill="#3f7977" stroke="#b6ddd3" stroke-width="1.5"/>
      <g fill="#edf2ed" font-family="inherit" font-size="17" text-anchor="middle">
        <text x="32" y="45">Cha</text>
        <text x="116" y="65">Nyos</text>
        <text x="190" y="25">Subum</text>
        <text x="177" y="130">See</text>
      </g>
    </svg>
    <figcaption style="color:var(--muted);font-size:.9em;line-height:1.4">Orte und Talsystem · nicht maßstäblich</figcaption>
  </figure>
  <p class="nyosCaption">Nyos liegt im Tal nördlich des Sees, Cha westlich und Subum nordöstlich davon. Täler können die Ausbreitung einer dichten CO₂-reichen Luftmasse lenken.</p>
  <p class="nyosCaption" style="font-size:.9em">Historische Ortsbezüge nach <a href="https://doi.org/10.1136/bmj.298.6685.1437" target="_blank" rel="noopener">Baxter et al. (1989), Abb. 1 (neuer Tab)</a>.</p>
</details>`,_u=[["lake","See"],["section","Im See"],["event","CO₂-Freisetzung"],["protection","Schutzmaßnahmen"]];function Nl(i,e,t){return`<label class="nyosCheck"><input id="nyos-${i}" type="checkbox" ${t?"checked":""}>${e}</label>`}function rl(i){const e=i.view==="protection"?"Weniger Violett zeigt, wie der Vorrat über Jahre sinken kann.":"CO₂ aus dem Untergrund reichert sich im Tiefenwasser an.";return`<div id="nyos-water-control">${Nl("dissolved","Gelöstes CO₂ zeigen",i.dissolved)}
    <p id="nyos-key" class="nyosKey dissolvedKey" ${i.dissolved?"":"hidden"}>Analysefarbe Violett · ${e}</p></div>`}function xu(i){return`<div class="regionScale"><button class="playButton" id="nyos-play">Start</button>
      <button id="nyos-reset">Zurücksetzen</button></div>
    ${Nl("slow","Zeitlupe",i.slow)}`}function yu(i){return i<.17?"Unter der ruhigen Oberfläche ist CO₂ im Tiefenwasser gelöst. Was den ersten Aufstieg auslöste, ist ungeklärt.":i<.33?"Steigt Tiefenwasser auf, nimmt der Druck ab.":i<.53?"CO₂ tritt aus der Lösung aus. Die Blasen verstärken den Auftrieb und reißen weiteres Wasser mit.":i<.68?"An der Oberfläche entweicht das Gas. In der Luft ist CO₂ unsichtbar.":i<.87?"CO₂-reiche Luft kann in tieferes Gelände fließen. Wind und Durchmischung verändern ihren Weg und verdünnen sie.":"In tieferen Talräumen waren Menschen besonders gefährdet. Unter anderem waren Nyos, Cha und Subum betroffen."}function Mu(i){return i<.27?"2001 ging das erste dauerhafte Entgasungsrohr in Betrieb. Das Rohr leitet Tiefenwasser zur Oberfläche.":i<.65?"Beim Aufstieg sinkt der Druck. Gasblasen im Rohr treiben den Wasserstrom an. Oben entweicht das CO₂ kontrolliert.":"Wird über Jahre mehr CO₂ entnommen als nachströmt, sinkt der Gasvorrat im See."}const _M=[["pipe","Kontrollierte Entgasung"],["monitor","Messprofil"],["settlements","Räumliche Vorsorge"]];function xM(i){const t=`<label class="nyosChoose" for="nyos-measure">Maßnahme</label>
    <select id="nyos-measure">${_M.map(([n,s])=>`<option value="${n}" ${i.measure===n?"selected":""}>${s}</option>`).join("")}</select>`;return i.measure==="pipe"?t+`<p class="nyosCaption" id="nyos-pipe-text" aria-live="polite">${Mu(i.progress)}</p>
    ${xu(i)}${rl(i)}`:i.measure==="monitor"?t+'<p class="nyosCaption">Eine Sonde misst in verschiedenen Tiefen. Wiederholte Messungen zeigen, wie sich Schichtung und Gasgehalt verändern.</p>':t+`<p class="nyosCaption">Talboden und Hang zeigen zwei mögliche Lagen für Siedlungen. Das Relief spielt bei Warnung und Vorsorge eine Rolle.</p>
    <p class="nyosKey">Beispielstandorte im heutigen Relief</p>`}function yM(i){const e=i.nyosLesson;return e.view==="protection"?xM(e):e.view==="lake"?`<div class="regionScale" role="group" aria-label="Kartenausschnitt">
    <button id="nyos-overview" aria-pressed="${!i.nyosDetail}">Region</button>
    <button id="nyos-near" aria-pressed="${i.nyosDetail}">Zum See</button></div>`:e.view==="event"?`<p id="nyos-phase" class="nyosCaption" aria-live="polite">${yu(e.progress)}</p>
    ${xu(e)}${rl(e)}
    <div id="nyos-air-control" hidden>${Nl("air","Gas in der Luft zeigen",e.air)}
      <p id="nyos-air-key" class="nyosKey dissolvedKey" hidden>CO₂ ist farblos. Die Analysefarbe zeigt eine mögliche Ausbreitung im Relief. Verlauf und Reichweite sind schematisch.</p></div>
    <div id="nyos-places" hidden>${vM}</div>`:`<p class="nyosCaption">Leichteres Wasser liegt oben. Das dichtere Tiefenwasser mischt sich nur wenig mit ihm.</p>
    ${rl(e)}`}function MM(i){return i.nyos.error?`<h1>Nyos-See</h1><p class="nyosCaption">Die Übersicht zeigt die Lage in Kamerun.</p>
    <button id="nyos-near">Geländedaten erneut laden</button>`:`<h1>Nyos-See</h1><p class="nyosLocation">Kamerun</p>
    <div class="nyosViews" role="group" aria-label="Ansicht am Nyos-See">${_u.map(([t,n])=>`<button id="nyos-${t}" aria-label="${n}" aria-pressed="${i.nyosLesson.view===t}">${t==="protection"?"Schutz":n}</button>`).join("")}</div>
    <div class="nyosDetail">${yM(i)}</div>`}function SM(i,e,t){const n=e.nyosLesson,s=a=>{t(),document.getElementById(a)?.focus({preventScroll:!0})};for(const[a]of _u)i.querySelector("#nyos-"+a)?.addEventListener("click",()=>{e.showNyos(a),s("nyos-"+a)});const r=i.querySelector("#nyos-measure");r?.addEventListener("change",()=>{e.showNyosMeasure(r.value),s("nyos-measure")});for(const a of["dissolved","slow","air"]){const l=i.querySelector("#nyos-"+a);l?.addEventListener("change",()=>{n[a]=l.checked,to(e)})}const o=()=>{const{dissolved:a,air:l}=n;e.showNyos(n.view),n.dissolved=a,n.air=l};i.querySelector("#nyos-play")?.addEventListener("click",()=>{if(n.progress>=1){const a=n.slow;o(),n.slow=a}n.togglePlayback(),to(e)}),i.querySelector("#nyos-reset")?.addEventListener("click",()=>{o(),s("nyos-reset")});for(const[a,l]of[["nyos-overview",!0],["nyos-near",!1]])i.querySelector("#"+a)?.addEventListener("click",()=>{e.visit("nyos",l),s(a)})}function Hr(i,e){const t=document.getElementById(i);t&&t.textContent!==e&&(t.textContent=e)}function ji(i,e){const t=document.getElementById(i);t&&t.hidden===e&&(t.hidden=!e)}function to(i){const e=i.nyosPin(),t=document.getElementById("nyosPin");t.hidden=!e,e&&(t.style.left=e.x+"px",t.style.top=e.y+"px");const n=i.nyosLesson,s=n.view==="protection"&&n.measure==="settlements";if(ji("nyosRelief",s),s){const l=i.nyosReliefLabels();for(const c of["Talboden","Hang"]){const h=document.getElementById("nyos-"+c),u=l.find(d=>d.label===c);h.hidden=!u,u&&(h.style.left=u.x+"px",h.style.top=u.y+"px")}}ji("nyos-key",n.dissolved),(n.view==="event"||n.view==="protection"&&n.measure==="pipe")&&Hr("nyos-play",n.playing?"Pause":n.progress>=1?"Wiederholen":n.progress>0?"Fortsetzen":"Start"),n.view==="protection"&&n.measure==="pipe"&&Hr("nyos-pipe-text",Mu(n.progress)),n.view==="event"&&(Hr("nyos-phase",yu(n.progress)),ji("nyos-water-control",n.progress<.53),ji("nyos-air-control",n.progress>=.5),ji("nyos-air-key",n.air),ji("nyos-places",n.progress>=.87));const r=i.nav.pose.d,o=n.view==="event"?"1986 · Historisches Erklärungsmodell":n.view==="protection"?s?"Nach 1986 · Räumliche Vorsorge":"Nach 1986 · Geräte vergrößert":n.view==="section"?"Seequerschnitt · Beckenform schematisch":r>3800?"Afrika":r>900?"Kamerun":r>105?"Kamerun-Vulkanlinie":r>12?"Region um den Nyos-See":"",a=document.getElementById("modelnote");a.classList.remove("exaggerated"),a.hidden=!o,Hr("modelnote",o)}const Su={island:{kind:"divergent",direction:"Auseinander",text:"Beim Aufsteigen schmilzt ein Teil des festen Gesteins durch sinkenden Druck. Kühlt die Schmelze ab, entsteht neuer Ozeanboden."},japan:{kind:"convergent",direction:"Aufeinander zu",text:"Hier taucht die Pazifische Platte ab. An anderen Grenzen können zwei Kontinente zusammenstoßen."},san:{kind:"transform",direction:"Aneinander vorbei",text:"Bei Parkfield bewegen sich beide Seiten seitlich aneinander vorbei. Verhakt sich die Störung, kann sich die Spannung ruckartig in einem Erdbeben lösen."}};function bM(i){return Object.hasOwn(Su,i)}const wM={divergent:"Zwei Platten bewegen sich voneinander weg.",convergent:"Zwei Platten bewegen sich aufeinander zu. An manchen Grenzen taucht eine Platte unter die andere ab.",transform:"Zwei Platten bewegen sich seitlich aneinander vorbei."},ra={divergent:"Auseinander",convergent:"Aufeinander zu",transform:"Aneinander vorbei"},EM=Object.entries(qn).sort((i,e)=>i[1].localeCompare(e[1],"de")),Vn=(i,e,t)=>`<label class="plateCheck"><input type="checkbox" id="${i}" ${t?"checked":""}>${e}</label>`;function AM(i){const e=i.plateOptions,t=i.processSite,n=`<label class="siteSelect">Bewegungen ansehen<select id="tectonicSite"><option value="">Weltkarte</option>${Object.entries({island:"Island – auseinander",japan:"Japan – aufeinander zu",san:"Kalifornien – aneinander vorbei"}).map(([d,f])=>`<option value="${d}" ${d===t?"selected":""}>${f}</option>`).join("")}</select></label>`;if(t){const d=Su[t];return`<h1>${d.direction}</h1>${n}
      <div class="regionScale" role="group" aria-label="Blick auf die Region"><button id="regionalOverview" aria-pressed="${!i.processDetail}">Region</button><button id="localProcess" aria-pressed="${i.processDetail}">Prozessmodell</button></div>
      ${Vn("plateNames","Namen zeigen",e.names)}
      ${i.processDetail?`
        <div class="playback"><button id="playProcess" class="playButton" aria-pressed="${i.processPlaying}"></button><button id="resetProcess" aria-label="Bewegung zurücksetzen" title="Bewegung zurücksetzen"><i data-lucide="rotate-ccw" aria-hidden="true"></i></button></div>
        <div class="playSettings">${Vn("slowProcess","Zeitlupe",i.processSlow)}${Vn("loopProcess","Wiederholen",i.processLoop)}</div>
        ${e.names?`<details id="processText"><summary>Weitere Einstellungen</summary><label class="siteSelect">Begriff hervorheben<select id="objectChoice"><option value="">Grundauswahl</option>${i.processObjects().map(f=>`<option value="${f.id}" ${i.processChoice===f.id?"selected":""}>${f.name}</option>`).join("")}</select></label><p>${d.text}</p></details>`:""}`:""}
      <button id="plateOverview" class="atlasReturn"><i data-lucide="globe-2" aria-hidden="true"></i> Zur Plattenkarte</button>`}const s=`<fieldset id="kindFilter"><legend>Grenztyp hervorheben</legend>
    ${["all","divergent","convergent","transform"].map(d=>`<label><input type="radio" name="kindFilter" value="${d}" ${e.category===d?"checked":""}><span>${d==="all"?"":`<i class="swatchDot ${d}"></i>`}${d==="all"?"Alle":ra[d]}</span></label>`).join("")}</fieldset>`,r=i.selectedBoundary,o=i.profiles[i.profileCode],a=`<div class="playback"><button id="atlasPlay" class="playButton" ${i.mosaic?"":"disabled"}>Platten bewegen</button>
    <button id="atlasReset" aria-label="Bewegung zurücksetzen" title="Bewegung zurücksetzen"><i data-lucide="rotate-ccw" aria-hidden="true"></i></button></div>
    ${Vn("atlasSlow","Langsamer",i.mosaic?.slow??!1)}`,l=i.mosaic?.pair;if(l&&o)return`<h1>Grenzvergleich</h1><section class="scienceCard"><h2>${o.where}</h2>
      <p>${qn[l.bodies[0].name]} und ${qn[l.bodies[1].name]}</p>
      <strong>${ra[i.pairKind]}</strong><p>Beobachte den hellen Streifen im Gestein.</p></section>
      ${a}<button id="atlasWorld" class="atlasReturn">Zur Weltansicht</button>${n}`;const c=o?'<div class="panelHead"><h1>Plattentektonik</h1><button id="atlasAll" aria-label="Steckbrief schließen" title="Schließen">×</button></div>':"<h1>Plattentektonik</h1>",h=o?`<section class="scienceCard" id="plateProfile" aria-live="polite">
    <h2>${qn[i.profileCode]}</h2><dl><dt>Lage</dt><dd>${o.place}</dd>
    <dt>Bewegung</dt><dd>${o.motion}</dd><dt>Beispiel an einer Plattengrenze</dt><dd>${o.boundary}</dd></dl>
    <div class="profileActions"><button id="atlasLocate">Zentrieren</button><button id="atlasCompare">Grenze ansehen</button><button id="atlasWorld">Weltansicht</button></div></section>`:"",u=`<div class="playback"><button id="atlasPlay" class="playButton" ${i.mosaic?"":"disabled"}>Platten bewegen</button></div>`;return`${c}${u}${h}
    <div class="plateChecks">${Vn("boundaries","Plattengrenzen zeigen",e.boundaries)}
    ${Vn("plateNames","Namen zeigen",e.names||i.singlePlateName)}</div>
    ${n}
    ${e.boundaries&&!e.names&&e.plate?Vn("onePlateName","Gewählten Namen zeigen",i.singlePlateName):""}
    <details id="plateSettings"><summary>Weitere Einstellungen</summary>
    ${Vn("boundaryTypes","Grenztypen unterscheiden",e.types)}
    ${e.types?s:""}
    ${e.names?Vn("smallPlates","Auch kleinere Platten im Fernblick benennen",i.smallPlateNames):""}
    <label class="siteSelect">Platte auswählen<select id="plateSelect"><option value="">Keine</option></select></label>
    </details>
    ${e.boundaries?`<p class="boundaryHint" aria-live="polite">${r?`<strong>${ra[r.kind]}</strong><br>${wM[r.kind]}${e.names?"<br>"+r.plates.join(" · "):""}`:"Eine Fläche oder Grenze auf dem Globus antippen."}</p>`:""}`}function TM(i,e,t){const n=h=>{t(),document.getElementById(h)?.focus({preventScroll:!0})},s=(h,u)=>{const d=i.querySelector("#"+h);d&&(d.onchange=()=>u(d.checked))};for(const[h,u]of[["boundaries","boundaries"],["plateNames","names"],["boundaryTypes","types"]])s(h,d=>{u==="names"&&!d&&!e.processSite&&e.inspectPlate(""),e.setPlateOptions(u==="types"&&d?{types:!0,boundaries:!0}:{[u]:d}),n(h)});s("smallPlates",h=>{e.smallPlateNames=h,n("smallPlates")});const r=i.querySelector("#objectChoice");r&&(r.onchange=()=>{e.processChoice=r.value}),s("onePlateName",h=>{e.singlePlateName=h,n("onePlateName")});for(const h of i.querySelectorAll("#kindFilter input"))h.onchange=()=>{const u=e.selectedBoundary;e.setPlateOptions({category:h.value}),u&&!e.selectedBoundary&&(t(),i.querySelector("#kindFilter input:checked")?.focus({preventScroll:!0}))};const o=i.querySelector("#plateSelect"),a=i.querySelector("#plateSettings");if(o&&a){const h=()=>{if(!a.open&&!e.plateOptions.names){o.length=1;return}if(o.length===1){for(const[u,d]of EM)o.add(new Option(d,u));o.value=e.plateOptions.plate}};a.ontoggle=h,h()}o&&(o.onchange=()=>{e.inspectPlate(o.value),n("plateSelect")});const l=i.querySelector("#tectonicSite");l.onchange=()=>{bM(l.value)?e.visit(l.value):e.plateOverview(),n("tectonicSite")};const c=(h,u)=>i.querySelector("#"+h)?.addEventListener("click",u);c("atlasPlay",()=>{const h=!!e.mosaic?.pair;e.comparePlates(!0),h||n("atlasPlay"),Zi(e)}),c("atlasCompare",()=>{e.comparePlates(!1),n("atlasPlay")}),c("atlasReset",()=>{e.mosaic?.reset(),Zi(e)}),c("atlasAll",()=>{e.inspectPlate(""),n("atlasPlay")}),c("atlasWorld",()=>{e.atlasWorld(),n("atlasPlay")}),c("atlasLocate",()=>e.locatePlate()),s("atlasSlow",h=>{e.mosaic&&(e.mosaic.slow=h)}),c("regionalOverview",()=>{e.visit(e.processSite,!0),n("regionalOverview")}),c("localProcess",()=>{e.visit(e.processSite),n("localProcess")}),c("plateOverview",()=>{e.plateOverview(),n("tectonicSite")}),c("playProcess",()=>{e.toggleProcess(),Zi(e)}),c("resetProcess",()=>{e.resetProcess(),Zi(e)}),s("slowProcess",h=>{e.processSlow=h}),s("loopProcess",h=>{e.processLoop=h}),Zi(e)}function Zi(i){const e=document.getElementById("atlasPlay");if(e&&i.mosaic){const{playing:s,progress:r}=i.mosaic,o=s?"Pause":r>=1?"Erneut bewegen":r>0?"Fortsetzen":"Platten bewegen";e.textContent!==o&&(e.textContent=o),e.setAttribute("aria-pressed",String(s))}const t=document.getElementById("playProcess");if(!t)return;const n=i.processPlaying?"Pausieren":i.processProgress>=1?"Erneut abspielen":i.processProgress>0?"Fortsetzen":"Abspielen";t.textContent!==n&&(t.textContent=n,t.setAttribute("aria-pressed",String(i.processPlaying)))}const CM={Globe2:o_,Layers3:h_,MapPin:u_,Maximize:d_,Minimize:f_,Info:c_,Plus:v_,Minus:p_,RotateCcw:__,Waypoints:y_,Orbit:g_,Compass:r_,X:M_,Eye:l_,EyeOff:a_,Navigation2:m_,Waves:x_},en=i=>`<i data-lucide="${i}" aria-hidden="true"></i>`,Ol=()=>S_({icons:CM,attrs:{"stroke-width":1.65}}),Ki=(i,e,t)=>`<button type="button" id="${i}" aria-label="${e}" title="${e}">${en(t)}</button>`,RM='<svg class="brandmark" width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden="true"><defs><clipPath id="disc"><circle cx="20" cy="20" r="16"/></clipPath></defs><circle cx="20" cy="20" r="16" fill="currentColor"/><g clip-path="url(#disc)" stroke="#17251f" stroke-width="2.4"><path d="M-5 19Q6 30 18 12T45 5M-5 26Q7 37 22 17T46 13M-4 33Q10 44 26 23T48 20M0 39Q13 50 30 29T49 28"/></g></svg>',Fl=new URLSearchParams(location.search).get("unterricht")==="schalenbau",be=i=>document.getElementById(i);be("app").innerHTML=`<header><div class="brand">${RM}<span>GeoRisiko <b>3D</b></span></div>
  <nav aria-label="Modellansicht">${[["globe","Globus","globe-2"],["inside","Schalenschnitt","layers-3"],["plates","Plattentektonik","waypoints"],["nyos","Nyos-See","waves"],["place","Orte","map-pin"]].map(([i,e,t])=>`<button id="nav-${i}">${en(t)}<span>${e}</span></button>`).join("")}</nav>
  <div class="headTools">${Ki("info","Modellhinweise und Quellen","info")}<button id="present" aria-label="Präsentieren" aria-pressed="false">${en("maximize")}<span>Präsentieren</span></button></div></header>
  <main id="desk" data-mode="globe"><aside id="sidebar" hidden aria-label="Modellsteuerung"></aside>
  <section class="view" aria-label="Interaktive 3D-Ansicht"><canvas id="earth" tabindex="0" aria-label="Drehbares Erdmodell. Pfeiltasten drehen, Plus und Minus zoomen."></canvas>
  <div class="orientation" title="Geografischer Norden">${en("navigation-2")} N</div>
  <div class="tools"><button id="orbitProcess" hidden aria-label="Prozessmodell drehen" title="Prozessmodell drehen">${en("orbit")}</button>${Ki("in","Vergrößern","plus")}${Ki("out","Verkleinern","minus")}${Ki("tilt","Neigung ändern","compass")}${Ki("home","Zur Startansicht zurücksetzen","rotate-ccw")}</div>
  <div id="pins" class="annotations"></div>
  <span id="nyosPin" hidden aria-hidden="true">Nyos-See</span><div id="platePins" class="annotations"></div>
  <div id="nyosRelief" hidden aria-hidden="true"><span id="nyos-Talboden" hidden>Talboden</span><span id="nyos-Hang" hidden>Hang</span></div>
  <div id="modelnote" hidden></div><div class="hint">Ziehen zum Drehen · Mit zwei Fingern oder Mausrad zoomen</div></section></main>
  <div id="status" role="status">Erdmodell wird geladen …</div>
  <dialog id="dialog" aria-labelledby="dialogTitle">${Ki("closeDialog","Schließen","x")}<div id="content"></div></dialog>`;if(Fl)for(const i of["plates","nyos","place"])be("nav-"+i).hidden=!0;const bu=be("desk"),mt=be("sidebar"),Yn=be("dialog"),rs=be("content"),ol=be("status");let q,yt=!1,Qs=!1,wu="";const Lt=new Set;let fs="",Ei=0;function co(i){const e=q.mode==="inside"?Qt.findIndex(a=>a.name===i.name):-1;if(e>=0&&!(yt||Lt.has(e)))return;const t=document.activeElement;e>=0&&q.shell.selected!==e&&Bl(e);const n=be("definition");if(!n)return;const s=document.createElement("strong"),r=document.createElement("p"),o=document.createElement("button");if(s.textContent=i.name,r.id="layerText",r.textContent=i.text,o.textContent="Schließen",o.onclick=()=>{n.replaceChildren(),n.hidden=!0,fs="",t instanceof HTMLElement&&t.isConnected&&t.focus({preventScroll:!0})},n.replaceChildren(s,r,o),e>=0){const a=Qt[e],l=e===0?"sie":"er",c=document.createElement("div"),h=document.createElement("p");c.className="shellQuestions",h.hidden=!0,h.id="shellAnswer";for(const[u,d]of[[`Woraus besteht ${l}?`,a.material],[`Wie ist ${l} entstanden?`,a.origin]]){const f=document.createElement("button");f.textContent=u,f.setAttribute("aria-expanded","false"),f.setAttribute("aria-controls",h.id),f.onclick=()=>{const g=f.getAttribute("aria-expanded")==="false";for(const _ of c.querySelectorAll("button"))_.setAttribute("aria-expanded","false");f.setAttribute("aria-expanded",String(g)),h.textContent=g?d:"",h.hidden=!g},c.append(f)}n.insertBefore(c,o),n.insertBefore(h,o)}n.hidden=!1,mt.scrollTop=0,o.focus({preventScroll:!0}),fs=""}const Eu=new Eh(be("pins"),co),Au=new Eh(be("platePins"),i=>{if(q.processSite)co(i);else{const e=!!q.mosaic?.pair;q.inspectPlate(i.id),e&&q.locatePlate(),Bt()}});function al(i){wu=i,ol.textContent=i}function PM(){if(q?.mode==="nyos"){rs.innerHTML=gM,Fs();return}if(q?.mode==="plates"){rs.innerHTML=`<h2 id="dialogTitle">Über die Plattenmodelle</h2><p>Nur das Kartenbild öffnet sich. Jede Platte umfasst die Kruste und den starren obersten Mantel. Darunter liegt überwiegend festes, langsam verformbares Gestein. Die Farben und die überhöhte Plattendicke helfen bei der Unterscheidung.</p><p>Der Atlas zeigt die heutigen Plattengrenzen. Im Grenzvergleich bewegen sich zwei starre Gesteinsausschnitte relativ zueinander. Ihre Richtung folgt den Rotationspolen von PB2002. Deren Ausgangsdaten beziehen sich auf die Pazifische Platte. Im Vergleich ist die Bewegung auf beide Seiten verteilt. Zeit, Abstand und Dicke sind schematisch. Der neutrale Untergrund dient als Zeichenfläche. Die Linien folgen dem globalen Plattenmodell PB2002. In der Natur kann sich die Verformung über eine breite Zone verteilen.</p><p>Das regionale Satellitenbild zeigt die Landschaft. Der vergrößerte Schnitt darüber erklärt den Prozess schematisch. Pfeillängen, Schichtdicken und Spielzeit haben keinen gemeinsamen Maßstab.</p><p><a href="${os("licenses/Geodaten.txt")}" target="_blank" rel="noopener">Quellen und Nutzungsrechte</a></p>`,Fs();return}rs.innerHTML=`<h2 id="dialogTitle">Über das Modell</h2><p>Die Farben sind Modellfarben. Der Keil macht die Schalen im Inneren sichtbar.</p><p>${yt?"Die Kruste ist im Referenzmodell überall 35 km dick. In der Natur variiert ihre Dicke.":"Die äußerste Schale hat im Referenzmodell überall dieselbe Dicke. In der Natur ist sie unterschiedlich dick."} Beim Verbreitern der Außenschale bleiben der Erdradius und die tieferen Grenzen gleich.</p><p><a href="${os("licenses/Geodaten.txt")}" target="_blank" rel="noopener">Geodaten und Bildquellen</a></p>${Fl?'<p><a href="?">Gesamtanwendung öffnen</a></p>':""}`,Fs()}function Fs(){Yn.open||Yn.showModal(),be("closeDialog").focus()}function Sh(i){return yt||Lt.has(i)?Qt[i].name:`Schale ${i+1}`}function LM(){const i=q.shell,e=i.selected,t=e===null?"disabled":"",n=yt||Lt.size>0,s=`<div class="shellActions"><button id="isolate" ${t}>Einzeln zeigen</button><button id="subdue" aria-pressed="${i.subdued}" ${t}>Umfeld dimmen</button><button id="restoreLayers">${en("rotate-ccw")} Alle zeigen</button></div>
  <label class="range" for="opacity">Deckkraft<input id="opacity" type="range" min="15" max="100" ${t} value="${e===null?100:i.opacity[e]*100}" aria-label="Deckkraft der gewählten Schale"></label>`,r=`<label><input id="cut" type="checkbox" ${i.cut?"checked":""}> Keilschnitt</label>`,o=`<label><input id="scale" type="checkbox" ${i.expanded?"checked":""}> ${yt?"Kruste":"Außenschale"} verbreitern</label>`,a=`<label><input id="lithosphere" type="checkbox" ${i.lithosphere?"checked":""} ${i.cut&&i.visible[0]&&i.visible[1]?"":"disabled"}> ${yt?"Lithosphäre vergleichen":"Starren Außenbereich vergleichen"}</label>`,l=`<button id="evidence">${en("waves")} P- und S-Wellen</button>`;return`<div class="panelHead"><h1>Schalen</h1><button id="labels" title="Beschriftungen durch die Lehrkraft umschalten" aria-pressed="${yt?"true":n?"mixed":"false"}">${en(n?"eye-off":"eye")}${n?"Namen verbergen":"Namen zeigen"}</button></div>
  <div class="layerlist">${Qt.map((c,h)=>`<div class="layer ${e===h?"chosen":""}" style="--rock:#${c.color.toString(16)}"><button data-layer="${h}" aria-pressed="${e===h}"><span class="swatch" aria-hidden="true">${yt?h+1:""}</span>${Sh(h)}</button><button class="eye" data-eye="${h}" aria-label="${Sh(h)} ${i.visible[h]?"ausblenden":"einblenden"}" aria-pressed="${i.visible[h]}">${en(i.visible[h]?"eye":"eye-off")}</button></div>`).join("")}</div>
  ${e===null?"":yt||Lt.has(e)?'<div class="nameActions"><button id="explainLayer">Erklärung öffnen</button><button id="hideOne">Diesen Namen verbergen</button></div>':'<button id="revealOne">Einzelnen Namen zeigen</button>'}
  ${!yt&&Lt.size?'<button id="allNames">Alle Namen zeigen</button>':""}
  ${Fl?`<div class="options">${o}</div><details id="shellOptions"><summary>Weitere Modelloptionen</summary>${s}<div class="options">${r}${a}</div>${l}</details>`:`${s}<div class="options">${r}${o}${a}</div>${l}`}`}function DM(){const i=q.region;rs.innerHTML=`<h2 id="dialogTitle">${i.name}</h2><div class="siteCard"><img src="${os("data/locator.webp")}" alt="Weltkarte mit markiertem Untersuchungsort"><i style="left:${(i.target.lon+180)/3.6}%;top:${(90-i.target.lat)/1.8}%"></i><span>${Math.abs(i.target.lat).toFixed(2)}° ${i.target.lat>=0?"N":"S"} · ${Math.abs(i.target.lon).toFixed(2)}° ${i.target.lon>=0?"O":"W"}</span></div><p>${i.limits}</p><h3>Detailstufen</h3><p>Globale Höhen liegen auf einem 0,5°-Raster. In der Deutschen Bucht zeigt die regionale Karte Landbedeckung in etwa 75-m-Feldern. Das regionale Wattenmeer-Luftbild zeigt rund 20 m pro Bildpunkt. Erst im Untersuchungsgebiet werden lokale Luftbilder und Gelände sichtbar.</p><p>${i.sources.join("<br>")}</p><p><a href="${os("licenses/Geodaten.txt")}" target="_blank" rel="noopener">Quellen und Nutzungsrechte</a></p>`,Fs()}function Bt(){fs="",Ei++;const i=q.mode;bu.dataset.mode=i;for(const t of["globe","inside","plates","nyos","place"])be("nav-"+t).setAttribute("aria-current",i===t?"page":"false");if(mt.hidden=i==="globe",mt.hidden&&mt.replaceChildren(),be("orbitProcess").hidden=!(i==="plates"&&q.processDetail),i==="plates"){const t=!!mt.querySelector("#plateSettings[open]"),n=mt.dataset.profile;mt.innerHTML=AM(q),mt.dataset.profile=q.profileCode+(q.mosaic?.pair?"-pair":""),n!==mt.dataset.profile&&(mt.scrollTop=0),t&&be("plateSettings")&&(be("plateSettings").open=!0),TM(mt,q,Bt)}if(be("nyosPin").hidden=!0,be("nyosRelief").hidden=!0,i==="nyos"&&(mt.dataset.nyosError=String(!!q.nyos.error),mt.innerHTML=MM(q),SM(mt,q,Bt)),i==="place"){const t=q.region;mt.innerHTML=`<h1>Orte</h1><label class="siteSelect">Ort wählen <select id="siteSelect">${Kv.map(n=>`<option value="${n.id}" ${n.id===t.id?"selected":""}>${n.name}</option>`).join("")}</select></label><div class="siteActions"><button id="overview" class="action secondary">${en("compass")} Inselübersicht</button><button id="nearby" class="action secondary">${en("map-pin")} Nahansicht</button></div><button id="siteInfo" class="action primary">${en("info")} Ort und Quellen</button><button id="return" class="action secondary">${en("globe-2")} Zur globalen Ansicht</button>`,be("siteSelect").onchange=n=>{q.visit(n.target.value),Bt(),(be("siteSelect")||be("tectonicSite")||be("nyos-near"))?.focus()},be("overview").onclick=()=>q.visit(t.id,!0),be("nearby").onclick=()=>q.visit(t.id)}if(i==="inside"){const t=!!mt.querySelector("#shellOptions[open]");mt.innerHTML=LM(),t&&(be("shellOptions").open=!0)}if(i==="inside"||i==="plates"){const t=document.createElement("section");t.id="definition",t.hidden=!0,t.setAttribute("aria-live","polite"),(mt.querySelector(".panelHead")??mt.querySelector("h1"))?.after(t)}be("explainLayer")?.addEventListener("click",()=>co(Qt[q.shell.selected])),be("revealOne")?.addEventListener("click",()=>{Lt.add(q.shell.selected),Lt.size===Qt.length&&(yt=!0,Lt.clear()),Bt(),be("explainLayer")?.focus()}),be("hideOne")?.addEventListener("click",()=>{const t=q.shell.selected;yt&&Qt.forEach((n,s)=>Lt.add(s)),yt=!1,Lt.delete(t),Bt(),be("revealOne").focus({preventScroll:!0})}),be("lithosphere")?.addEventListener("change",()=>{q.shell.setComparison(be("lithosphere").checked?"lithosphere":"reference"),Cs("lithosphere")}),be("labels")?.addEventListener("click",()=>{yt=!yt&&Lt.size===0,Lt.clear(),Bt(),be("labels").focus()}),be("allNames")?.addEventListener("click",()=>{yt=!0,Lt.clear(),Bt(),be("labels").focus()}),be("isolate")?.addEventListener("click",()=>{q.shell.visible=Qt.map((t,n)=>n===q.shell.selected),Cs("isolate")}),be("restoreLayers")?.addEventListener("click",()=>{q.shell.restore(),Cs("restoreLayers")}),be("subdue")?.addEventListener("click",()=>{q.shell.subdued=!q.shell.subdued,Cs("subdue")}),be("evidence")?.addEventListener("click",()=>{rs.innerHTML=pM(yt),Fs()}),be("return")?.addEventListener("click",()=>Tu("globe")),be("siteInfo")?.addEventListener("click",DM),mt.querySelectorAll("[data-layer]").forEach(t=>t.onclick=()=>Bl(+t.dataset.layer)),mt.querySelectorAll("[data-eye]").forEach(t=>t.onclick=()=>{const n=+t.dataset.eye;q.shell.visible[n]=!q.shell.visible[n],q.shell.rebuild(),Bt(),mt.querySelector('[data-eye="'+n+'"]')?.focus()});const e=be("opacity");e&&(e.oninput=()=>{q.shell.selected!==null&&(q.shell.opacity[q.shell.selected]=+e.value/100,q.shell.rebuild())}),be("cut")&&(be("cut").onchange=t=>{q.shell.cut=t.target.checked,q.shell.rebuild(),Bt(),be("cut").focus()}),be("scale")&&(be("scale").onchange=t=>{q.shell.setComparison(t.target.checked?"expanded":"reference"),Cs("scale")}),IM(),Ru(),Ol()}function Cs(i){q.shell.rebuild(),Bt(),be(i)?.focus()}function Bl(i){q.shell.selected=i,q.shell.visible[i]=!0,q.shell.rebuild(),Bt(),mt.querySelector('[data-layer="'+i+'"]')?.focus()}function IM(){if(q.mode==="nyos"){to(q);return}const i=be("modelnote");i.hidden=q.mode==="globe",i.classList.toggle("exaggerated",q.mode==="inside"&&q.shell.expanded),i.textContent=q.mode==="inside"?q.shell.expanded?`Didaktisch überhöht · ${yt?"Kruste":"Außenschale"} verbreitert`:yt?"Maßstabsgetreu · vereinfachte Krustendicke":"Maßstabsgetreu · vereinfachte Dicke der Außenschale":q.mode==="plates"?q.processDetail?"Schematischer Schnitt · Zeit stark überhöht":q.processSite?"Regionale Ansicht":q.mosaic?.pair?"Zwei starre Ausschnitte · Abstand und Zeit schematisch":"Heutige Platten · grafische Abdeckung · Dicke überhöht":q.region.label,q.mode==="inside"&&q.shell.cut&&q.shell.lithosphere&&q.shell.visible[0]&&q.shell.visible[1]&&(i.textContent=yt?"Lithosphäre: Erdkruste und starrer oberster Mantel. Untergrenze schematisch.":"Referenzmaßstab · Schraffur für den starren Außenbereich. Untergrenze schematisch.")}function Tu(i){i==="inside"?q.inside():i==="nyos"?q.visit("nyos"):i==="plates"?q.plates():i==="place"?q.visit():q.globe(),Bt()}function bh(){yt=!1,Lt.clear(),q.shell.setComparison("reference"),q.region=Ds,q.shell.restore(),q.shell.cut=!0,q.smallPlateNames=!1,q.globe(!0),q.setPlateOptions({boundaries:!1,names:!1,types:!1,category:"all",plate:""}),Bt()}function zl(i){fs="",Ei++,Qs=i,document.body.classList.toggle("present",i);const e=be("present");e.setAttribute("aria-pressed",String(i));const t=i?"Präsentation beenden":"Präsentieren";e.setAttribute("aria-label",t),e.innerHTML=en(i?"minimize":"maximize")+`<span>${t}</span>`,Ol()}const Cu=[document.querySelector(".tools"),be("modelnote"),document.querySelector(".orientation")],UM=new ResizeObserver(()=>{Ei++});for(const i of[...Cu,mt,be("earth")])UM.observe(i);document.fonts.addEventListener("loadingdone",()=>{Ei++});function Ru(){const i=q.nav.pose,e=q.shell,t=q.plateOptions,n=be("earth"),s=[q.mode,i.lat,i.lon,i.d,i.tilt,i.bearing,n.clientWidth,n.clientHeight,yt,Lt.size,e.cut,e.expanded,e.lithosphere,e.group.visible,e.visible.join(),t.boundaries,t.names,t.plate,q.singlePlateName,q.processDetail,q.processSite,q.processChoice,q.smallPlateNames,q.atlasReady,q.processProgress,q.annotationTransition,Qs,Ei].join("/");if(fs===s)return;fs=s;const r=Cu;Eu.draw(q.mode==="inside"&&(yt||Lt.size)?q.layerMarkers(Lt,yt):[],r,Ei);const o=q.mode==="plates"&&(t.names||q.singlePlateName)?q.processDetail?q.processLabels():q.plateLabels().map(a=>({...a,id:a.code,text:"Zu dieser Platte gehören die Erdkruste und der starre oberste Erdmantel. Sie bewegt sich langsam gegenüber anderen Platten."})):[];Au.draw(o,[...r,mt],Ei)}be("info").onclick=PM;Yn.onclose=()=>rs.replaceChildren();be("closeDialog").onclick=()=>Yn.close();Yn.onclick=i=>{i.target===Yn&&Yn.close()};be("present").onclick=async()=>{zl(!Qs);try{Qs?await document.documentElement.requestFullscreen?.():document.fullscreenElement&&await document.exitFullscreen()}catch{}};document.onfullscreenchange=()=>{document.fullscreenElement||zl(!1)};const wh=be("earth");Ol();async function NM(){try{q=new fM(wh,al)}catch{bu.dataset.mode="fallback",mt.hidden=!1,mt.innerHTML='<h1>Weltkarte</h1><p class="intro">WebGL 2 ist auf diesem Gerät nicht verfügbar. Die lokale Erdkarte zeigt die Kontinente zur Orientierung.</p>',wh.parentElement.classList.add("fallback"),document.querySelectorAll("nav button,.tools button,#present").forEach(t=>t.disabled=!0),al("Ersatzansicht · lokale Weltkarte");return}Bt(),q.onLayer=t=>{yt||Lt.has(t)?co(Qt[t]):Bl(t)},q.onBoundary=()=>{q.mode==="plates"&&Bt()};for(const t of["globe","inside","plates","nyos","place"])be("nav-"+t).onclick=()=>Tu(t);be("in").onclick=()=>q.nav.zoom(.68),be("out").onclick=()=>q.nav.zoom(1/.68),be("home").onclick=bh,be("orbitProcess").onclick=()=>{q.nav.stop(),q.nav.goal.bearing+=35},be("tilt").onclick=()=>{q.nav.stop(),q.nav.goal.tilt=q.nav.goal.tilt>55?0:q.nav.goal.tilt+30},document.addEventListener("keydown",t=>{if(t.key==="Escape"&&!Yn.open&&be("definition")&&!be("definition").hidden){be("definition").querySelector(":scope > button")?.click();return}if(Yn.open||t.target instanceof HTMLInputElement||t.target instanceof HTMLSelectElement||t.altKey||t.ctrlKey||t.metaKey)return;const n=q.nav;if(t.key==="Home")bh();else if(["+","=","-"].includes(t.key))n.zoom(t.key==="-"?1.35:.74);else if(t.key.startsWith("Arrow"))n.pan(t.key==="ArrowLeft"?42:t.key==="ArrowRight"?-42:0,t.key==="ArrowUp"?42:t.key==="ArrowDown"?-42:0);else if(t.key==="Escape"&&Qs)zl(!1),document.fullscreenElement&&document.exitFullscreen();else return;t.preventDefault()});let i=0,e=NaN;q.onFrame=()=>{(q.mode==="inside"&&(yt||Lt.size)||q.mode==="plates"&&(q.plateOptions.names||q.singlePlateName))&&Ru();const t=performance.now();if(t-i<55)return;i=t,e!==q.nav.pose.bearing&&(e=q.nav.pose.bearing,document.querySelector(".orientation svg").style.transform=`rotate(${e}deg)`),q.mode==="plates"&&Zi(q),q.mode==="nyos"&&(mt.dataset.nyosError!==String(!!q.nyos.error)&&Bt(),to(q));const n=q.nyosWarning||q.mode==="place"&&q.local.warning||wu||"";ol.textContent!==n&&(ol.textContent=n)},await q.init(),Object.defineProperty(window,"geoAtlasCoverage",{value:()=>q.atlasCoverage()}),Object.defineProperty(window,"geoObservatory",{value:()=>({...q.diagnostics(),annotationDom:{...Au.work},shellAnnotationDom:{...Eu.work}})})}NM().catch(()=>al("Das Erdmodell konnte nicht geladen werden. Bitte die Seite neu laden."));
