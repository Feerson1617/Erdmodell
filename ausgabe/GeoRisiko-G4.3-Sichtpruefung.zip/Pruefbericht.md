# Browserprüfung G4.3

Geprüfte Einzeldatei (SHA-256) `9d2ebce85ed62826b88394de7c049c713f621cbae74236b5aea96a54dfacc467`.

## chromium 141.0.7390.37

52 von 52 Flächen per Zeigertreffer identifiziert. Acht Antworten über die Schalenbeschriftungen geöffnet. Island, Japan und Kalifornien gestartet. Die Einzeldatei arbeitete bei gesperrtem HTTP(S)-Zugriff. Auch die Originaldatei wurde über file:// geöffnet.

Nach Bewegung und Rücksetzung unterschieden sich 73378 Bildpunkte des geprüften Ausschnitts. Die Drehung wurde über die Oberflächenkoordinaten aller Platten geprüft. Der pazifikfeste Bezugspunkt blieb in Ruhe. Die Rücksetzung brachte alle Messpunkte exakt an die Ausgangsposition.

Geprüfte Bildschirmgrößen: 1920 × 1080, 768 × 1024, 1024 × 768.

Warme Ansichtswechsel (Geometrien / Texturen / Programme): 259 / 22 / 18, 259 / 22 / 18, 259 / 22 / 18, 259 / 22 / 18.

## webkit 26.0

52 von 52 Flächen per Zeigertreffer identifiziert. Acht Antworten über die Schalenbeschriftungen geöffnet. Island, Japan und Kalifornien gestartet. Die Einzeldatei arbeitete bei gesperrtem HTTP(S)-Zugriff. Auch die Originaldatei wurde über file:// geöffnet.

Nach Bewegung und Rücksetzung unterschieden sich 73962 Bildpunkte des geprüften Ausschnitts. Die Drehung wurde über die Oberflächenkoordinaten aller Platten geprüft. Der pazifikfeste Bezugspunkt blieb in Ruhe. Die Rücksetzung brachte alle Messpunkte exakt an die Ausgangsposition.

Geprüfte Bildschirmgrößen: 1920 × 1080, 768 × 1024, 1024 × 768.

Warme Ansichtswechsel (Geometrien / Texturen / Programme): 265 / 22 / 18, 265 / 22 / 18, 265 / 22 / 18, 265 / 22 / 18.

## Geometrie und Richtung

32077 gekrümmte Oberflächendreiecke in jeweils 32 Zeitständen auf Umklappen geprüft. Die gemeinsamen Randpunkte bleiben geschlossen. Für Island, Japan, Kalifornien und den Ostafrikanischen Graben wurden relative Richtung und Geschwindigkeit aus den Eulerpolen unabhängig mit den veröffentlichten Grenzdaten verglichen.

## Reichweite

Die bytegleiche Rückfallversion öffnet das Modell, sucht aber die dekorative Himmelsgrafik sky.png neben der Datei. G4.3 bettet dieses Bild ein. Die Messungen stammen aus echten Cloud-Browsern mit simulierter Maus- und Touchbedienung. Displayhelligkeit, Stifteingabe an einer physischen Tafel, Safari auf dem konkreten Schul-Mac und ein Import ins produktive Schul-LMS sind gesonderte Geräteprüfungen.
